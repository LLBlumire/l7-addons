local _, addon = ...
local cache = {}
local names, formats

local aliases = {
    ITEM_MOD_ARMOR_SHORT = "RESISTANCE0_NAME",
    ITEM_MOD_HOLY_RESISTANCE_SHORT = "RESISTANCE1_NAME",
    ITEM_MOD_FIRE_RESISTANCE_SHORT = "RESISTANCE2_NAME",
    ITEM_MOD_NATURE_RESISTANCE_SHORT = "RESISTANCE3_NAME",
    ITEM_MOD_FROST_RESISTANCE_SHORT = "RESISTANCE4_NAME",
    ITEM_MOD_SHADOW_RESISTANCE_SHORT = "RESISTANCE5_NAME",
    ITEM_MOD_ARCANE_RESISTANCE_SHORT = "RESISTANCE6_NAME",
    ITEM_MOD_POWER_REGEN0_SHORT = "ITEM_MOD_MANA_REGENERATION_SHORT",
    ITEM_MOD_HEALTH_REGENERATION_SHORT = "ITEM_MOD_HEALTH_REGEN_SHORT",
}

local attributes = {
    "ITEM_MOD_STRENGTH_SHORT", "ITEM_MOD_AGILITY_SHORT", "ITEM_MOD_STAMINA_SHORT",
    "ITEM_MOD_INTELLECT_SHORT", "ITEM_MOD_SPIRIT_SHORT",
}
local resistances = {"RESISTANCE2_NAME", "RESISTANCE3_NAME", "RESISTANCE4_NAME", "RESISTANCE5_NAME", "RESISTANCE6_NAME"}
local enchantKeys = {
    "ITEM_MOD_HEALTH_SHORT", "ITEM_MOD_MANA_SHORT", "RESISTANCE0_NAME", "RESISTANCE1_NAME",
    "RESISTANCE2_NAME", "RESISTANCE3_NAME", "RESISTANCE4_NAME", "RESISTANCE5_NAME", "RESISTANCE6_NAME",
    "ITEM_MOD_ATTACK_POWER_SHORT", "ITEM_MOD_RANGED_ATTACK_POWER_SHORT", "ITEM_MOD_SPELL_POWER_SHORT",
    "ITEM_MOD_SPELL_DAMAGE_DONE_SHORT", "ITEM_MOD_SPELL_HEALING_DONE_SHORT",
    "ITEM_MOD_MANA_REGENERATION_SHORT", "ITEM_MOD_HEALTH_REGEN_SHORT",
    "ITEM_MOD_DEFENSE_SKILL_RATING_SHORT", "ITEM_MOD_HIT_RATING_SHORT", "ITEM_MOD_CRIT_RATING_SHORT",
    "ITEM_MOD_HASTE_RATING_SHORT", "ITEM_MOD_DODGE_RATING_SHORT", "ITEM_MOD_PARRY_RATING_SHORT",
    "ITEM_MOD_BLOCK_RATING_SHORT", "ITEM_MOD_BLOCK_VALUE_SHORT", "ITEM_MOD_EXPERTISE_RATING_SHORT",
    "ITEM_MOD_SPELL_PENETRATION_SHORT",
}

local function readable(value, kind)
    return not issecretvalue(value) and type(value) == kind
end

local function plain(text)
    return text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", "")
        :gsub("|A.-|a", ""):gsub("\194\160", " "):gsub("%s+", " "):match("^%s*(.-)%s*$")
end

local function escape(text)
    return text:gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1")
end

local function number(text)
    return tonumber((text:gsub(",", ".")))
end

local function add(stats, keys, value)
    if type(keys) == "string" then
        stats[keys] = (stats[keys] or 0) + value
    else
        for _, key in ipairs(keys) do
            add(stats, key, value)
        end
    end
end

local function buildPatterns()
    names, formats = {}, {}
    local registered = {}
    local function register(name, keys)
        if readable(name, "string") and name ~= "" then
            name = plain(name):lower()
            if not registered[name] then
                registered[name] = true
                names[#names + 1] = {name = name, keys = keys}
            end
        end
    end
    local function registerKey(key)
        register(_G[key], key)
        local format = _G[key:gsub("_SHORT$", "")]
        if key:match("_SHORT$") and readable(format, "string") then
            format = plain(format):lower():gsub("%%c", "")
            local count
            format, count = format:gsub("%%[sd]", "\1")
            if count == 1 and not format:find("%", 1, true) then
                formats[#formats + 1] = {pattern = "^" .. escape(format):gsub("\1", "([%%+%%-]?%%d+[%%.,]?%%d*)") .. "$", key = key}
            end
        end
    end
    for _, key in ipairs(attributes) do
        registerKey(key)
    end
    for _, key in ipairs(enchantKeys) do
        registerKey(key)
    end
    register(_G.SPELL_STATALL, attributes)
    register("All Stats", attributes)
    register("to All Stats", attributes)
    register("All Resistances", resistances)
    register("to All Resistances", resistances)
    register("All Resistance", resistances)
    register("Healing Power", "ITEM_MOD_SPELL_HEALING_DONE_SHORT")
    register("Healing Spells", "ITEM_MOD_SPELL_HEALING_DONE_SHORT")
    register("Healing", "ITEM_MOD_SPELL_HEALING_DONE_SHORT")
    register("Spell Damage and Healing", "ITEM_MOD_SPELL_POWER_SHORT")
    register("Damage and Healing Spells", "ITEM_MOD_SPELL_POWER_SHORT")
    register("Mana per 5 sec.", "ITEM_MOD_MANA_REGENERATION_SHORT")
    register("Mana every 5 sec.", "ITEM_MOD_MANA_REGENERATION_SHORT")
    register("Health per 5 sec.", "ITEM_MOD_HEALTH_REGEN_SHORT")
    register("Weapon Damage", "L7_WEAPON_DAMAGE")
    register("Damage", "L7_WEAPON_DAMAGE")
    table.sort(names, function(left, right) return #left.name > #right.name end)
end

local function enchantStats(text)
    if not names then
        buildPatterns()
    end
    text = text:lower()
    for _, rule in ipairs(formats) do
        local value = text:match(rule.pattern)
        if value and not text:find("%", 1, true) then
            return {[rule.key] = number(value)}
        end
    end
    local stats, matched = {}, false
    for _, rule in ipairs(names) do
        local name = escape(rule.name)
        for _, pattern in ipairs({"([%+%-]?%d+[%.,]?%d*)%s*" .. name, name .. "%s*([%+%-]?%d+[%.,]?%d*)"}) do
            text = text:gsub(pattern, function(value)
                matched = true
                add(stats, rule.keys, number(value))
                return " "
            end)
        end
    end
    text = text:gsub("%f[%a]and%f[%A]", "")
    if matched and not text:find("%", 1, true) and text:gsub("[%s%p]", "") == "" then
        return stats
    end
end

local function enchantText(text)
    text = plain(text)
    local wrapper = _G.ENCHANTED_TOOLTIP_LINE
    if readable(wrapper, "string") then
        local pattern, count = plain(wrapper):gsub("%%s", "\1")
        if count == 1 then
            local value = text:match("^" .. escape(pattern):gsub("\1", "(.-)") .. "$")
            if value then
                return plain(value)
            end
        end
    end
    return text:gsub("^Enchanted:%s*", "")
end

local function normalize(raw)
    if not readable(raw, "table") then
        return nil
    end
    local stats = {}
    for key, value in pairs(raw) do
        if not readable(key, "string") or not readable(value, "number") then
            return nil
        end
        if not aliases[key] then
            stats[key] = value
        end
    end
    for alias, key in pairs(aliases) do
        if raw[alias] ~= nil and stats[key] == nil then
            stats[key] = raw[alias]
        end
    end
    return stats
end

function addon.GetItemStats(link)
    if not link then
        return {}, {}
    end
    if cache[link] then
        return cache[link].stats, cache[link].effects
    end
    local enchantID = tonumber(link:match("item:%-?%d+:([^:]*)")) or 0
    local base = link:gsub("(item:%-?%d+:)[^:]*:", function(prefix) return prefix .. "0:" end, 1)
    local stats = normalize(C_Item.GetItemStats(base))
    if not stats then
        return nil
    end
    local effects = {}
    if enchantID ~= 0 then
        local enchanted = normalize(C_Item.GetItemStats(link))
        local nativeBonuses = false
        if enchanted then
            for key, value in pairs(enchanted) do
                nativeBonuses = nativeBonuses or value ~= (stats[key] or 0)
            end
            for key, value in pairs(stats) do
                nativeBonuses = nativeBonuses or value ~= (enchanted[key] or 0)
            end
            if nativeBonuses then
                stats = enchanted
            end
        end
        local data = C_TooltipInfo.GetHyperlink(link)
        if not readable(data, "table") or not readable(data.lines, "table") then
            return nil
        end
        local found = false
        for _, line in ipairs(data.lines) do
            if not issecretvalue(line.type) and line.type == Enum.TooltipDataLineType.ItemEnchantmentPermanent then
                if not readable(line.leftText, "string") then
                    return nil
                end
                local text = enchantText(line.leftText)
                if text == "" then
                    return nil
                end
                local bonuses = enchantStats(text)
                if bonuses then
                    if not nativeBonuses then
                        for key, value in pairs(bonuses) do
                            add(stats, key, value)
                        end
                    end
                else
                    effects[text] = (effects[text] or 0) + 1
                end
                found = true
            end
        end
        if not found then
            return nil
        end
    end
    local spellPower = stats.ITEM_MOD_SPELL_POWER_SHORT
    if spellPower then
        add(stats, "ITEM_MOD_SPELL_DAMAGE_DONE_SHORT", spellPower)
        add(stats, "ITEM_MOD_SPELL_HEALING_DONE_SHORT", spellPower)
        stats.ITEM_MOD_SPELL_POWER_SHORT = nil
    end
    cache[link] = {stats = stats, effects = effects}
    return stats, effects
end

function addon.ClearStatCache()
    cache = {}
end
