local _, addon = ...
local driver = CreateFrame("Frame")
local form
local scroll
local recipeID
local installed = false
local itemLoads = {}
local SCROLL_LEFT = 22
local SCROLL_STEP = 36
local CONTENT_LEFT = 5
local TOP_PAD = 4
local BOTTOM_PAD = 8
local ROW_TOP = 28
local ROW_GAP = 3

local function money(value)
    return value ~= nil and GetMoneyString(math.ceil(math.abs(value)), true) or "—"
end

local function profit(value)
    if value == nil then
        return "Unknown"
    end
    local text = (value < 0 and "−" or "+") .. money(value)
    return (value < 0 and "|cffff6060" or "|cff40ff40") .. text .. "|r"
end

local function age(timestamp)
    local seconds = math.max(0, GetServerTime() - timestamp)
    local count, unit = seconds, "second"
    if seconds >= 86400 then
        count, unit = math.floor(seconds / 86400), "day"
    elseif seconds >= 3600 then
        count, unit = math.floor(seconds / 3600), "hour"
    elseif seconds >= 60 then
        count, unit = math.floor(seconds / 60), "minute"
    end
    return count .. " " .. unit .. (count == 1 and "" or "s") .. " ago"
end

local function itemInfo(id)
    if not addon.Readable(id, "number") or id <= 0 then
        return
    end
    local name, _, _, _, _, _, _, _, _, _, sell, _, _, bind = C_Item.GetItemInfo(id)
    if not name and not itemLoads[id] then
        itemLoads[id] = true
        C_Item.RequestLoadItemDataByID(id)
    end
    return name, sell, bind
end

local function auctionPrice(id, market)
    if id and L7AuctionScanner and type(L7AuctionScanner.GetPrice) == "function" then
        return L7AuctionScanner.GetPrice(id, market)
    end
end

local function reagents(transaction, schematic)
    local entries = {}
    for index, slot in ipairs(schematic.reagentSlotSchematics) do
        local required = slot.required or slot.reagentType == Enum.CraftingReagentType.Basic
        if required and #slot.reagents == 1 then
            local reagent = slot.reagents[1]
            entries[#entries + 1] = {
                id = reagent.itemID, currency = reagent.currencyID,
                quantity = transaction:GetQuantityRequiredInSlot(index, reagent),
            }
        else
            local allocated = 0
            for _, allocation in transaction:GetAllocations(index):Enumerate() do
                local reagent = allocation:GetReagent()
                local quantity = allocation:GetQuantity()
                if quantity > 0 then
                    entries[#entries + 1] = {id = reagent.itemID, currency = reagent.currencyID, quantity = quantity}
                    allocated = allocated + quantity
                end
            end
            if required and allocated < slot.quantityRequired then
                entries[#entries + 1] = {quantity = slot.quantityRequired - allocated, name = "Unselected reagent"}
            end
        end
    end
    local grouped, items = {}, {}
    for _, entry in ipairs(entries) do
        local previous = entry.id and items[entry.id]
        if previous then
            previous.quantity = previous.quantity + entry.quantity
        else
            grouped[#grouped + 1] = entry
            if entry.id then
                items[entry.id] = entry
            end
        end
    end
    return grouped
end

local function craftingNote(craft, quantity)
    local lines = {craft.casts .. " × " .. craft.name}
    local function materials(plan, depth)
        for _, material in ipairs(plan.materials) do
            if #lines >= 20 then
                lines[#lines + 1] = "…"
                return
            end
            local name = itemInfo(material.id) or ("Item " .. material.id)
            lines[#lines + 1] = string.rep("  ", depth) .. material.quantity .. " × " .. name .. ": " .. money(material.cost)
            if material.source == "Craft" then
                materials(material.craft, depth + 1)
            end
        end
        if plan.bought > 0 then
            lines[#lines + 1] = string.rep("  ", depth) .. "Buy " .. plan.bought .. " remaining: " .. money(plan.purchaseCost)
        end
    end
    materials(craft, 0)
    local surplus = craft.produced + craft.bought - quantity
    if surplus > 0 then
        lines[#lines + 1] = surplus .. " extra; no sale value credited."
    end
    lines[#lines + 1] = "Uses whole batches and minimum recipe yields."
    return table.concat(lines, "\n")
end

local function showRowTooltip(row)
    GameTooltip:SetOwner(row, "ANCHOR_RIGHT")
    GameTooltip:ClearLines()
    if row.itemID then
        GameTooltip:SetItemByID(row.itemID)
    else
        GameTooltip:AddLine(row.label:GetText(), 1, 1, 1)
    end
    if row.note then
        GameTooltip:AddLine(row.note, 0.7, 0.7, 0.7, true)
    end
    GameTooltip:Show()
end

local function createScroll()
    local frame = CreateFrame("ScrollFrame", nil, form, "UIPanelScrollFrameTemplate")
    frame:Hide()
    frame.scrollBarHideIfUnscrollable = true
    frame.scrollBarHideable = true
    frame:EnableMouseWheel(true)
    local scrollbar = frame.ScrollBar or frame.scrollBar
    if scrollbar then
        scrollbar.scrollStep = SCROLL_STEP
        scrollbar:Hide()
    end
    frame:SetScript("OnMouseWheel", function(self, delta)
        local maxScroll = math.max(0, self:GetVerticalScrollRange())
        local target = math.max(0, math.min(self:GetVerticalScroll() - delta * SCROLL_STEP, maxScroll))
        if scrollbar then
            scrollbar:SetValue(target)
        else
            self:SetVerticalScroll(target)
        end
    end)
    frame.content = CreateFrame("Frame", nil, frame)
    frame.content:SetSize(1, 1)
    frame:SetScrollChild(frame.content)
    for _, container in pairs({form.Reagents, form.OptionalReagents, form.FinishingReagents, form.Concentrate}) do
        container:SetParent(frame.content)
    end
    frame:SetScript("OnUpdate", function(self, elapsed)
        self.elapsed = (self.elapsed or 0) + elapsed
        if self.elapsed >= 1 then
            self.elapsed = 0
            addon.RefreshPricing()
        end
    end)
    return frame
end

local reflowScroll
local reflowQueued = false

local function queueReflow()
    if reflowQueued then
        return
    end
    reflowQueued = true
    C_Timer.After(0, function()
        reflowScroll()
        reflowQueued = false
    end)
end

local function layoutViewport()
    local formTop, formBottom = form:GetTop(), form:GetBottom()
    local topInset = 12
    local needsReflow = not formTop
    for _, header in pairs({form.OutputIcon, form.Cooldown, form.MinimizedCooldown, form.Description,
        form.RecipeSourceButton, form.FirstCraftBonus, form.recraftSlot, form.RecraftingDescription}) do
        if header:IsShown() then
            local isText = header:IsObjectType("FontString")
            local label = isText and header:GetText()
            if not isText or (label and label ~= "") then
                local bottom = header:GetBottom()
                needsReflow = needsReflow or not bottom
                local gap = header == form.RecipeSourceButton and 16 or 12
                topInset = math.max(topInset, formTop and bottom and math.ceil(formTop - bottom) + gap or 120)
            end
        end
    end

    local rightInset = 30
    local details = form.Details
    local detailsLeft = details and details:IsShown() and details:GetLeft()
    local formLeft, formRight = form:GetLeft(), form:GetRight()
    if detailsLeft and formLeft and formRight and detailsLeft > formLeft + 200 then
        rightInset = math.max(rightInset, math.ceil(formRight - detailsLeft) + 30)
    end

    local bottomInset = 16
    for _, checkbox in pairs({form.TrackRecipeCheckbox, form.AllocateBestQualityCheckbox}) do
        local top = checkbox:IsShown() and checkbox:GetTop()
        if formBottom and top and top < formBottom + 90 then
            bottomInset = math.max(bottomInset, 36, math.ceil(top - formBottom) + 8)
        end
    end
    local height = form:GetHeight()
    if height > 0 then
        topInset = math.min(topInset, math.max(0, height - bottomInset - 1))
    end

    scroll:SetPoint("TOPLEFT", form, "TOPLEFT", SCROLL_LEFT, -topInset)
    scroll:SetPoint("BOTTOMRIGHT", form, "BOTTOMRIGHT", -rightInset, bottomInset)
    local width = form:GetWidth()
    scroll.content:SetWidth(math.max(1, width > 0 and width - SCROLL_LEFT - rightInset or scroll:GetWidth()))
    if needsReflow or scroll:GetHeight() <= 0 then
        queueReflow()
    end
end

local function layoutReagents()
    local content = scroll.content
    local basic, optional, finishing, concentrate = form.Reagents, form.OptionalReagents,
        form.FinishingReagents, form.Concentrate
    local bottom
    local anchor, point, x, y = content, "TOPLEFT", CONTENT_LEFT, -TOP_PAD
    local nextTop = TOP_PAD
    if basic and basic:IsShown() then
        basic:ClearAllPoints()
        basic:SetPoint("TOPLEFT", anchor, point, x, y)
        bottom = TOP_PAD + basic:GetHeight()
        nextTop = bottom + 20
        anchor, point, x, y = basic, "BOTTOMLEFT", 0, -20
    end
    if optional and optional:IsShown() then
        optional:ClearAllPoints()
        optional:SetPoint("TOPLEFT", anchor, point, x, y)
        bottom = nextTop + optional:GetHeight()
        anchor, point, x, y = optional, "TOPLEFT", 186, 0
    end
    local showConcentrate = finishing and concentrate and concentrate:IsShown()
    if finishing and (finishing:IsShown() or showConcentrate) then
        finishing:ClearAllPoints()
        finishing:SetPoint("TOPLEFT", anchor, point, x, y)
        if finishing:IsShown() then
            bottom = math.max(bottom or 0, nextTop + finishing:GetHeight())
        end
    end
    if showConcentrate then
        local _, _, _, _, offsetY = concentrate:GetPoint()
        bottom = math.max(bottom or 0, nextTop - (offsetY or 0) + concentrate:GetHeight())
    end
    return bottom
end

local function updateScroll(offset)
    scroll:UpdateScrollChildRect()
    local maxScroll = math.max(0, math.floor(scroll:GetVerticalScrollRange()))
    offset = math.max(0, math.min(offset, maxScroll))
    local scrollbar = scroll.ScrollBar or scroll.scrollBar
    if scrollbar then
        scrollbar:SetMinMaxValues(0, maxScroll)
        scrollbar:SetValue(offset)
        scrollbar:SetShown(maxScroll > 0)
    end
    scroll:SetVerticalScroll(offset)
end

function reflowScroll()
    if scroll and scroll:IsVisible() and form:GetRecipeInfo() then
        local offset = scroll:GetVerticalScroll()
        layoutViewport()
        updateScroll(offset)
    end
end

local function createPanel()
    local panel = CreateFrame("Frame", nil, scroll.content)
    panel:Hide()
    panel.toggle = CreateFrame("CheckButton", nil, panel, "CheckboxWithLabelTemplate")
    panel.toggle:SetSize(24, 24)
    panel.toggle:SetPoint("TOPLEFT", -3, 1)
    panel.toggle.Text:SetText("Craft cheaper reagents")
    panel.toggle:SetScript("OnClick", function(self)
        addon.SetCraftReagents(self:GetChecked())
    end)
    panel.rows = {}
    form.L7Prices = panel
    return panel
end

local function setRow(panel, index, label, auction, vendor, itemID, note, source)
    local row = panel.rows[index]
    if not row then
        row = CreateFrame("Frame", nil, panel)
        local previous = panel.rows[index - 1]
        local edge = previous and "BOTTOM" or "TOP"
        local gap = previous and ROW_GAP or ROW_TOP
        row:SetPoint("TOPLEFT", previous or panel, edge .. "LEFT", 0, -gap)
        row:SetPoint("TOPRIGHT", previous or panel, edge .. "RIGHT", 0, -gap)
        row:EnableMouse(true)
        row:SetScript("OnEnter", showRowTooltip)
        row:SetScript("OnLeave", GameTooltip_Hide)
        row.label = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.label:SetJustifyH("LEFT")
        row.label:SetJustifyV("TOP")
        row.label:SetWordWrap(false)
        row.label:SetPoint("TOPLEFT", 0, -2)
        row.vendor = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.vendor:SetWidth(88)
        row.vendor:SetJustifyH("RIGHT")
        row.vendor:SetJustifyV("TOP")
        row.vendor:SetPoint("TOPRIGHT", 0, -2)
        row.auction = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.auction:SetWidth(88)
        row.auction:SetJustifyH("RIGHT")
        row.auction:SetJustifyV("TOP")
        row.auction:SetPoint("TOPRIGHT", row.vendor, "TOPLEFT", -6, 0)
        panel.rows[index] = row
    end
    row.label:ClearAllPoints()
    row.label:SetPoint("TOPLEFT", 0, -2)
    if (not auction or auction == "") and (not vendor or vendor == "") then
        row.label:SetPoint("TOPRIGHT", row, "TOPRIGHT", 0, -2)
    else
        row.label:SetPoint("TOPRIGHT", row.auction, "TOPLEFT", -6, 0)
    end
    row.label:SetTextColor(1, 1, 1)
    row.label:SetText(label)
    row.auction:SetText(auction or "")
    row.vendor:SetText(vendor or "")
    row.auction:SetAlpha((not source or source == "AH") and 1 or 0.45)
    row.vendor:SetAlpha((not source or source == "Vendor") and 1 or 0.45)
    row.itemID, row.note = itemID, note
    row:SetHeight(math.max(16, row.label:GetStringHeight() + 4,
        row.auction:GetStringHeight() + 4, row.vendor:GetStringHeight() + 4))
    row:Show()
    return row
end

function addon.RefreshPricing()
    if not form or not addon.options then
        return
    end
    local recipe = form:GetRecipeInfo()
    local panel = form.L7Prices
    if not recipe then
        if panel then
            panel:Hide()
        end
        if scroll then
            scroll:Hide()
        end
        recipeID = nil
        return
    end
    if not form:IsVisible() then
        if recipeID ~= recipe.recipeID then
            recipeID = nil
        end
        return
    end

    scroll = scroll or createScroll()
    local offset = recipeID == recipe.recipeID and scroll:GetVerticalScroll() or 0
    recipeID = recipe.recipeID
    layoutViewport()
    local reagentsBottom = layoutReagents()
    local schematic = form.recipeSchematic
    local transaction = form:GetTransaction()
    if not schematic or not transaction or C_TradeSkillUI.IsDataSourceChanging() then
        if panel then
            panel:Hide()
        end
        scroll.content:SetHeight((reagentsBottom or TOP_PAD) + BOTTOM_PAD)
        scroll:Show()
        updateScroll(offset)
        return
    end
    panel = panel or createPanel()
    local panelTop = reagentsBottom and reagentsBottom + 12 or TOP_PAD
    panel:SetPoint("TOPLEFT", scroll.content, "TOPLEFT", CONTENT_LEFT, -panelTop)
    panel:SetPoint("TOPRIGHT", scroll.content, "TOPRIGHT", 0, -panelTop)
    panel.toggle:SetChecked(addon.options.craftReagents)
    panel:Show()

    local scanner = L7AuctionScanner
    local market, marketName
    if scanner and type(scanner.GetSelectedMarket) == "function" then
        market, marketName = scanner.GetSelectedMarket()
    end
    local rowIndex = 0
    local function row(...)
        rowIndex = rowIndex + 1
        return setRow(panel, rowIndex, ...)
    end
    row("Per craft", marketName and ("AH (" .. marketName .. ")") or "AH", "Vendor",
        nil, "Vendor prices: " .. addon.options.vendorPricing .. ". Unused prices are dimmed.")
    local calculator = addon.CreateReagentCostCalculator(market)
    local cost, complete, scannedAt = 0, true, nil
    local purchaseCost, purchaseComplete, crafted = 0, true, false
    for _, reagent in ipairs(reagents(transaction, schematic)) do
        local name = itemInfo(reagent.id)
        if reagent.currency then
            local info = C_CurrencyInfo.GetCurrencyInfo(reagent.currency)
            name = info and info.name
        end
        local estimate = calculator:Resolve(reagent.id, reagent.quantity)
        local offer = estimate.offer
        if estimate.cost ~= nil then
            cost = cost + estimate.cost
        else
            complete = false
        end
        if estimate.purchase ~= nil then
            purchaseCost = purchaseCost + estimate.purchase
        else
            purchaseComplete = false
        end
        crafted = crafted or estimate.source == "Craft"
        local note = estimate.source and ("Cost uses " .. estimate.source .. ".") or "Purchase price unknown."
        if offer then
            note = note .. "\n" .. (offer.name and (offer.name .. (offer.capital and " (capital)" or "")) or "Base vendor price, before discounts.")
            if offer.location and offer.location ~= "" then
                note = note .. ", " .. offer.location
            end
            if offer.name and not offer.seenAt then
                note = note .. "\nWowhead vendor price."
            end
            if offer.limited then
                note = note .. "\nLimited stock."
            end
            if offer.seenAt then
                note = note .. "\nObserved " .. age(offer.seenAt)
            end
        end
        row(reagent.quantity .. " × " .. (name or reagent.name or ("Item " .. (reagent.id or "?"))),
            money(estimate.auction), money(estimate.vendor), reagent.id, note, estimate.source)
        if estimate.craft then
            row("  Craft ×" .. estimate.craft.casts, "", money(estimate.craft.cost), reagent.id,
                craftingNote(estimate.craft, reagent.quantity), estimate.source == "Craft" and "Vendor" or "AH")
        end
    end
    scannedAt = calculator.scannedAt
    row("Total cost", "", complete and money(cost) or "Unknown", nil,
        "Buying uses vendor prices first, then AH. With crafting enabled, cheaper learned recipes are also considered. Includes reagents already owned.")
    if crafted then
        row("Craft savings", "", complete and purchaseComplete and money(purchaseCost - cost) or "Unknown",
            nil, "Savings compared with buying every reagent using your vendor price preference and AH scan.")
    end

    local outputID = schematic.outputItemID
    if not addon.Readable(outputID, "number") or outputID <= 0 then
        local result = C_TradeSkillUI.GetRecipeOutputItemData(schematic.recipeID,
            transaction:CreateCraftingReagentInfoTbl(), transaction:GetAllocationItemGUID())
        outputID = result and result.itemID
    end
    local _, sell, bind = itemInfo(outputID)
    local auction, timestamp = auctionPrice(outputID, market)
    scannedAt = timestamp or scannedAt
    if bind == 1 or schematic.recipeType ~= Enum.TradeskillRecipeType.Item then
        auction = nil
    end
    local minimum = math.max(0, schematic.quantityMin or 1)
    local maximum = math.max(minimum, schematic.quantityMax or minimum)
    local quantity = minimum == maximum and tostring(minimum) or (minimum .. "–" .. maximum)
    local function values(unit, format, subtract)
        if unit == nil then
            return "—"
        end
        local low = unit * minimum - (subtract or 0)
        local high = unit * maximum - (subtract or 0)
        return low == high and format(low) or (format(low) .. " – " .. format(high))
    end
    row("Sale (" .. quantity .. ")", values(auction, money), values(sell, money), outputID,
        "Sale value of this craft's output. AH uses the lowest buyout in the selected scan, across variants.")
    row("Profit", complete and values(auction, profit, cost) or "Unknown",
        complete and values(sell, profit, cost) or "Unknown", nil, "Sale value minus reagent cost. AH fees are excluded.")
    local footer = row("AH before fees", "", "", nil, "Auction house cuts and deposits are excluded from these figures.")
    footer.label:SetTextColor(0.7, 0.7, 0.7)
    if scannedAt then
        row("Scanned " .. age(scannedAt), "", "")
    else
        row(scanner and "No saved scan" or "Auction Scanner unavailable", "", "")
    end
    for index = rowIndex + 1, #panel.rows do
        panel.rows[index]:Hide()
    end
    local height = ROW_TOP - ROW_GAP
    for index = 1, rowIndex do
        height = height + panel.rows[index]:GetHeight() + ROW_GAP
    end
    panel:SetHeight(height)
    scroll.content:SetHeight(panelTop + height + BOTTOM_PAD)
    scroll:Show()
    updateScroll(offset)
end

function addon.InstallPricing()
    if installed or not addon.options or not ProfessionsFrame or not ProfessionsFrame.CraftingPage then
        return
    end
    form = ProfessionsFrame.CraftingPage.SchematicForm
    if not form then
        return
    end
    installed = true
    hooksecurefunc(form, "Init", addon.RefreshPricing)
    if type(form.UpdateRecipeDescription) == "function" then
        hooksecurefunc(form, "UpdateRecipeDescription", queueReflow)
    end
    form:HookScript("OnShow", addon.RefreshPricing)
    form:HookScript("OnSizeChanged", reflowScroll)
    driver:UnregisterEvent("ADDON_LOADED")
    driver:RegisterEvent("ITEM_DATA_LOAD_RESULT")
    addon.RefreshPricing()
end

driver:RegisterEvent("ADDON_LOADED")
driver:SetScript("OnEvent", function(_, event, id)
    if event == "ADDON_LOADED" then
        addon.InstallPricing()
    elseif itemLoads[id] then
        addon.RefreshPricing()
    end
end)
