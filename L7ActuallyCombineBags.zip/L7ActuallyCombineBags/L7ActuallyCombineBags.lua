local addonName = ...
local driver = CreateFrame("Frame")
local defaults = {
    mergeReagent = true,
    mergeKeyring = true,
    keepKeyringTogether = true,
    colorReagent = true,
    colorKeyring = true,
    bagOrder = 1,
    layoutMode = "BAG",
    separateSetGear = false,
    columns = 10,
}
local minimumColumns, maximumColumns = 4, 20
local itemGroups = {consumables = 0, equipment = 1, reagents = 2, quest = 3, keys = 4, other = 5}
local bagOrders = {
    {"keyring", "bags", "reagent"},
    {"keyring", "reagent", "bags"},
    {"bags", "keyring", "reagent"},
    {"bags", "reagent", "keyring"},
    {"reagent", "keyring", "bags"},
    {"reagent", "bags", "keyring"},
}
local bagLabels = {keyring = "Keyring", bags = "Regular bags", reagent = "Reagent bag"}
local options
local modeSetting
local combined
local manager
local layoutMode = "BAG"
local separateSetGear = false
local keepKeyringTogether = defaults.keepKeyringTogether
local columns = defaults.columns
local bagIDs = {}
local included = {}
local layoutRanks = {}
local slotCounts = {}
local bagParents = {}
local backgrounds = setmetatable({}, {__mode = "k"})
local reagentColor = {0.1, 0.45, 1, 0.35}
local keyringColor = {1, 0.72, 0.12, 0.35}
local itemCategories = {}
local itemTypes = {}
local itemLoads = {}
local categoryLayout
local categoryTimer
local equipmentMembers = {}
local equipmentDirty = true
local extraCategories = {junk = 100, empty = 101, reagent = 102, keyring = 103, locked = 104, combinedKeyring = 105, bags = 106}
local refreshQueued = false
local refreshRetry
local refreshPending = false
local rebuildPending = false
local layoutPending = false
local installed = false

local function reagentBag(bagID)
    return bagID > NUM_BAG_FRAMES and bagID <= NUM_TOTAL_BAG_FRAMES
end

local function keyringAvailable()
    return C_ActionBar.ShouldShowKeyring() and GetCVarBool("showKeyring")
end

local function collectBags()
    bagIDs = {}
    included = {}
    layoutMode = options.layoutMode
    separateSetGear = options.separateSetGear
    keepKeyringTogether = options.keepKeyringTogether
    columns = options.columns
    equipmentDirty = true
    categoryLayout = nil
    for rank, group in ipairs(bagOrders[options.bagOrder]) do
        layoutRanks[group] = rank
    end
    for bagID = 0, NUM_TOTAL_BAG_FRAMES do
        if bagID <= NUM_BAG_FRAMES or options.mergeReagent then
            bagIDs[#bagIDs + 1] = bagID
            included[bagID] = true
        end
    end
    if options.mergeKeyring and keyringAvailable() then
        bagIDs[#bagIDs + 1] = KEYRING_CONTAINER
        included[KEYRING_CONTAINER] = true
    end
end

local function bagRank(bagID)
    if bagID == KEYRING_CONTAINER then
        return layoutRanks.keyring
    elseif reagentBag(bagID) then
        return layoutRanks.reagent
    end
    return layoutRanks.bags
end

local function colorSlot(button)
    local bagID = button:GetBagID()
    local color
    if reagentBag(bagID) and options.colorReagent then
        color = reagentColor
    elseif bagID == KEYRING_CONTAINER and options.colorKeyring then
        color = keyringColor
    end
    local background = backgrounds[button]
    if color then
        if not background then
            background = button:CreateTexture(nil, "BACKGROUND", nil, 1)
            background:SetPoint("TOPLEFT", button, "TOPLEFT", -2, 2)
            background:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", 2, -2)
            backgrounds[button] = background
        end
        background:SetColorTexture(unpack(color))
        background:Show()
    elseif background then
        background:Hide()
    end
end

local function readable(value, kind)
    return not issecretvalue(value) and type(value) == kind
end

local function itemGUID(location)
    local exists = C_Item.DoesItemExist(location)
    if not issecretvalue(exists) and exists then
        local guid = C_Item.GetItemGUID(location)
        if readable(guid, "string") and guid ~= "" then
            return guid
        end
    end
end

local function rebuildEquipmentMembers()
    equipmentMembers = {}
    for _, setID in ipairs(C_EquipmentSet.GetEquipmentSetIDs()) do
        local ignored = C_EquipmentSet.GetIgnoredSlots(setID) or {}
        for equipmentSlot, packed in pairs(C_EquipmentSet.GetItemLocations(setID) or {}) do
            if not ignored[equipmentSlot] and readable(packed, "number") and packed >= 0 then
                local data = EquipmentManager_GetLocationData(packed)
                local location
                if data.isBags and not data.isBank and readable(data.bag, "number")
                    and data.bag >= 0 and data.bag <= NUM_TOTAL_BAG_FRAMES and data.slot > 0 then
                    location = ItemLocation:CreateFromBagAndSlot(data.bag, data.slot)
                elseif data.isPlayer and not data.isBags and not data.isBank and data.slot > 0 then
                    location = ItemLocation:CreateFromEquipmentSlot(data.slot)
                end
                if location then
                    local guid = itemGUID(location)
                    if guid then
                        equipmentMembers[guid] = true
                    end
                end
            end
        end
    end
    equipmentDirty = false
end

local function requestItemData(itemID)
    if itemLoads[itemID] == nil then
        itemLoads[itemID] = "pending"
        C_Item.RequestLoadItemDataByID(itemID)
    end
end

local function itemType(itemID)
    if itemTypes[itemID] then
        return itemTypes[itemID]
    end
    local _, _, _, _, _, classID, subclassID = C_Item.GetItemInfoInstant(itemID)
    if not readable(classID, "number") then
        requestItemData(itemID)
        return
    end
    local result = {class = classID, subclass = readable(subclassID, "number") and subclassID or 0}
    itemTypes[itemID] = result
    return result
end

local function classCategory(classID)
    if classID == Enum.ItemClass.Weapon or classID == Enum.ItemClass.Armor or classID == Enum.ItemClass.Profession then
        return itemGroups.equipment
    elseif classID == Enum.ItemClass.Consumable or classID == Enum.ItemClass.Projectile
        or classID == Enum.ItemClass.ItemEnhancement or classID == Enum.ItemClass.Glyph then
        return itemGroups.consumables
    elseif classID == Enum.ItemClass.Reagent or classID == Enum.ItemClass.Tradegoods then
        return itemGroups.reagents
    elseif classID == Enum.ItemClass.Questitem then
        return itemGroups.quest
    elseif classID == Enum.ItemClass.Key then
        return itemGroups.keys
    end
    return itemGroups.other
end

local function itemCategory(itemID)
    if itemCategories[itemID] then
        return itemCategories[itemID]
    end
    local item = itemType(itemID)
    if not item then
        return itemGroups.other
    end
    local classID = item.class
    if classID == Enum.ItemClass.Reagent or classID == Enum.ItemClass.Tradegoods then
        itemCategories[itemID] = itemGroups.reagents
    elseif classID == Enum.ItemClass.Key then
        itemCategories[itemID] = itemGroups.keys
    else
        local craftingReagent = select(17, C_Item.GetItemInfo(itemID))
        if readable(craftingReagent, "boolean") then
            itemCategories[itemID] = craftingReagent and itemGroups.reagents or classCategory(classID)
        else
            requestItemData(itemID)
        end
    end
    return itemCategories[itemID] or classCategory(classID)
end

local function slotCategory(button)
    if button.isBag then
        return extraCategories.bags
    end
    if button:IsExtended() then
        return extraCategories.locked
    end
    local bagID = button:GetBagID()
    local info = C_Container.GetContainerItemInfo(bagID, button:GetID())
    if keepKeyringTogether and bagID == KEYRING_CONTAINER then
        local itemID = info and readable(info.itemID, "number") and info.itemID or nil
        return extraCategories.combinedKeyring, itemID
    end
    if not info then
        if bagID == KEYRING_CONTAINER then
            return extraCategories.keyring
        elseif reagentBag(bagID) then
            return extraCategories.reagent
        end
        return extraCategories.empty
    end
    local itemID = readable(info.itemID, "number") and info.itemID or nil
    if readable(info.quality, "number") and info.quality == Enum.ItemQuality.Poor
        and readable(info.hasNoValue, "boolean") and not info.hasNoValue then
        return extraCategories.junk, itemID
    end
    if not readable(info.quality, "number") and itemID then
        requestItemData(itemID)
    end
    if bagID == KEYRING_CONTAINER then
        return itemGroups.keys, itemID
    elseif reagentBag(bagID) then
        return itemGroups.reagents, itemID
    elseif itemID then
        return itemCategory(itemID), itemID
    end
    return itemGroups.other
end

local function layoutItems(container)
    local items = {}
    for _, button in container:EnumerateValidItems() do
        local bagButton = GamepadBagBar and GamepadBagBar:GetBagButton(button:GetBagID())
        if not bagButton or not bagButton.isCollapsed then
            items[#items + 1] = button
        end
    end
    if InputUtil.IsGamepadUIEnabled() and GamepadBagBar then
        for _, bagID in ipairs(bagIDs) do
            local bagButton = GamepadBagBar:GetBagButton(bagID)
            if bagButton then
                items[#items + 1] = bagButton
            end
        end
    end
    return items
end

local function sortBagItems(items, ascending, sortKeys)
    local accountSecured = IsAccountSecured()
    table.sort(items, function(left, right)
        if sortKeys then
            local leftKey, rightKey = sortKeys[left], sortKeys[right]
            if leftKey.bagPriority ~= rightKey.bagPriority then
                return leftKey.bagPriority < rightKey.bagPriority
            end
            if leftKey.class ~= rightKey.class then
                return leftKey.class < rightKey.class
            end
            if leftKey.subclass ~= rightKey.subclass then
                return leftKey.subclass < rightKey.subclass
            end
            if leftKey.itemID ~= rightKey.itemID then
                return leftKey.itemID < rightKey.itemID
            end
        end
        if ascending then
            left, right = right, left
        end
        local leftBag, rightBag = left:GetBagID(), right:GetBagID()
        local leftRank, rightRank = bagRank(leftBag), bagRank(rightBag)
        if leftRank ~= rightRank then
            return leftRank > rightRank
        end
        if not accountSecured then
            local leftExtended, rightExtended = left:IsExtended(), right:IsExtended()
            if leftExtended ~= rightExtended then
                return not leftExtended
            end
        end
        if leftBag ~= rightBag then
            return leftBag > rightBag
        end
        if left.isBag ~= right.isBag then
            return right.isBag ~= nil
        end
        return left:GetID() > right:GetID()
    end)
end

local function getCategoryLayout(container)
    local columns = container:GetColumns()
    if categoryLayout and categoryLayout.columns == columns then
        return categoryLayout
    end
    if separateSetGear and equipmentDirty then
        rebuildEquipmentMembers()
    end
    local groups, byCategory, sortKeys = {}, {}, {}
    for _, button in ipairs(layoutItems(container)) do
        local category, itemID = slotCategory(button)
        local item = itemID and itemType(itemID)
        sortKeys[button] = {
            bagPriority = category == itemGroups.reagents and not reagentBag(button:GetBagID()) and 1 or 0,
            class = item and item.class or math.huge,
            subclass = item and item.subclass or 0,
            itemID = itemID or 0,
        }
        local inSet = false
        if separateSetGear and (category == itemGroups.equipment or category == extraCategories.junk) then
            local guid = itemGUID(ItemLocation:CreateFromBagAndSlot(button:GetBagID(), button:GetID()))
            inSet = guid and equipmentMembers[guid] == true
        end
        local groupID = category * 2 + (inSet and 0 or 1)
        local group = byCategory[groupID]
        if not group then
            group = {category = groupID, items = {}}
            byCategory[groupID] = group
            groups[#groups + 1] = group
        end
        group.items[#group.items + 1] = button
    end
    table.sort(groups, function(left, right) return left.category < right.category end)
    local rows = 0
    for _, group in ipairs(groups) do
        sortBagItems(group.items, true, sortKeys)
        group.row = rows
        rows = rows + math.ceil(#group.items / columns)
    end
    categoryLayout = {groups = groups, rows = rows, columns = columns}
    return categoryLayout
end

local function sameCategoryLayout(left, right)
    if not left or left.columns ~= right.columns or #left.groups ~= #right.groups then
        return false
    end
    for index, group in ipairs(left.groups) do
        local other = right.groups[index]
        if group.category ~= other.category or #group.items ~= #other.items then
            return false
        end
        for slot, button in ipairs(group.items) do
            if button ~= other.items[slot] then
                return false
            end
        end
    end
    return true
end

local function inventoryLocked()
    for _, bagID in ipairs(bagIDs) do
        for slot = 1, ContainerFrame_GetContainerNumSlots(bagID) do
            local info = C_Container.GetContainerItemInfo(bagID, slot)
            if info and (issecretvalue(info.isLocked) or info.isLocked) then
                return true
            end
        end
    end
    return false
end

local function refresh()
    if not installed or InCombatLockdown() or GetCursorInfo() == "item" then
        return
    end
    local height = combined:IsShown() and combined:GetHeight()
    if layoutMode ~= options.layoutMode then
        layoutMode = options.layoutMode
        categoryLayout = nil
        if combined:IsShown() then
            combined:UpdateFrameSize()
            combined:UpdateItemLayout()
            if height ~= combined:GetHeight() then
                UpdateContainerFrameAnchors()
            end
        end
    end
    if (rebuildPending or layoutPending) and (layoutMode == "CATEGORY" or options.layoutMode == "CATEGORY")
        and (categoryTimer or inventoryLocked()) then
        if not refreshRetry then
            refreshRetry = C_Timer.NewTimer(0.25, function()
                refreshRetry = nil
                if refreshPending or rebuildPending or layoutPending then
                    refresh()
                end
            end)
        end
        return
    end
    if refreshRetry then
        refreshRetry:Cancel()
        refreshRetry = nil
    end
    refreshPending = false
    local updateLayout = layoutPending
    layoutPending = false
    if rebuildPending then
        rebuildPending = false
        local shownBagIDs = {}
        for _, container in ContainerFrameUtil_EnumerateContainerFrames() do
            if container:IsShown() then
                container:GetContainedBagIDs(shownBagIDs)
            end
        end
        if #shownBagIDs > 0 then
            CloseAllBags()
        end
        collectBags()
        manager:MarkBagSetupDirty()
        for _, bagID in ipairs(shownBagIDs) do
            if (bagID >= 0 and bagID <= NUM_TOTAL_BAG_FRAMES)
                or (bagID == KEYRING_CONTAINER and keyringAvailable()) then
                OpenBag(bagID)
            end
        end
    elseif updateLayout and layoutMode == "CATEGORY" and combined:IsShown() then
        local previous = categoryLayout
        categoryLayout = nil
        local current = getCategoryLayout(combined)
        if not sameCategoryLayout(previous, current) then
            combined:UpdateItemLayout()
            if height ~= combined:GetHeight() then
                UpdateContainerFrameAnchors()
            end
        end
    end
    if combined:IsShown() then
        for _, button in combined:EnumerateValidItems() do
            colorSlot(button)
        end
    end
end

local function queueRefresh(rebuild)
    refreshPending = true
    rebuildPending = rebuildPending or rebuild
    if refreshQueued then
        return
    end
    refreshQueued = true
    C_Timer.After(0, function()
        refreshQueued = false
        refresh()
    end)
end

local function queueCategoryRefresh()
    if installed and (layoutMode == "CATEGORY" or (rebuildPending and options.layoutMode == "CATEGORY")) then
        layoutPending = true
        if categoryTimer then
            categoryTimer:Cancel()
            categoryTimer = nil
        end
        if combined:IsShown() then
            categoryTimer = C_Timer.NewTimer(0.25, function()
                categoryTimer = nil
                queueRefresh()
            end)
        else
            categoryLayout = nil
            if rebuildPending then
                queueRefresh()
            end
        end
    end
end

local function registerOptions()
    local category = Settings.RegisterVerticalLayoutCategory("L7 Actually Combine Bags")
    local function toggle(key, name, tooltip, rebuild)
        local setting = Settings.RegisterProxySetting(
            category, "L7ActuallyCombineBags_" .. key, Settings.VarType.Boolean, name, defaults[key],
            function() return options[key] end,
            function(value)
                options[key] = value
                queueRefresh(rebuild)
            end
        )
        Settings.CreateCheckbox(category, setting, tooltip)
    end
    toggle("mergeReagent", "Merge reagent bag",
        "Include reagent bag slots when native combined bags are enabled. Changes apply after combat.", true)
    toggle("colorReagent", "Colour reagent slot backgrounds",
        "Give reagent slots a blue background in the combined bag window.")
    toggle("mergeKeyring", "Merge keyring",
        "Include keyring slots when native combined bags and the keyring are enabled. Changes apply after combat.", true)
    toggle("colorKeyring", "Colour keyring slot backgrounds",
        "Give keyring slots a gold background in the combined bag window.")
    toggle("keepKeyringTogether", "Keep keyring together",
        "When keyring merging is enabled, keep filled and empty keyring slots together at the bottom of category mode. Changes apply after combat.", true)
    toggle("separateSetGear", "Separate equipment set gear",
        "In category mode, put weapons and armour saved in an equipment set on separate rows from other gear. Changes apply after combat.", true)
    modeSetting = Settings.RegisterProxySetting(
        category, "L7ActuallyCombineBags_layoutMode", Settings.VarType.String, "Layout mode", defaults.layoutMode,
        function() return options.layoutMode end,
        function(value)
            options.layoutMode = value
            queueRefresh()
        end
    )
    local function modeChoices()
        local choices = Settings.CreateControlTextContainer()
        choices:Add("BAG", "Bag mode")
        choices:Add("CATEGORY", "Category mode")
        return choices:GetData()
    end
    Settings.CreateDropdown(category, modeSetting, modeChoices,
        "Use bag slot order, or start a new row for each item category. Changes apply after combat or after placing a held item.")
    local width = Settings.RegisterProxySetting(
        category, "L7ActuallyCombineBags_columns", Settings.VarType.Number, "Slots per row", defaults.columns,
        function() return options.columns end,
        function(value)
            options.columns = math.floor(math.max(minimumColumns, math.min(maximumColumns, value)) + 0.5)
            queueRefresh(true)
        end
    )
    local widthOptions = Settings.CreateSliderOptions(minimumColumns, maximumColumns, 1)
    widthOptions:SetLabelFormatter(MinimalSliderWithSteppersMixin.Label.Right, function(value) return string.format("%d", value) end)
    Settings.CreateSlider(category, width, widthOptions,
        "Choose the number of item slots across the combined bag in either layout mode. Changes apply after combat or after placing a held item.")
    local order = Settings.RegisterProxySetting(
        category, "L7ActuallyCombineBags_bagOrder", Settings.VarType.Number, "Bag order (top to bottom)", defaults.bagOrder,
        function() return options.bagOrder end,
        function(value)
            options.bagOrder = value
            queueRefresh(true)
        end
    )
    local function orderChoices()
        local choices = Settings.CreateControlTextContainer()
        for value, groups in ipairs(bagOrders) do
            local labels = {}
            for _, group in ipairs(groups) do
                labels[#labels + 1] = bagLabels[group]
            end
            choices:Add(value, table.concat(labels, " > "))
        end
        return choices:GetData()
    end
    Settings.CreateDropdown(category, order, orderChoices,
        "In bag mode, choose the order of merged bag slots from top to bottom. Unmerged bags are skipped. Changes apply after combat.")
    Settings.RegisterAddOnCategory(category)
end

local function supported()
    return ContainerFrameCombinedBags and ContainerFrameSettingsManager
        and type(ContainerFrameSettingsManager.IsUsingCombinedBags) == "function"
        and type(ContainerFrameCombinedBags.AcquireNewItemButton) == "function"
        and type(ContainerFrameCombinedBags.ClearItems) == "function"
        and type(ContainerFrame_GetContainerNumSlots) == "function"
        and type(ContainerFrameUtil_EnumerateContainerFrames) == "function"
        and C_Item and type(C_Item.GetItemInfoInstant) == "function"
        and type(C_Item.GetItemInfo) == "function" and type(C_Item.RequestLoadItemDataByID) == "function"
        and type(C_Item.DoesItemExist) == "function" and type(C_Item.GetItemGUID) == "function"
        and C_EquipmentSet and type(C_EquipmentSet.GetEquipmentSetIDs) == "function"
        and type(C_EquipmentSet.GetItemLocations) == "function" and type(C_EquipmentSet.GetIgnoredSlots) == "function"
        and type(EquipmentManager_GetLocationData) == "function"
        and ItemLocation and type(ItemLocation.CreateFromBagAndSlot) == "function"
        and type(ItemLocation.CreateFromEquipmentSlot) == "function"
        and Menu and type(Menu.ModifyMenu) == "function" and Enum and Enum.ItemClass
        and C_ActionBar and type(C_ActionBar.ShouldShowKeyring) == "function"
        and type(NUM_BAG_FRAMES) == "number" and type(NUM_TOTAL_BAG_FRAMES) == "number"
        and type(KEYRING_CONTAINER) == "number"
end

local function install()
    if installed or not options or not supported() then
        return
    end
    combined = ContainerFrameCombinedBags
    manager = ContainerFrameSettingsManager
    collectBags()

    combined.GetColumns = function()
        return columns
    end

    local setSearchBoxPoint = combined.SetSearchBoxPoint
    combined.SetSearchBoxPoint = function(self, searchBox)
        setSearchBoxPoint(self, searchBox)
        if not InputUtil.IsGamepadUIEnabled() then
            searchBox:SetWidth(self:CalculateWidth() - 100)
        end
    end

    combined.MatchesBagID = function(_, bagID)
        return not issecretvalue(bagID) and included[bagID] == true
    end

    combined.IsBagOpen = function(self, bagID)
        if self:IsShown() and self:MatchesBagID(bagID) then
            return bagID
        end
    end

    combined.GetContainedBagIDs = function(_, result)
        for _, bagID in ipairs(bagIDs) do
            result[#result + 1] = bagID
        end
    end

    combined.SetBagSize = function(self)
        local size, shown = 0, 0
        for _, bagID in ipairs(bagIDs) do
            local count = ContainerFrame_GetContainerNumSlots(bagID)
            size = size + count
            local bagButton = GamepadBagBar and GamepadBagBar:GetBagButton(bagID)
            if bagButton and not bagButton.isCollapsed then
                shown = shown + count
            end
        end
        self.size = size
        self.shownSlots = shown
    end

    combined.UpdateItemSlots = function(self)
        self:ClearItems()
        categoryLayout = nil
        slotCounts = {}
        for index = #bagIDs, 1, -1 do
            local bagID = bagIDs[index]
            local count = ContainerFrame_GetContainerNumSlots(bagID)
            slotCounts[bagID] = count
            local parent = bagParents[bagID]
            if not parent then
                parent = CreateFrame("Frame", nil, self)
                parent:SetID(bagID)
                parent:SetAllPoints(self)
                parent:SetFrameLevel(self:GetFrameLevel())
                bagParents[bagID] = parent
            end
            for slot = count, 1, -1 do
                local button = self:AcquireNewItemButton()
                button:SetParent(parent)
                button:Initialize(self, nil, slot)
                colorSlot(button)
            end
        end
    end

    local getRows = combined.GetRows
    combined.GetRows = function(self)
        if layoutMode == "CATEGORY" then
            return getCategoryLayout(self).rows
        end
        return getRows(self)
    end

    combined.UpdateItemLayout = function(self)
        if layoutMode == "CATEGORY" then
            if InputUtil.IsGamepadUIEnabled() then
                categoryLayout = nil
            end
            local data = getCategoryLayout(self)
            local nativeLayout = self:GetAnchorLayout()
            local _, relativeTo, relativePoint, x, y = self:GetInitialItemAnchor():Get()
            local template = C_XMLUtil.GetTemplateInfo(self.itemButtonPool:GetTemplate())
            local width = data.columns * template.width + (data.columns - 1) * nativeLayout.paddingX
            local height = data.rows * template.height + (data.rows - 1) * nativeLayout.paddingY
            local layout = AnchorUtil.CreateGridLayout(GridLayoutMixin.Direction.TopLeftToBottomRight,
                data.columns, nativeLayout.paddingX, nativeLayout.paddingY)
            for _, group in ipairs(data.groups) do
                local anchor = AnchorUtil.CreateAnchor("TOPLEFT", relativeTo, relativePoint,
                    x - width, y + height - group.row * (template.height + layout.paddingY))
                AnchorUtil.GridLayout(group.items, anchor, layout)
            end
            self:UpdateFrameSize()
        else
            local items = layoutItems(self)
            sortBagItems(items)
            AnchorUtil.GridLayout(items, self:GetInitialItemAnchor(), self:GetAnchorLayout())
        end
        self:LayoutAddSlots()
    end

    combined:HookScript("OnHide", function()
        categoryLayout = nil
        if categoryTimer then
            categoryTimer:Cancel()
            categoryTimer = nil
        end
    end)

    Menu.ModifyMenu("MENU_CONTAINER_FRAME_COMBINED", function(_, root)
        root:CreateDivider()
        root:CreateTitle("Layout")
        root:CreateRadio("Bag mode", function() return options.layoutMode == "BAG" end,
            function() modeSetting:SetValue("BAG") end)
        root:CreateRadio("Category mode", function() return options.layoutMode == "CATEGORY" end,
            function() modeSetting:SetValue("CATEGORY") end)
    end)

    local usingCombined = manager.IsUsingCombinedBags
    manager.IsUsingCombinedBags = function(self, bagID)
        if bagID and (reagentBag(bagID) or bagID == KEYRING_CONTAINER) then
            return usingCombined(self) and combined:MatchesBagID(bagID)
        end
        return usingCombined(self, bagID)
    end

    local toggleAllBags = ToggleAllBags
    ToggleAllBags = function(...)
        if not manager:IsUsingCombinedBags() then
            return toggleAllBags(...)
        end
        if not ContainerFrame_AllowedToOpenBags() then
            return
        end
        local allOpen = combined:IsShown()
        for bagID = NUM_BAG_FRAMES + 1, NUM_TOTAL_BAG_FRAMES do
            if not included[bagID] and ContainerFrame_GetContainerNumSlots(bagID) > 0
                and not IsBagOpen(bagID) then
                allOpen = false
            end
        end
        if allOpen then
            CloseAllBags()
        else
            if not included[KEYRING_CONTAINER] and IsBagOpen(KEYRING_CONTAINER) then
                CloseBag(KEYRING_CONTAINER)
            end
            OpenBackpack()
            for bagID = NUM_BAG_FRAMES + 1, NUM_TOTAL_BAG_FRAMES do
                if not included[bagID] then
                    OpenBag(bagID)
                end
            end
        end
    end

    installed = true
    queueRefresh(true)
end

driver:RegisterEvent("ADDON_LOADED")
driver:RegisterEvent("ADDON_ACTION_BLOCKED")
driver:RegisterEvent("ADDON_ACTION_FORBIDDEN")
driver:RegisterEvent("PLAYER_LOGIN")
driver:RegisterEvent("PLAYER_ENTERING_WORLD")
driver:RegisterEvent("PLAYER_LEVEL_UP")
driver:RegisterEvent("PLAYER_REGEN_ENABLED")
driver:RegisterEvent("BAG_UPDATE_DELAYED")
driver:RegisterEvent("ITEM_LOCK_CHANGED")
driver:RegisterEvent("EQUIPMENT_SETS_CHANGED")
driver:RegisterEvent("EQUIPMENT_SWAP_FINISHED")
driver:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
driver:RegisterEvent("ITEM_DATA_LOAD_RESULT")
driver:RegisterEvent("CURSOR_CHANGED")
driver:RegisterEvent("CVAR_UPDATE")
driver:RegisterEvent("USE_COMBINED_BAGS_CHANGED")
driver:RegisterEvent("MERCHANT_CLOSED")
driver:RegisterEvent("BANKFRAME_CLOSED")
driver:RegisterEvent("TRADE_CLOSED")
driver:SetScript("OnEvent", function(_, event, name, success)
    if event == "ADDON_LOADED" then
        if name == addonName then
            if type(L7ActuallyCombineBagsDB) ~= "table" then
                L7ActuallyCombineBagsDB = {}
            end
            options = L7ActuallyCombineBagsDB
            for key, default in pairs(defaults) do
                if type(options[key]) ~= type(default) then
                    options[key] = default
                end
            end
            if not bagOrders[options.bagOrder] then
                options.bagOrder = defaults.bagOrder
            end
            if options.layoutMode ~= "BAG" and options.layoutMode ~= "CATEGORY" then
                options.layoutMode = defaults.layoutMode
            end
            options.columns = math.floor(math.max(minimumColumns, math.min(maximumColumns, options.columns)) + 0.5)
            registerOptions()
        end
        install()
    elseif event == "ADDON_ACTION_BLOCKED" or event == "ADDON_ACTION_FORBIDDEN" then
        if name == addonName and options then
            local stack = debugstack(2)
            options.lastBlockedAction = {
                event = event,
                action = readable(success, "string") and success or "unavailable",
                stack = readable(stack, "string") and stack or "unavailable",
                version = C_AddOns.GetAddOnMetadata(addonName, "Version"),
                build = select(2, GetBuildInfo()),
                layoutMode = layoutMode,
                combat = InCombatLockdown(),
            }
            print("L7 Actually Combine Bags: blocked action " .. options.lastBlockedAction.action
                .. ". Use /l7bags error to show the saved report.")
        end
    elseif event == "PLAYER_LOGIN" then
        install()
        if not installed then
            print("L7 Actually Combine Bags: required native bag APIs are unavailable.")
        end
    elseif not installed then
        return
    elseif event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_LEVEL_UP" then
        queueRefresh(true)
    elseif event == "PLAYER_REGEN_ENABLED" then
        queueRefresh()
    elseif event == "USE_COMBINED_BAGS_CHANGED" then
        categoryLayout = nil
        queueRefresh(true)
    elseif event == "MERCHANT_CLOSED" or event == "BANKFRAME_CLOSED" or event == "TRADE_CLOSED" then
        if refreshPending or rebuildPending or layoutPending then
            queueRefresh()
        end
    elseif event == "CURSOR_CHANGED" then
        if refreshPending or rebuildPending or layoutPending then
            queueRefresh()
        end
    elseif event == "ITEM_DATA_LOAD_RESULT" then
        if readable(name, "number") and itemLoads[name] == "pending" then
            itemLoads[name] = success
            queueCategoryRefresh()
        end
    elseif event == "ITEM_LOCK_CHANGED" then
        if readable(name, "number") and included[name] then
            queueCategoryRefresh()
        end
    elseif event == "EQUIPMENT_SETS_CHANGED" or event == "EQUIPMENT_SWAP_FINISHED"
        or event == "PLAYER_EQUIPMENT_CHANGED" then
        equipmentDirty = true
        if separateSetGear then
            queueCategoryRefresh()
        end
    elseif event == "CVAR_UPDATE" then
        if not issecretvalue(name) and type(name) == "string" and name:lower() == "showkeyring" then
            queueRefresh(true)
        end
    elseif event == "BAG_UPDATE_DELAYED" and combined:IsShown() then
        equipmentDirty = true
        for _, bagID in ipairs(bagIDs) do
            if slotCounts[bagID] ~= ContainerFrame_GetContainerNumSlots(bagID) then
                queueRefresh(true)
                return
            end
        end
        queueCategoryRefresh()
    end
end)

SLASH_L7ACTUALLYCOMBINEBAGS1 = "/l7bags"
SlashCmdList.L7ACTUALLYCOMBINEBAGS = function(message)
    if message:match("^%s*error%s*$") then
        local report = options and options.lastBlockedAction
        if type(report) ~= "table" then
            print("L7 Actually Combine Bags: no blocked action has been recorded.")
            return
        end
        print("L7 Actually Combine Bags: " .. tostring(report.event) .. ", action " .. tostring(report.action)
            .. ", version " .. tostring(report.version) .. ", build " .. tostring(report.build)
            .. ", layout " .. tostring(report.layoutMode) .. ", combat " .. tostring(report.combat))
        print(report.stack or "Call stack unavailable.")
        return
    end
    if not installed then
        print("L7 Actually Combine Bags: not initialized.")
        return
    end
    local cursor = GetCursorInfo()
    print("L7 Actually Combine Bags: selected " .. options.layoutMode .. ", applied " .. layoutMode
        .. ", combined " .. tostring(manager:IsUsingCombinedBags())
        .. ", combat " .. tostring(InCombatLockdown())
        .. ", cursor " .. (readable(cursor, "string") and cursor or "empty/unavailable"))
    local count = 0
    local inspectBags = {}
    for bagID = 0, NUM_TOTAL_BAG_FRAMES do
        inspectBags[#inspectBags + 1] = bagID
    end
    if keyringAvailable() then
        inspectBags[#inspectBags + 1] = KEYRING_CONTAINER
    end
    for _, bagID in ipairs(inspectBags) do
        for slot = 1, ContainerFrame_GetContainerNumSlots(bagID) do
            local info = C_Container.GetContainerItemInfo(bagID, slot)
            if info and (issecretvalue(info.isLocked) or info.isLocked) then
                count = count + 1
                if count <= 10 then
                    local item = readable(info.hyperlink, "string") and info.hyperlink
                        or (readable(info.itemID, "number") and ("item " .. info.itemID)) or "item unavailable"
                    print("Bag " .. bagID .. ", slot " .. slot .. ": " .. item
                        .. (issecretvalue(info.isLocked) and " (lock status unavailable)" or " (locked)"))
                end
            end
        end
    end
    print("L7 Actually Combine Bags: " .. count .. " locked or unreadable slots."
        .. (count > 10 and " First 10 shown." or ""))
end
