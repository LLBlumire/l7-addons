local driver = CreateFrame("Frame")
local markers = {}
local members = {}
local dirty = true
local elapsedSinceUpdate = 0
local updateInterval = 0.1
local warned = false

local interactionFrames = {
    MERCHANT_SHOW = "MerchantFrame",
    BANKFRAME_OPENED = "BankFrame",
    TRADE_SHOW = "TradeFrame",
    AUCTION_HOUSE_SHOW = "AuctionHouseFrame",
    MAIL_SHOW = "MailFrame",
    GUILDBANKFRAME_OPENED = "GuildBankFrame",
}

local function hideMarkers()
    for _, marker in pairs(markers) do
        marker:Hide()
    end
end

local function readable(value, kind)
    return not issecretvalue(value) and type(value) == kind
end

local function itemGUID(location)
    local exists = C_Item.DoesItemExist(location)
    if not issecretvalue(exists) and exists then
        local guid = C_Item.GetItemGUID(location)
        if readable(guid, "string") and guid ~= "" then
            return guid
        end
    end
end

local function heldBag(bag)
    return readable(bag, "number") and bag >= 0 and bag <= NUM_TOTAL_EQUIPPED_BAG_SLOTS
end

local function rebuildMembers()
    members = {}
    for _, setID in ipairs(C_EquipmentSet.GetEquipmentSetIDs()) do
        local ignored = C_EquipmentSet.GetIgnoredSlots(setID) or {}
        for equipmentSlot, packed in pairs(C_EquipmentSet.GetItemLocations(setID) or {}) do
            if not ignored[equipmentSlot] and readable(packed, "number") and packed >= 0 then
                local data = EquipmentManager_GetLocationData(packed)
                local location
                if data.isBags and not data.isBank and heldBag(data.bag) and data.slot > 0 then
                    location = ItemLocation:CreateFromBagAndSlot(data.bag, data.slot)
                elseif data.isPlayer and not data.isBags and not data.isBank and data.slot > 0 then
                    location = ItemLocation:CreateFromEquipmentSlot(data.slot)
                end
                if location then
                    local guid = itemGUID(location)
                    if guid then
                        members[guid] = true
                    end
                end
            end
        end
    end
    dirty = false
end

local function showMarker(button)
    local marker = markers[button]
    if not marker then
        marker = button:CreateTexture(nil, "OVERLAY", nil, 7)
        marker:SetAtlas("bags-icon-equipment")
        marker:SetVertexColor(1, 0.15, 0.15)
        marker:SetSize(18, 18)
        marker:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 1, 1)
        markers[button] = marker
        button:HookScript("OnHide", function() marker:Hide() end)
    end
    marker:Show()
end

local function windowOpen()
    for _, name in pairs(interactionFrames) do
        local frame = _G[name]
        if frame and frame:IsShown() then
            return true
        end
    end
    return false
end

local function update(self, elapsed)
    elapsedSinceUpdate = elapsedSinceUpdate + elapsed
    if elapsedSinceUpdate < updateInterval then
        return
    end
    elapsedSinceUpdate = 0
    hideMarkers()
    if not windowOpen() then
        self:SetScript("OnUpdate", nil)
        members = {}
        return
    end
    if dirty then
        rebuildMembers()
    end
    if not next(members) then
        return
    end
    for _, container in ContainerFrameUtil_EnumerateContainerFrames() do
        if container:IsShown() then
            for _, button in container:EnumerateValidItems() do
                local bag, slot = button:GetBagID(), button:GetID()
                if button:IsShown() and heldBag(bag) and slot > 0 then
                    local guid = itemGUID(ItemLocation:CreateFromBagAndSlot(bag, slot))
                    if guid and members[guid] then
                        showMarker(button)
                    end
                end
            end
        end
    end
end

local function supported()
    return C_EquipmentSet and type(C_EquipmentSet.GetEquipmentSetIDs) == "function"
        and type(C_EquipmentSet.GetItemLocations) == "function"
        and type(C_EquipmentSet.GetIgnoredSlots) == "function"
        and type(EquipmentManager_GetLocationData) == "function"
        and C_Item and type(C_Item.DoesItemExist) == "function" and type(C_Item.GetItemGUID) == "function"
        and ItemLocation and type(ItemLocation.CreateFromBagAndSlot) == "function"
        and type(ItemLocation.CreateFromEquipmentSlot) == "function"
        and type(ContainerFrameUtil_EnumerateContainerFrames) == "function"
        and type(NUM_TOTAL_EQUIPPED_BAG_SLOTS) == "number"
end

driver:SetScript("OnEvent", function(self, event)
    dirty = true
    elapsedSinceUpdate = updateInterval
    hideMarkers()
    if event == "PLAYER_LEAVING_WORLD" then
        self:SetScript("OnUpdate", nil)
        members = {}
    elseif interactionFrames[event] or (event == "PLAYER_ENTERING_WORLD" and windowOpen()) then
        if supported() then
            self:SetScript("OnUpdate", update)
        elseif not warned then
            warned = true
            print("L7 Equipment Set Marker: required equipment-set or bag APIs are unavailable.")
        end
    end
end)

for event in pairs(interactionFrames) do
    driver:RegisterEvent(event)
end

for _, event in ipairs({
    "MERCHANT_CLOSED",
    "BANKFRAME_CLOSED",
    "TRADE_CLOSED",
    "AUCTION_HOUSE_CLOSED",
    "MAIL_CLOSED",
    "GUILDBANKFRAME_CLOSED",
    "PLAYER_ENTERING_WORLD",
    "PLAYER_LEAVING_WORLD",
    "BAG_UPDATE",
    "BAG_UPDATE_DELAYED",
    "BAG_CONTAINER_UPDATE",
    "PLAYER_EQUIPMENT_CHANGED",
    "EQUIPMENT_SETS_CHANGED",
    "EQUIPMENT_SWAP_FINISHED",
    "USE_COMBINED_BAGS_CHANGED",
}) do
    driver:RegisterEvent(event)
end
