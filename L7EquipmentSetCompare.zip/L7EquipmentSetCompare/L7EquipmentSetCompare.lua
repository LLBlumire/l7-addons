local _, addon = ...
local driver = CreateFrame("Frame")
local tooltips = setmetatable({}, {__mode = "k"})
local itemLoads = {}
local refreshQueued = false

local statOrder = {
    "ITEM_MOD_STRENGTH_SHORT",
    "ITEM_MOD_AGILITY_SHORT",
    "ITEM_MOD_STAMINA_SHORT",
    "ITEM_MOD_INTELLECT_SHORT",
    "ITEM_MOD_SPIRIT_SHORT",
    "ITEM_MOD_HEALTH_SHORT",
    "ITEM_MOD_MANA_SHORT",
    "RESISTANCE0_NAME",
    "ITEM_MOD_ATTACK_POWER_SHORT",
    "ITEM_MOD_RANGED_ATTACK_POWER_SHORT",
    "ITEM_MOD_SPELL_DAMAGE_DONE_SHORT",
    "ITEM_MOD_SPELL_HEALING_DONE_SHORT",
    "L7_MAIN_HAND_DPS",
    "L7_OFF_HAND_DPS",
    "L7_RANGED_DPS",
    "L7_MAIN_HAND_DAMAGE",
    "L7_OFF_HAND_DAMAGE",
    "L7_RANGED_DAMAGE",
}
local statRanks = {}
for index, key in ipairs(statOrder) do
    statRanks[key] = index
end

local weaponStats = {
    [16] = "L7_MAIN_HAND_DPS",
    [17] = "L7_OFF_HAND_DPS",
    [18] = "L7_RANGED_DPS",
}
local weaponDamageStats = {
    [16] = "L7_MAIN_HAND_DAMAGE",
    [17] = "L7_OFF_HAND_DAMAGE",
    [18] = "L7_RANGED_DAMAGE",
}
local statLabels = {
    L7_MAIN_HAND_DPS = "Main-hand DPS",
    L7_OFF_HAND_DPS = "Off-hand DPS",
    L7_RANGED_DPS = "Ranged DPS",
    L7_MAIN_HAND_DAMAGE = "Main-hand damage",
    L7_OFF_HAND_DAMAGE = "Off-hand damage",
    L7_RANGED_DAMAGE = "Ranged damage",
}
local ratingTypes = {
    ITEM_MOD_HIT_RATING_SHORT = "CR_HIT_MELEE",
    ITEM_MOD_HIT_MELEE_RATING_SHORT = "CR_HIT_MELEE",
    ITEM_MOD_HIT_RANGED_RATING_SHORT = "CR_HIT_RANGED",
    ITEM_MOD_HIT_SPELL_RATING_SHORT = "CR_HIT_SPELL",
    ITEM_MOD_CRIT_RATING_SHORT = "CR_CRIT_MELEE",
    ITEM_MOD_CRIT_MELEE_RATING_SHORT = "CR_CRIT_MELEE",
    ITEM_MOD_CRIT_RANGED_RATING_SHORT = "CR_CRIT_RANGED",
    ITEM_MOD_CRIT_SPELL_RATING_SHORT = "CR_CRIT_SPELL",
    ITEM_MOD_HASTE_RATING_SHORT = "CR_HASTE_MELEE",
    ITEM_MOD_HASTE_MELEE_RATING_SHORT = "CR_HASTE_MELEE",
    ITEM_MOD_HASTE_RANGED_RATING_SHORT = "CR_HASTE_RANGED",
    ITEM_MOD_HASTE_SPELL_RATING_SHORT = "CR_HASTE_SPELL",
    ITEM_MOD_EXPERTISE_RATING_SHORT = "CR_EXPERTISE",
    ITEM_MOD_DODGE_RATING_SHORT = "CR_DODGE",
    ITEM_MOD_PARRY_RATING_SHORT = "CR_PARRY",
    ITEM_MOD_BLOCK_RATING_SHORT = "CR_BLOCK",
}

local function readable(value, kind)
    return not issecretvalue(value) and type(value) == kind
end

local function ratingBonus(key, value)
    local rating = ratingTypes[key] and _G[ratingTypes[key]]
    if not readable(rating, "number") then
        return nil
    end
    if type(GetCombatRatingBonusForCombatRatingValue) == "function" then
        local ok, bonus = pcall(GetCombatRatingBonusForCombatRatingValue, rating, math.abs(value))
        if ok and readable(bonus, "number") and bonus > 0 then
            return value < 0 and -bonus or bonus
        end
    end
    if type(GetCombatRating) == "function" and type(GetCombatRatingBonus) == "function" then
        local okRating, points = pcall(GetCombatRating, rating)
        local okBonus, bonus = pcall(GetCombatRatingBonus, rating)
        if okRating and okBonus and readable(points, "number") and readable(bonus, "number") and points > 0 and bonus > 0 then
            return value * bonus / points
        end
    end
end

local function statLabel(key, percent)
    local label = statLabels[key] or _G[key]
    if not readable(label, "string") then
        label = key:gsub("^ITEM_MOD_", ""):gsub("_SHORT$", ""):gsub("_", " "):lower()
        label = label:gsub("^%l", string.upper)
    end
    if not percent and key:match("_RATING_SHORT$") and key ~= "ITEM_MOD_DEFENSE_SKILL_RATING_SHORT" then
        label = label .. " (rating)"
    end
    return label
end

local function requestItem(location)
    local id = C_Item.GetItemID(location)
    if readable(id, "number") and itemLoads[id] == nil then
        itemLoads[id] = "pending"
        C_Item.RequestLoadItemData(location)
    end
    if readable(id, "number") and itemLoads[id] == "failed" then
        return nil, "Item data could not be loaded."
    end
    return nil, "Loading item data..."
end

local function itemLink(location, expectedID)
    local exists = C_Item.DoesItemExist(location)
    if not readable(exists, "boolean") then
        return nil, "Item data is unavailable."
    end
    if not exists then
        if expectedID then
            return nil, "A saved item is unavailable. Put it in your bags."
        end
        return false
    end
    if expectedID then
        local id = C_Item.GetItemID(location)
        if not readable(id, "number") or id ~= expectedID then
            return nil, "Equipment is moving. Try again when it has finished."
        end
    end
    local cached = C_Item.IsItemDataCached(location)
    if not readable(cached, "boolean") or not cached then
        return requestItem(location)
    end
    local link = C_Item.GetItemLink(location)
    if not readable(link, "string") or link == "" then
        return requestItem(location)
    end
    return link
end

local function savedItemLink(packed, id)
    if not readable(packed, "number") then
        return nil, "Equipment-set data is unavailable."
    end
    if packed == 0 then
        return false
    end
    if packed < 0 then
        return nil, "A saved item is missing. Put it in your bags."
    end
    if not readable(id, "number") or id <= 1 then
        return nil, "Equipment-set item data is unavailable."
    end
    local data = EquipmentManager_GetLocationData(packed)
    if data.isBank then
        return nil, "Move saved items from the bank into your bags to compare."
    end
    if not readable(data.slot, "number") or data.slot <= 0 then
        return nil, "Equipment-set item locations are unavailable."
    end
    local location
    if data.isBags and readable(data.bag, "number")
        and data.bag >= 0 and data.bag <= NUM_TOTAL_EQUIPPED_BAG_SLOTS then
        location = ItemLocation:CreateFromBagAndSlot(data.bag, data.slot)
    elseif data.isPlayer and not data.isBags then
        location = ItemLocation:CreateFromEquipmentSlot(data.slot)
    end
    if not location then
        return nil, "A saved item is unavailable. Put it in your bags."
    end
    return itemLink(location, id)
end

local function equipmentLinks(setID)
    local ignored = C_EquipmentSet.GetIgnoredSlots(setID)
    local locations = C_EquipmentSet.GetItemLocations(setID)
    local ids = C_EquipmentSet.GetItemIDs(setID)
    if not readable(ignored, "table") or not readable(locations, "table") or not readable(ids, "table") then
        return nil, "Equipment-set data is unavailable."
    end
    local current, target = {}, {}
    for slot = 1, 19 do
        local packed, id, skip = locations[slot], ids[slot], ignored[slot]
        if issecretvalue(packed) or issecretvalue(id) or issecretvalue(skip) then
            return nil, "Equipment-set data is unavailable."
        end
        if skip or packed == 1 then
            current[slot], target[slot] = false, false
        else
            local link, message = itemLink(ItemLocation:CreateFromEquipmentSlot(slot))
            if link == nil then
                return nil, message
            end
            current[slot] = link
            if packed == nil and id == nil then
                packed = 0
            end
            target[slot], message = savedItemLink(packed, id)
            if target[slot] == nil then
                return nil, message
            end
        end
    end
    if target[16] and (ignored[17] or locations[17] == 1) then
        local _, _, _, equipLocation = C_Item.GetItemInfoInstant(target[16])
        if readable(equipLocation, "string") and equipLocation == "INVTYPE_2HWEAPON" then
            local link, message = itemLink(ItemLocation:CreateFromEquipmentSlot(17))
            if link == nil then
                return nil, message
            end
            current[17] = link
            target[17] = false
        end
    end
    return current, target
end

local function addStats(totals, stats, sign, slot)
    for key, value in pairs(stats) do
        if key == "ITEM_MOD_DAMAGE_PER_SECOND_SHORT" and weaponStats[slot] then
            key = weaponStats[slot]
        elseif key == "L7_WEAPON_DAMAGE" and weaponDamageStats[slot] then
            key = weaponDamageStats[slot]
        end
        totals[key] = (totals[key] or 0) + value * sign
    end
end

local function compare(setID)
    local current, target = equipmentLinks(setID)
    if not current then
        return nil, target
    end
    local totals, effects = {}, {}
    local changed = false
    for slot = 1, 19 do
        if current[slot] ~= target[slot] then
            changed = true
            local before, beforeEffects = addon.GetItemStats(current[slot])
            local after, afterEffects = addon.GetItemStats(target[slot])
            if not before or not after then
                return nil, "Item stats are unavailable. Try again after item data has loaded."
            end
            addStats(totals, before, -1, slot)
            addStats(totals, after, 1, slot)
            for text, count in pairs(beforeEffects) do
                effects[text] = (effects[text] or 0) - count
            end
            for text, count in pairs(afterEffects) do
                effects[text] = (effects[text] or 0) + count
            end
        end
    end
    local changes = {}
    for key, value in pairs(totals) do
        local bonus = ratingBonus(key, value)
        value = bonus or value
        if math.abs(value) >= 0.005 then
            changes[#changes + 1] = {key = key, label = statLabel(key, bonus ~= nil), value = value, percent = bonus ~= nil}
        end
    end
    for text, count in pairs(effects) do
        if count ~= 0 then
            changes[#changes + 1] = {key = "L7_ENCHANT_" .. text, label = "Enchant: " .. text, value = count, enchant = true}
        end
    end
    table.sort(changes, function(left, right)
        local leftRank = left.enchant and 200 or statRanks[left.key] or 100
        local rightRank = right.enchant and 200 or statRanks[right.key] or 100
        if leftRank ~= rightRank then
            return leftRank < rightRank
        end
        if left.label ~= right.label then
            return left.label < right.label
        end
        return left.key < right.key
    end)
    return changes, changed and "No item-stat changes." or "Already equipped."
end

local function resolveSetID(value)
    if readable(value, "string") then
        value = C_EquipmentSet.GetEquipmentSetID(value)
    end
    if readable(value, "number") then
        local name = C_EquipmentSet.GetEquipmentSetInfo(value)
        if readable(name, "string") then
            return value
        end
    end
end

local function tooltipSetID(tooltip, data)
    local info = tooltip:GetProcessingTooltipInfo()
    if info and info.getterArgs and not issecretvalue(info.getterArgs[1]) then
        if info.getterName == "GetAction" then
            local kind, id = GetActionInfo(info.getterArgs[1])
            if readable(kind, "string") and kind == "equipmentset" then
                local setID = resolveSetID(id)
                if setID then
                    return setID
                end
            end
        elseif info.getterName == "GetEquipmentSet" then
            return resolveSetID(info.getterArgs[1])
        end
    end
    return resolveSetID(data.id)
end

local function addComparison(tooltip, data)
    local setID = tooltipSetID(tooltip, data)
    if not setID then
        return
    end
    tooltips[tooltip] = true
    local changes, message = compare(setID)
    tooltip:AddLine(" ")
    tooltip:AddLine("Item stat changes", 1, 0.82, 0)
    if not changes then
        tooltip:AddLine(message, 1, 0.4, 0.2, true)
        return
    end
    if #changes == 0 then
        tooltip:AddLine(message, 0.8, 0.8, 0.8)
    else
        for _, change in ipairs(changes) do
            local value = string.format("%+.2f", change.value):gsub("(%..-)0+$", "%1"):gsub("%.$", "")
            if change.percent then
                value = value .. "%"
            end
            if change.enchant and change.value > 0 then
                tooltip:AddLine(value .. " " .. change.label, 0.2, 1, 0.2, true)
            elseif change.enchant then
                tooltip:AddLine(value .. " " .. change.label, 1, 0.2, 0.2, true)
            elseif change.value > 0 then
                tooltip:AddDoubleLine(change.label, value, 1, 1, 1, 0.2, 1, 0.2)
            else
                tooltip:AddDoubleLine(change.label, value, 1, 1, 1, 1, 0.2, 0.2)
            end
        end
    end
end

local function supported()
    return TooltipDataProcessor and type(TooltipDataProcessor.AddTooltipPostCall) == "function"
        and Enum and Enum.TooltipDataType and type(Enum.TooltipDataType.EquipmentSet) == "number"
        and Enum.TooltipDataLineType and type(Enum.TooltipDataLineType.ItemEnchantmentPermanent) == "number"
        and C_TooltipInfo and type(C_TooltipInfo.GetHyperlink) == "function"
        and C_EquipmentSet and type(C_EquipmentSet.GetEquipmentSetID) == "function"
        and type(C_EquipmentSet.GetEquipmentSetInfo) == "function"
        and type(C_EquipmentSet.GetIgnoredSlots) == "function"
        and type(C_EquipmentSet.GetItemLocations) == "function" and type(C_EquipmentSet.GetItemIDs) == "function"
        and C_Item and type(C_Item.GetItemStats) == "function" and type(C_Item.GetItemLink) == "function"
        and type(C_Item.GetItemID) == "function" and type(C_Item.DoesItemExist) == "function"
        and type(C_Item.IsItemDataCached) == "function" and type(C_Item.RequestLoadItemData) == "function"
        and type(C_Item.GetItemInfoInstant) == "function"
        and ItemLocation and type(ItemLocation.CreateFromEquipmentSlot) == "function"
        and type(ItemLocation.CreateFromBagAndSlot) == "function"
        and type(EquipmentManager_GetLocationData) == "function" and type(GetActionInfo) == "function"
        and type(NUM_TOTAL_EQUIPPED_BAG_SLOTS) == "number" and type(issecretvalue) == "function"
        and C_Timer and type(C_Timer.After) == "function"
end

driver:SetScript("OnEvent", function(self, event, id, success)
    if event == "PLAYER_LOGIN" then
        self:UnregisterEvent(event)
        if not supported() then
            print("L7 Equipment Set Compare: required equipment-set or tooltip APIs are unavailable.")
            return
        end
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.EquipmentSet, addComparison)
        for _, name in ipairs({
            "PLAYER_ENTERING_WORLD",
            "PLAYER_EQUIPMENT_CHANGED",
            "EQUIPMENT_SETS_CHANGED",
            "EQUIPMENT_SWAP_FINISHED",
            "BAG_UPDATE_DELAYED",
            "ITEM_DATA_LOAD_RESULT",
        }) do
            self:RegisterEvent(name)
        end
        return
    end
    addon.ClearStatCache()
    if event == "ITEM_DATA_LOAD_RESULT" then
        if readable(id, "number") and not issecretvalue(success) and itemLoads[id] then
            itemLoads[id] = success and "loaded" or "failed"
        end
    else
        itemLoads = {}
    end
    if refreshQueued then
        return
    end
    refreshQueued = true
    C_Timer.After(0, function()
        refreshQueued = false
        for tooltip in pairs(tooltips) do
            local data = tooltip:GetPrimaryTooltipData()
            if tooltip:IsShown() and data and not issecretvalue(data.type)
                and data.type == Enum.TooltipDataType.EquipmentSet then
                tooltip:RebuildFromTooltipInfo()
            else
                tooltips[tooltip] = nil
            end
        end
    end)
end)

driver:RegisterEvent("PLAYER_LOGIN")
