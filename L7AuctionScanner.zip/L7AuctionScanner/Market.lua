local _, addon = ...

addon.markets = {Alliance = "Alliance", Horde = "Horde", Neutral = "Blackwater"}

local auctioneers = {
    [8661] = "Neutral", [9857] = "Neutral", [9858] = "Neutral",
    [15677] = "Neutral", [15681] = "Neutral",
    [258878] = "Neutral",
    [8669] = "Alliance", [8670] = "Alliance", [8671] = "Alliance",
    [8719] = "Alliance", [8720] = "Alliance", [8723] = "Alliance", [9859] = "Alliance",
    [15659] = "Alliance", [15678] = "Alliance", [15679] = "Alliance",
    [8672] = "Horde", [8673] = "Horde", [8674] = "Horde",
    [8721] = "Horde", [8722] = "Horde", [8724] = "Horde", [9856] = "Horde",
    [15675] = "Horde", [15676] = "Horde", [15682] = "Horde",
    [15683] = "Horde", [15684] = "Horde", [15686] = "Horde",
}

function addon.Readable(value, kind)
    return not (issecretvalue and issecretvalue(value)) and type(value) == kind
end

function addon.Now()
    return GetServerTime()
end

function addon.FormatAge(timestamp)
    local seconds = math.max(0, math.floor(addon.Now() - timestamp))
    local count, unit
    if seconds < 60 then
        count, unit = seconds, "second"
    elseif seconds < 3600 then
        count, unit = math.floor(seconds / 60), "minute"
    elseif seconds < 86400 then
        count, unit = math.floor(seconds / 3600), "hour"
    else
        count, unit = math.floor(seconds / 86400), "day"
    end
    return count .. " " .. unit .. (count == 1 and "" or "s") .. " ago"
end

function addon.Context()
    local region = GetCurrentRegion()
    local mode = C_GameRules.GetCurrentGameModeRecordID()
    if not addon.Readable(region, "number") or region <= 0 or not addon.Readable(mode, "number") then
        return
    end
    return region .. ":" .. mode
end

function addon.DetectMarket()
    local guid = UnitGUID("npc")
    if addon.Readable(guid, "string") then
        local id = tonumber(guid:match("^Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-"))
        if auctioneers[id] then
            return auctioneers[id], guid
        end
    end
    local faction = UnitFactionGroup("npc")
    if addon.Readable(faction, "string") and addon.markets[faction] then
        return faction, guid
    end
end

function addon.ItemKey(link)
    if not addon.Readable(link, "string") then
        return
    end
    local item = link:match("item:([%d:%-]+)")
    if not item then
        return
    end
    local id, _, _, _, _, _, suffix = strsplit(":", item)
    id = tonumber(id)
    suffix = tonumber(suffix) or 0
    if id and id > 0 then
        return id .. ":" .. suffix, id
    end
end

function addon.SelectedMarket()
    return addon.options.market
end

function addon.Snapshot(market, context)
    context = context or addon.Context()
    if not context then
        return
    end
    market = market or addon.SelectedMarket()
    local stores = addon.db.contexts[context]
    if stores and stores[market] then
        return stores[market]
    end
    local prefix = context .. ":"
    local latest
    for key, legacyStores in pairs(addon.db.contexts) do
        if type(key) == "string" and key:sub(1, #prefix) == prefix and type(legacyStores) == "table" then
            local snapshot = legacyStores[market]
            if snapshot and (not latest or snapshot.scannedAt > latest.scannedAt) then
                latest = snapshot
            end
        end
    end
    return latest
end

function addon.Initialize()
    if type(L7AuctionScannerDB) ~= "table" then
        L7AuctionScannerDB = {}
    end
    if type(L7AuctionScannerDB.contexts) ~= "table" then
        L7AuctionScannerDB.contexts = {}
    end
    if type(L7AuctionScannerCharacterDB) ~= "table" then
        L7AuctionScannerCharacterDB = {}
    end
    addon.db = L7AuctionScannerDB
    addon.options = L7AuctionScannerCharacterDB
    if not addon.markets[addon.options.market] then
        local faction = UnitFactionGroup("player")
        addon.options.market = addon.markets[faction] and faction or "Alliance"
    end
    if type(addon.options.nextScanAt) ~= "number" then
        addon.options.nextScanAt = 0
    end
end

L7AuctionScanner = {}

function L7AuctionScanner.GetSelectedMarket()
    if addon.options then
        local market = addon.SelectedMarket()
        return market, addon.markets[market]
    end
end

function L7AuctionScanner.GetPrice(item, market)
    if not addon.db or (market and not addon.markets[market]) then
        return
    end
    local snapshot = addon.Snapshot(market)
    if not snapshot then
        return
    end
    local price
    if addon.Readable(item, "number") then
        price = snapshot.prices[item]
    else
        local key = addon.ItemKey(item)
        price = key and snapshot.variants[key]
    end
    return price, snapshot.scannedAt, market or addon.SelectedMarket()
end
