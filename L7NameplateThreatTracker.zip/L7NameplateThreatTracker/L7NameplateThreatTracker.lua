local addonName = ...
local plates = {}
local labels = {}
local barStates = setmetatable({}, {__mode = "k"})
local pendingBarRepaints = {}
local pendingThreatUpdates = {}
local pendingThreatAll = false
local driver = CreateFrame("Frame")
local elapsedSinceUpdate = 0

local defaults = {
    colorNumber = false,
    colorPetNumber = false,
    colorNameplate = false,
    nameplateSource = "PLAYER",
    useGroupRole = true,
    fallbackStyle = "DPS",
    petStyle = "DPS",
    position = "LEFT",
}
local options = defaults

local white = {1, 1, 1}
local green = {0, 1, 0}
local orange = {1, 0.5, 0}
local yellow = {1, 1, 0}
local red = {1, 0, 0}
local palettes = {
    DPS = {[0] = green, [1] = orange, [2] = yellow, [3] = red},
    TANK = {[0] = red, [1] = yellow, [2] = orange, [3] = green},
}
local concerns = {
    DPS = {[0] = 0, [1] = 2, [2] = 1, [3] = 3},
    TANK = {[0] = 3, [1] = 1, [2] = 2, [3] = 0},
}
local nameplateSources = {PLAYER = true, PET = true, AGGRO = true, CONCERN = true}

local function activePet()
    local ok, exists = pcall(UnitExists, "pet")
    if not ok or issecretvalue(exists) or not exists then
        return false
    end
    local deadOk, dead = pcall(UnitIsDeadOrGhost, "pet")
    return deadOk and not issecretvalue(dead) and not dead
end

local function activeStyle()
    if options.useGroupRole then
        local grouped = IsInGroup()
        if not issecretvalue(grouped) and grouped then
            local role = UnitGroupRolesAssigned("player")
            if not issecretvalue(role) then
                if role == "TANK" then
                    return "TANK"
                elseif role == "DAMAGER" or role == "HEALER" then
                    return "DPS"
                end
            end
        end
    end
    return options.fallbackStyle
end

local function accessible(region)
    if issecretvalue(region) or not region then
        return false
    end
    local ok, result = pcall(function()
        if region.IsForbidden then
            local forbidden = region:IsForbidden()
            if issecretvalue(forbidden) or forbidden then
                return false
            end
        end
        if region.CanBeAccessedInContext then
            local allowed = region:CanBeAccessedInContext()
            return not issecretvalue(allowed) and allowed == true
        end
        return true
    end)
    return ok and result == true
end

local function setBarColor(bar, state, r, g, b, a)
    state.painting = true
    local ok = pcall(function() bar:SetStatusBarColor(r, g, b, a) end)
    state.painting = false
    return ok
end

local function healthBar(frame)
    local ok, bar, alternate, container = pcall(function()
        return frame.healthBar, frame.HealthBar, frame.HealthBarsContainer
    end)
    if not ok or issecretvalue(bar) then
        return
    end
    if bar then
        return bar
    end
    if issecretvalue(alternate) then
        return
    end
    if alternate then
        return alternate
    end
    if not accessible(container) then
        return
    end
    local found, contained = pcall(function() return container.healthBar end)
    if found and not issecretvalue(contained) then
        return contained
    end
end

local function barState(bar)
    local state = barStates[bar]
    if state then
        return state
    end

    local ok, r, g, b, a = pcall(function() return bar:GetStatusBarColor() end)
    state = {hasOriginal = ok, r = r, g = g, b = b, a = a}
    barStates[bar] = state
    pcall(hooksecurefunc, bar, "SetStatusBarColor", function(target, newR, newG, newB, newA)
        if state.painting then
            return
        end
        state.hasOriginal = true
        state.r, state.g, state.b, state.a = newR, newG, newB, newA
        local entry = state.owner
        local unit = entry and entry.barUnit
        if not issecretvalue(unit) and type(unit) == "string" then
            pendingBarRepaints[unit] = entry
        end
    end)
    return state
end

local function ownsBar(entry)
    local frame, unit = entry.barFrame, entry.barUnit
    if issecretvalue(frame) or not frame or issecretvalue(unit) or type(unit) ~= "string" then
        return false
    end
    local ok, currentUnit = pcall(function() return frame.unit end)
    return ok and not issecretvalue(currentUnit) and currentUnit == unit
end

local function observeNativeColor(entry)
    local bar = entry.bar
    if not accessible(bar) or not ownsBar(entry) then
        return
    end
    local state = barStates[bar]
    if not state or state.owner ~= entry then
        return
    end
    local ok, r, g, b, a = pcall(function() return bar:GetStatusBarColor() end)
    if ok then
        state.hasOriginal = true
        state.r, state.g, state.b, state.a = r, g, b, a
    end
end

local nativeColorHooked = false
local function hookNativeColor()
    if nativeColorHooked then
        return true
    end
    if type(CompactUnitFrame_UpdateHealthColor) ~= "function" then
        return false
    end
    local ok = pcall(hooksecurefunc, "CompactUnitFrame_UpdateHealthColor", function(frame)
        if not accessible(frame) then
            return
        end
        local bar = healthBar(frame)
        if not accessible(bar) then
            return
        end
        local state = barStates[bar]
        local entry = state and state.owner
        if not entry or entry.barFrame ~= frame or not ownsBar(entry) then
            return
        end
        observeNativeColor(entry)
        local unit = entry.barUnit
        if not issecretvalue(unit) and type(unit) == "string" then
            pendingBarRepaints[unit] = entry
        end
    end)
    nativeColorHooked = ok
    return ok
end

local function clearBar(entry)
    local unit = entry.barUnit
    if not issecretvalue(unit) and type(unit) == "string" and pendingBarRepaints[unit] == entry then
        pendingBarRepaints[unit] = nil
    end
    local bar = entry.bar
    if issecretvalue(bar) or not bar then
        entry.bar = nil
        entry.barFrame = nil
        entry.barUnit = nil
        entry.color = nil
        return
    end
    local state = barStates[bar]
    if state and state.owner == entry then
        state.owner = nil
    end
    entry.bar = nil
    if state and state.hasOriginal and accessible(bar) and ownsBar(entry) then
        setBarColor(bar, state, state.r, state.g, state.b, state.a)
    end
    entry.barFrame = nil
    entry.barUnit = nil
    entry.color = nil
end

local function colorBar(unit, entry, frame, bar, color, available)
    if not options.colorNameplate or not available then
        clearBar(entry)
        return
    end
    if not accessible(bar) or not hookNativeColor() then
        clearBar(entry)
        return
    end
    if issecretvalue(entry.bar) then
        clearBar(entry)
    elseif entry.bar and (entry.bar ~= bar or entry.barFrame ~= frame or entry.barUnit ~= unit) then
        clearBar(entry)
    end
    local state = barState(bar)
    entry.bar = bar
    entry.barFrame = frame
    entry.barUnit = unit
    entry.color = color
    local ok, r, g, b, a = pcall(function() return bar:GetStatusBarColor() end)
    if state.owner ~= entry then
        state.hasOriginal = ok
        if ok then
            state.r, state.g, state.b, state.a = r, g, b, a
        end
    end
    state.owner = entry
    if not ok or issecretvalue(r) or issecretvalue(g) or issecretvalue(b)
        or type(r) ~= "number" or type(g) ~= "number" or type(b) ~= "number"
        or r ~= color[1] or g ~= color[2] or b ~= color[3] then
        setBarColor(bar, state, color[1], color[2], color[3], state.a)
    end
end

local function releaseLabel(entry, key)
    local label = entry[key]
    if not label then
        return
    end
    label:SetText("")
    label:Hide()
    label:ClearAllPoints()
    label:SetParent(UIParent)
    labels[#labels + 1] = label
    entry[key] = nil
    if key == "petLabel" then
        entry.petAnchor = nil
        entry.petPosition = nil
    end
end

local function clearLabel(entry)
    releaseLabel(entry, "petLabel")
    releaseLabel(entry, "label")
    entry.baseAnchor = nil
    entry.position = nil
    entry.layoutDirty = true
    entry.layoutRetry = nil
end

local function clear(unit)
    local entry = plates[unit]
    if entry then
        clearBar(entry)
        clearLabel(entry)
    end
end

local function publicNumber(value)
    return not issecretvalue(value) and type(value) == "number"
end

local function visibility(region)
    if not accessible(region) then
        return
    end
    local method = region.IsVisible or region.IsShown
    local ok, shown = pcall(method, region)
    if ok and not issecretvalue(shown) and type(shown) == "boolean" then
        return shown
    end
end

local function visible(region)
    return visibility(region) == true
end

local function rect(region)
    if not accessible(region) then
        return
    end
    local ok, left, bottom, width, height = pcall(region.GetRect, region)
    if not ok or not publicNumber(left) or not publicNumber(bottom)
        or not publicNumber(width) or not publicNumber(height) then
        return
    end
    local scaleOk, scale = pcall(region.GetEffectiveScale, region)
    if not scaleOk or not publicNumber(scale) or scale <= 0 then
        return
    end
    return left * scale, bottom * scale, width * scale, height * scale
end

local function point(region)
    if not accessible(region) then
        return
    end
    local ok, ownPoint, relative, relativePoint, x, y = pcall(region.GetPoint, region, 1)
    if not ok or issecretvalue(ownPoint) or issecretvalue(relative) or issecretvalue(relativePoint)
        or not publicNumber(x) or not publicNumber(y) then
        return
    end
    return ownPoint, relative, relativePoint, x, y
end

local function markerWidth(region, fallback)
    local ok, width = pcall(region.GetWidth, region)
    if not ok or not publicNumber(width) or width <= 0 then
        width = fallback
    end
    local scaleOk, scale = pcall(region.GetScale, region)
    if scaleOk and publicNumber(scale) and scale > 0 then
        width = width * scale
    end
    return width
end

local function markerAnchor(frame, anchor, side)
    local level = frame.PlayerLevelDiffFrame
    local _, _, levelSide = point(level)
    if side == "RIGHT" then
        if visible(level) and (type(levelSide) ~= "string" or levelSide:find("RIGHT", 1, true)) then
            return level, 0
        end
        return anchor, 0
    end

    local classification = frame.ClassificationFrame
    local raid = frame.RaidTargetFrame
    local reserve = 0
    if visible(level) and type(levelSide) == "string" and levelSide:find("LEFT", 1, true) then
        reserve = reserve + markerWidth(level, 15)
    end
    if visible(raid) then
        reserve = reserve + markerWidth(raid, 22)
    end
    if visible(classification) then
        reserve = reserve + markerWidth(classification, 20)
        return classification, reserve
    end
    if visible(raid) then
        return raid, reserve
    end
    if reserve > 0 then
        return level, reserve
    end
    return anchor, 0
end

local function nearbyIcons(plate, frame)
    local icons = {}
    local function scan(parent, questie)
        if not accessible(parent) or not parent.GetChildren then
            return
        end
        local ok, children = pcall(function() return {parent:GetChildren()} end)
        if not ok then
            return
        end
        local found = false
        for _, child in ipairs(children) do
            if not issecretvalue(child) and child ~= frame and visible(child) then
                local childOk, icon, lastIcon = pcall(function() return child.Icon, child.lastIcon end)
                if childOk and not issecretvalue(icon) and icon ~= nil
                    and (not questie or (not issecretvalue(lastIcon) and lastIcon ~= nil)) then
                    if questie then
                        icons[#icons + 1] = child
                    else
                        found = true
                    end
                end
            end
        end
        if found then
            icons[#icons + 1] = parent
            return parent
        end
    end
    if QuestieLoader then
        scan(plate, true)
    end
    local auras = frame.AurasFrame
    local leftAura, rightAura
    if accessible(auras) then
        leftAura = scan(auras.BuffListFrame, false)
        rightAura = scan(auras.CrowdControlListFrame, false)
    end
    return icons, leftAura, rightAura
end

local function placement(plate, frame, anchor, side)
    local target, reserve = markerAnchor(frame, anchor, side)
    local offset = side == "RIGHT" and 4 or -4
    local y = 0
    local barLeft, barBottom, barWidth, barHeight = rect(anchor)
    local targetLeft, targetBottom, targetWidth, targetHeight = rect(target)
    local scaleOk, scale = pcall(plate.GetEffectiveScale, plate)
    if not scaleOk or not publicNumber(scale) or scale <= 0 then
        scale = nil
    end

    if target ~= anchor and barBottom and targetBottom and scale then
        local barCenter = barBottom + barHeight / 2
        if targetBottom >= barCenter + 10 * scale or targetBottom + targetHeight <= barCenter - 10 * scale then
            target, reserve = anchor, 0
            targetLeft, targetBottom, targetWidth, targetHeight = barLeft, barBottom, barWidth, barHeight
        end
    end

    local edge
    if targetLeft and scale then
        edge = side == "RIGHT" and targetLeft + targetWidth or targetLeft
        if barBottom then
            y = (barBottom + barHeight / 2 - targetBottom - targetHeight / 2) / scale
        end
    end

    local incomplete = not (barLeft and targetLeft and scale)
    local icons, leftAura, rightAura = nearbyIcons(plate, frame)
    local fallbackAura = leftAura
    if side == "RIGHT" then
        fallbackAura = rightAura
    end
    local fallbackX
    local selectedExternal = false
    for _, icon in ipairs(icons) do
        local left, bottom, width, height = rect(icon)
        if left and (width <= 0 or height <= 0) then
            left = nil
        end
        if barLeft and left and edge and scale then
            local barCenter = barBottom + barHeight / 2
            local overlaps = bottom < barCenter + 10 * scale and bottom + height > barCenter - 10 * scale
            local iconEdge = side == "RIGHT" and left + width or left
            local isOutside = side == "RIGHT" and iconEdge > barLeft + barWidth or side == "LEFT" and iconEdge < barLeft
            local isFurther = side == "RIGHT" and iconEdge > edge or side == "LEFT" and iconEdge < edge
            if overlaps and isOutside and isFurther then
                target, edge = icon, iconEdge
                selectedExternal = icon ~= leftAura and icon ~= rightAura
                y = (barCenter - bottom - height / 2) / scale
                offset = side == "RIGHT" and 4 or -4
            end
        elseif icon == fallbackAura then
            if not selectedExternal then
                target, offset, y = icon, side == "RIGHT" and 4 or -4, 0
            end
            incomplete = true
        elseif side == "LEFT" then
            incomplete = true
            local ownPoint, relative, relativePoint, x = point(icon)
            if ownPoint == "LEFT" and relative == plate and relativePoint == "LEFT"
                and x < 0 and (not fallbackX or x < fallbackX) then
                target, fallbackX = icon, x
                selectedExternal = true
                offset, y = -4 - reserve, 0
            end
        else
            incomplete = true
        end
    end
    return target, offset, y, incomplete
end

local function threatData(actor, unit, style)
    local statusOk, status = pcall(UnitThreatSituation, actor, unit)
    local statusAvailable = statusOk and not issecretvalue(status)
    local data = {color = white, concern = -1, available = statusAvailable and status ~= nil}
    if statusAvailable and type(status) == "number" then
        data.color = palettes[style][status] or white
        data.concern = concerns[style][status] or -1
        data.tanking = status == 2 or status == 3
    end

    local ok, percentage = pcall(UnitThreatPercentageOfLead, actor, unit)
    data.hasNumber = ok and (issecretvalue(percentage) or type(percentage) == "number")
    if not data.hasNumber then
        return data
    end
    data.percentage = percentage
    data.formatString, data.value = "%.0f%%", percentage
    if not issecretvalue(percentage) and percentage == 0 and data.tanking then
        local threatOk, _, _, _, _, threat = pcall(UnitDetailedThreatSituation, actor, unit)
        if threatOk and (issecretvalue(threat) or (type(threat) == "number" and threat > 0)) then
            data.formatString, data.value = "[%.0f]", threat
        end
    end
    return data
end

local function barThreat(player, pet)
    if not pet then
        return player
    end
    if options.nameplateSource == "PET" then
        return pet
    elseif options.nameplateSource == "AGGRO" then
        if pet.tanking or not player.available then
            return pet
        end
    elseif options.nameplateSource == "CONCERN" then
        if not player.available or (pet.available and pet.concern > player.concern) then
            return pet
        end
    end
    return player
end

local function acquireLabel(entry, key, plate)
    if entry[key] then
        return entry[key]
    end
    local label = table.remove(labels) or UIParent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    label:SetFont(STANDARD_TEXT_FONT, 18, "OUTLINE")
    if not pcall(label.SetParent, label, plate) then
        label:Hide()
        labels[#labels + 1] = label
        return
    end
    entry[key] = label
    return label
end

local function paintNumber(label, data, colored)
    local formatString = data.formatString
    local painted = pcall(label.SetFormattedText, label, formatString, data.value)
    if not painted and formatString ~= "%.0f%%" then
        formatString = "%.0f%%"
        painted = pcall(label.SetFormattedText, label, formatString, data.percentage)
    end
    if not painted then
        return false
    end
    if colored then
        local color = data.color
        label:SetTextColor(color[1], color[2], color[3], 1)
    else
        local brightness = formatString == "%.0f%%" and 1 or 0.7
        label:SetTextColor(brightness, brightness, brightness, 1)
    end
    label:Show()
    return true
end

local function update(unit, entry, style, petActive)
    local hostile = UnitCanAttack("player", unit)
    if issecretvalue(hostile) or not hostile then
        clear(unit)
        return
    end

    local plateOk, plate = pcall(C_NamePlate.GetNamePlateForUnit, unit)
    if not plateOk or not accessible(plate) then
        clear(unit)
        return
    end

    local frameOk, frame = pcall(function() return plate.UnitFrame end)
    if not frameOk or not accessible(frame) then
        clear(unit)
        return
    end
    local containerOk, container = pcall(function() return frame.HealthBarsContainer end)
    if not containerOk or issecretvalue(container) then
        clear(unit)
        return
    end
    local bar = healthBar(frame)
    local anchor = container or bar
    if not accessible(anchor) then
        clear(unit)
        return
    end

    if visibility(bar) == false then
        clearBar(entry)
        if entry.label then
            entry.label:Hide()
        end
        if entry.petLabel then
            entry.petLabel:Hide()
        end
        return
    end

    local targetOk, targetPlate = pcall(C_NamePlate.GetNamePlateForUnit, "target")
    local threatUnit = targetOk and not issecretvalue(targetPlate) and targetPlate == plate and "target" or unit
    local player = threatData("player", threatUnit, style)
    local pet = petActive and threatData("pet", threatUnit, options.petStyle) or nil
    local barData = barThreat(player, pet)
    colorBar(unit, entry, frame, bar, barData.color, barData.available)

    if not player.hasNumber and not (pet and pet.hasNumber) then
        clearLabel(entry)
        return
    end

    local label = acquireLabel(entry, "label", plate)
    if not label then
        clearLabel(entry)
        return
    end
    local side = options.position
    if entry.layoutRetry and GetTime() >= entry.layoutRetry then
        entry.layoutDirty = true
    end
    if entry.baseAnchor ~= anchor or entry.position ~= side or entry.layoutDirty then
        local target, offset, y, incomplete = placement(plate, frame, anchor, side)
        local ownPoint = side == "RIGHT" and "LEFT" or "RIGHT"
        local relativePoint = side == "RIGHT" and "RIGHT" or "LEFT"
        label:SetJustifyH(side == "RIGHT" and "LEFT" or "RIGHT")
        label:ClearAllPoints()
        if not pcall(label.SetPoint, label, ownPoint, target, relativePoint, offset, y) then
            if not pcall(label.SetPoint, label, ownPoint, anchor, relativePoint, side == "RIGHT" and 4 or -4, 0) then
                clearLabel(entry)
                return
            end
            incomplete = true
        end
        entry.baseAnchor = anchor
        entry.position = side
        entry.layoutDirty = false
        entry.layoutRetry = incomplete and GetTime() + 1 or nil
    end

    local painted = player.hasNumber and paintNumber(label, player, options.colorNumber)
    if not painted then
        label:SetText("")
        label:Hide()
    end

    if pet and pet.hasNumber then
        local petLabel = acquireLabel(entry, "petLabel", plate)
        if petLabel then
            local positioned = true
            if entry.petAnchor ~= label or entry.petPosition ~= side then
                petLabel:SetJustifyH(side == "RIGHT" and "LEFT" or "RIGHT")
                petLabel:ClearAllPoints()
                positioned = pcall(petLabel.SetPoint, petLabel, side == "RIGHT" and "LEFT" or "RIGHT",
                    label, side == "RIGHT" and "RIGHT" or "LEFT", side == "RIGHT" and 6 or -6, 0)
                if positioned then
                    entry.petAnchor = label
                    entry.petPosition = side
                end
            end
            if not positioned or not paintNumber(petLabel, pet, options.colorPetNumber) then
                releaseLabel(entry, "petLabel")
            end
        end
    else
        releaseLabel(entry, "petLabel")
    end
    if not painted and not entry.petLabel then
        clearLabel(entry)
    end
end

local function refresh()
    local style = activeStyle()
    local petActive = activePet()
    for unit, entry in pairs(plates) do
        update(unit, entry, style, petActive)
    end
end

local function queueThreat(unit)
    if not issecretvalue(unit) and type(unit) == "string" and plates[unit] then
        pendingThreatUpdates[unit] = true
    else
        pendingThreatAll = true
    end
end

local function flushThreat()
    if pendingThreatAll then
        pendingThreatAll = false
        pendingThreatUpdates = {}
        for unit in pairs(pendingBarRepaints) do
            pendingBarRepaints[unit] = nil
        end
        refresh()
        return
    end
    local pending = pendingThreatUpdates
    pendingThreatUpdates = {}
    if next(pending) then
        local style = activeStyle()
        local petActive = activePet()
        for unit in pairs(pending) do
            local entry = plates[unit]
            if entry then
                pendingBarRepaints[unit] = nil
                update(unit, entry, style, petActive)
            end
        end
    end
end

local placementQueued = false
local function queuePlacement(unit)
    if not issecretvalue(unit) and type(unit) == "string" then
        local entry = plates[unit]
        if not entry then
            return
        end
        entry.layoutDirty = true
    else
        for _, entry in pairs(plates) do
            entry.layoutDirty = true
        end
    end
    if placementQueued then
        return
    end
    placementQueued = true
    if C_Timer and C_Timer.After then
        C_Timer.After(0, function()
            placementQueued = false
            refresh()
        end)
    else
        placementQueued = false
        refresh()
    end
end

local questieHooked = false
local function hookQuestie()
    if questieHooked or not QuestieLoader or type(QuestieLoader.ImportModule) ~= "function" then
        return
    end
    local ok, module = pcall(QuestieLoader.ImportModule, QuestieLoader, "QuestieNameplate")
    if not ok or type(module) ~= "table" then
        return
    end
    for _, method in ipairs({"NameplateCreated", "NameplateDestroyed", "UpdateNameplate", "RedrawIcons", "HideCurrentFrames"}) do
        local perUnit = method == "NameplateCreated" or method == "NameplateDestroyed"
        local function changed(_, unit)
            if perUnit and not issecretvalue(unit) and type(unit) == "string" then
                queuePlacement(unit)
            else
                queuePlacement()
            end
        end
        if type(module[method]) == "function" and pcall(hooksecurefunc, module, method, changed) then
            questieHooked = true
        end
    end
end

local function registerOptions()
    local category = Settings.RegisterVerticalLayoutCategory("L7 Nameplate Threat Tracker")

    local function toggle(key, name, tooltip)
        local setting = Settings.RegisterProxySetting(
            category, "L7NameplateThreatTracker_" .. key, Settings.VarType.Boolean, name, defaults[key],
            function() return options[key] end,
            function(value) options[key] = value; refresh() end
        )
        Settings.CreateCheckbox(category, setting, tooltip)
    end

    local function dropdown(key, name, values, tooltip)
        local setting = Settings.RegisterProxySetting(
            category, "L7NameplateThreatTracker_" .. key, Settings.VarType.String, name, defaults[key],
            function() return options[key] end,
            function(value) options[key] = value; refresh() end
        )
        local function choices()
            local container = Settings.CreateControlTextContainer()
            for _, value in ipairs(values) do
                container:Add(value[1], value[2])
            end
            return container:GetData()
        end
        Settings.CreateDropdown(category, setting, choices, tooltip)
    end

    toggle("colorNumber", "Color your threat number", "Color your threat number using your current threat state and role.")
    toggle("colorPetNumber", "Color pet threat number", "Color your pet's threat number independently, using its selected DPS or Tank style.")
    toggle("colorNameplate", "Color enemy health bar", "Color enemy nameplate health bars using the selected threat source.")
    dropdown("nameplateSource", "Nameplate color source", {
        {"PLAYER", "You"}, {"PET", "Your pet"},
        {"AGGRO", "Combined: aggro holder"}, {"CONCERN", "Combined: highest concern"},
    }, "Aggro holder uses your pet's colors while it has aggro, otherwise yours. Highest concern prefers red, then orange, yellow and green after applying each unit's role. All modes use your threat when no pet is active.")
    toggle("useGroupRole", "Use assigned group role", "Use Tank or DPS / Healer colors based on your assigned party or raid role.")
    dropdown("fallbackStyle", "Default style", {{"DPS", "DPS / Healer"}, {"TANK", "Tank"}},
        "Used for your number and threat colors when group role detection is off, you are solo, or your role is unassigned.")
    dropdown("petStyle", "Pet threat style", {{"DPS", "Treat Pet as DPS"}, {"TANK", "Treat Pet as Tank"}},
        "Choose your pet's threat colors independently of your role. This also applies when the nameplate follows pet threat.")
    dropdown("position", "Number position", {{"LEFT", "Left"}, {"RIGHT", "Right"}},
        "Place both numbers to the left or right of the enemy nameplate. Your number is nearest the plate; your pet's is farther out.")
    Settings.RegisterAddOnCategory(category)
end

local function loadOptions()
    if type(L7NameplateThreatTrackerDB) ~= "table" then
        L7NameplateThreatTrackerDB = {}
    end
    options = L7NameplateThreatTrackerDB
    local inheritPetColor = type(options.colorPetNumber) ~= "boolean"
    for key, default in pairs(defaults) do
        if type(options[key]) ~= type(default) then
            options[key] = default
        end
    end
    if inheritPetColor then
        options.colorPetNumber = options.colorNumber
    end
    if not palettes[options.fallbackStyle] then
        options.fallbackStyle = defaults.fallbackStyle
    end
    if not palettes[options.petStyle] then
        options.petStyle = defaults.petStyle
    end
    if not nameplateSources[options.nameplateSource] then
        options.nameplateSource = defaults.nameplateSource
    end
    if options.position ~= "LEFT" and options.position ~= "RIGHT" then
        options.position = defaults.position
    end
    registerOptions()
end

driver:RegisterEvent("ADDON_LOADED")
driver:RegisterEvent("NAME_PLATE_UNIT_ADDED")
driver:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
driver:RegisterEvent("UNIT_THREAT_SITUATION_UPDATE")
driver:RegisterEvent("UNIT_THREAT_LIST_UPDATE")
driver:RegisterEvent("UNIT_PET")
driver:RegisterEvent("UNIT_FLAGS")
driver:RegisterEvent("PLAYER_TARGET_CHANGED")
driver:RegisterEvent("RAID_TARGET_UPDATE")
driver:RegisterEvent("UNIT_CLASSIFICATION_CHANGED")
driver:RegisterEvent("UNIT_LEVEL")
driver:RegisterEvent("UNIT_FACTION")
driver:RegisterEvent("UNIT_AURA")
driver:RegisterEvent("QUEST_LOG_UPDATE")
driver:RegisterEvent("CVAR_UPDATE")
driver:RegisterEvent("UI_SCALE_CHANGED")
driver:RegisterEvent("DISPLAY_SIZE_CHANGED")
driver:RegisterEvent("PLAYER_REGEN_DISABLED")
driver:RegisterEvent("PLAYER_REGEN_ENABLED")
driver:RegisterEvent("GROUP_ROSTER_UPDATE")
driver:RegisterEvent("GROUP_JOINED")
driver:RegisterEvent("GROUP_LEFT")
driver:RegisterEvent("PLAYER_ROLES_ASSIGNED")
driver:RegisterEvent("PLAYER_ENTERING_WORLD")
driver:RegisterEvent("PLAYER_LEAVING_WORLD")

driver:SetScript("OnEvent", function(_, event, unit)
    if event == "ADDON_LOADED" then
        if unit == addonName then
            loadOptions()
            hookQuestie()
        elseif unit == "Questie" then
            hookQuestie()
            queuePlacement()
        end
    elseif event == "NAME_PLATE_UNIT_ADDED" or event == "NAME_PLATE_UNIT_REMOVED" then
        if issecretvalue(unit) or type(unit) ~= "string" then
            return
        end
        clear(unit)
        pendingThreatUpdates[unit] = nil
        plates[unit] = event == "NAME_PLATE_UNIT_ADDED" and {} or nil
        if plates[unit] then
            update(unit, plates[unit], activeStyle(), activePet())
            queuePlacement(unit)
        end
    elseif event == "PLAYER_LEAVING_WORLD" then
        pendingThreatAll = false
        pendingThreatUpdates = {}
        for token in pairs(plates) do
            clear(token)
            plates[token] = nil
        end
    elseif event == "PLAYER_ENTERING_WORLD" then
        for _, plate in ipairs(C_NamePlate.GetNamePlates()) do
            if accessible(plate) and plate.GetUnit then
                local ok, token = pcall(plate.GetUnit, plate)
                if ok and not issecretvalue(token) and type(token) == "string" then
                    plates[token] = plates[token] or {}
                end
            end
        end
        refresh()
        queuePlacement()
    elseif event == "RAID_TARGET_UPDATE" or event == "UNIT_CLASSIFICATION_CHANGED"
        or event == "UNIT_LEVEL" or event == "UNIT_FACTION"
        or event == "PLAYER_TARGET_CHANGED" or event == "QUEST_LOG_UPDATE"
        or event == "UI_SCALE_CHANGED" or event == "DISPLAY_SIZE_CHANGED"
        or event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_REGEN_ENABLED" then
        queuePlacement()
    elseif event == "UNIT_AURA" then
        queuePlacement(unit)
    elseif event == "UNIT_THREAT_SITUATION_UPDATE" then
        queueThreat(unit)
    elseif event == "UNIT_THREAT_LIST_UPDATE" then
        queueThreat(unit)
    elseif event == "UNIT_PET" then
        queueThreat()
    elseif event == "UNIT_FLAGS" then
        if issecretvalue(unit) or unit == "pet" then
            queueThreat()
        end
    elseif event == "GROUP_JOINED" or event == "GROUP_LEFT" then
        queueThreat()
    elseif event == "CVAR_UPDATE" then
        if not issecretvalue(unit) and type(unit) == "string" and unit:lower():find("nameplate", 1, true) then
            queuePlacement()
        end
    else
        refresh()
    end
end)

local function repaintBars()
    for unit, entry in pairs(pendingBarRepaints) do
        pendingBarRepaints[unit] = nil
        local bar = entry.bar
        if options.colorNameplate and plates[unit] == entry and not issecretvalue(bar) and bar and entry.color and ownsBar(entry) then
            local hostile = UnitCanAttack("player", unit)
            if not issecretvalue(hostile) and hostile then
                local state = barStates[bar]
                if state and state.owner == entry then
                    local color = entry.color
                    local ok, r, g, b = pcall(function() return bar:GetStatusBarColor() end)
                    if not ok or issecretvalue(r) or issecretvalue(g) or issecretvalue(b)
                        or type(r) ~= "number" or type(g) ~= "number" or type(b) ~= "number"
                        or r ~= color[1] or g ~= color[2] or b ~= color[3] then
                        setBarColor(bar, state, color[1], color[2], color[3], state.a)
                    end
                end
            end
        end
    end
end

driver:SetScript("OnUpdate", function(_, elapsed)
    elapsedSinceUpdate = elapsedSinceUpdate + elapsed
    if elapsedSinceUpdate >= 0.25 then
        elapsedSinceUpdate = 0
        pendingThreatAll = false
        pendingThreatUpdates = {}
        for unit in pairs(pendingBarRepaints) do
            pendingBarRepaints[unit] = nil
        end
        refresh()
    else
        flushThreat()
        repaintBars()
    end
end)
