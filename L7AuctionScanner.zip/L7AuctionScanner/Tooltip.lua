local _, addon = ...
local driver = CreateFrame("Frame")
local tooltips = setmetatable({}, {__mode = "k"})
local counts
local refreshQueued = false
local itemLoads = {}

local function itemReference(data)
    local link
    if addon.Readable(data.guid, "string") then
        link = C_Item.GetItemLinkByGUID(data.guid)
    end
    if not addon.Readable(link, "string") then
        link = data.hyperlink
    end
    local key, id = addon.ItemKey(link)
    if id == data.id then
        return link, key
    end
end

local function vendorPrice(data)
    local link = itemReference(data)
    local price = select(11, C_Item.GetItemInfo(link or data.id))
    if addon.Readable(price, "number") and price >= 0 then
        return price
    end
end

local function carriedCount(id, key)
    if not counts then
        counts = {items = {}, variants = {}}
        local function add(itemID, link, quantity)
            if not addon.Readable(itemID, "number") or not addon.Readable(quantity, "number") or quantity <= 0 then
                return
            end
            counts.items[itemID] = (counts.items[itemID] or 0) + quantity
            local itemKey, linkedID = addon.ItemKey(link)
            if itemKey and linkedID == itemID then
                counts.variants[itemKey] = (counts.variants[itemKey] or 0) + quantity
            end
        end
        local function bagItems(bag)
            for slot = 1, ContainerFrame_GetContainerNumSlots(bag) do
                local info = C_Container.GetContainerItemInfo(bag, slot)
                if info then
                    add(info.itemID, info.hyperlink, info.stackCount)
                end
            end
        end
        for bag = 0, NUM_TOTAL_BAG_FRAMES do
            bagItems(bag)
        end
        if type(KEYRING_CONTAINER) == "number" and KEYRING_CONTAINER < 0 then
            bagItems(KEYRING_CONTAINER)
        end
        for slot = INVSLOT_FIRST_EQUIPPED, INVSLOT_LAST_EQUIPPED do
            local link = GetInventoryItemLink("player", slot)
            local _, itemID = addon.ItemKey(link)
            local quantity = GetInventoryItemCount("player", slot)
            if itemID and addon.Readable(quantity, "number") then
                add(itemID, link, math.max(1, quantity))
            end
        end
    end
    return key and (counts.variants[key] or 0) or (counts.items[id] or 0)
end

local function hideNativePrice(tooltip)
    if not addon.db or tooltip:IsForbidden() then
        return
    end
    local info = tooltip:GetProcessingTooltipInfo()
    local data = info and info.tooltipData
    if data and not issecretvalue(data.type) and data.type == Enum.TooltipDataType.Item
        and tooltip:GetPrimaryTooltipData() == data and addon.Readable(data.id, "number")
        and vendorPrice(data) ~= nil then
        return true
    end
end

local function priceValues(data)
    local _, key = itemReference(data)
    local owned = carriedCount(data.id, key)
    local total = IsShiftKeyDown() and owned > 0
    local quantity = total and owned or 1
    local snapshot = addon.Snapshot()
    local price = snapshot and (key and snapshot.variants[key] or (not key and snapshot.prices[data.id]))
    local auctionValue = "Not scanned"
    if snapshot then
        auctionValue = price and GetMoneyString(price * quantity, true) or "No buyout in scan"
    end
    local vendor = vendorPrice(data)
    local vendorValue = "Unknown"
    if vendor ~= nil then
        vendorValue = vendor > 0 and GetMoneyString(vendor * quantity, true) or "Cannot sell"
    elseif not itemLoads[data.id] then
        itemLoads[data.id] = true
        C_Item.RequestLoadItemDataByID(data.id)
    end
    local quantityText = total and ("Total for " .. owned .. (owned == 1 and " item" or " items"))
        or ("Per item (" .. owned .. " carried)")
    return "AH (" .. addon.markets[addon.SelectedMarket()] .. ")", auctionValue,
        vendorValue, quantityText, snapshot and ("Scanned " .. addon.FormatAge(snapshot.scannedAt))
end

local function addPrices(tooltip, data)
    if not addon.db or tooltip:IsForbidden() or not addon.Readable(data.id, "number")
        or tooltip:GetPrimaryTooltipData() ~= data then
        return
    end
    local market, auction, vendor, quantity, age = priceValues(data)
    tooltip:AddDoubleLine(market, auction, 1, 1, 1, 1, 1, 1)
    local marketLine = tooltip:NumLines()
    tooltip:AddDoubleLine("Vendor", vendor, 1, 1, 1, 1, 1, 1)
    local vendorLine = tooltip:NumLines()
    tooltip:AddLine(quantity, 0.7, 0.7, 0.7)
    local quantityLine = tooltip:NumLines()
    local ageText
    if age then
        tooltip:AddLine(age, 0.7, 0.7, 0.7)
        ageText = tooltip:GetLeftLine(tooltip:NumLines())
    end
    tooltips[tooltip] = {
        data = data,
        market = tooltip:GetLeftLine(marketLine),
        auction = tooltip:GetRightLine(marketLine),
        vendor = tooltip:GetRightLine(vendorLine),
        quantity = tooltip:GetLeftLine(quantityLine),
        age = ageText,
    }
end

local function refreshTooltips()
    if refreshQueued then
        return
    end
    refreshQueued = true
    C_Timer.After(0, function()
        refreshQueued = false
        for tooltip, rows in pairs(tooltips) do
            if not tooltip:IsForbidden() and tooltip:IsShown() and tooltip:GetPrimaryTooltipData() == rows.data then
                local market, auction, vendor, quantity, age = priceValues(rows.data)
                rows.market:SetText(market)
                rows.auction:SetText(auction)
                rows.vendor:SetText(vendor)
                rows.quantity:SetText(quantity)
                if rows.age then
                    rows.age:SetText(age or "")
                end
                tooltip:Show()
            else
                tooltips[tooltip] = nil
            end
        end
    end)
end

function addon.InstallTooltips()
    TooltipDataProcessor.AddLinePreCall(Enum.TooltipDataLineType.SellPrice, hideNativePrice)
    TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, addPrices)
    driver:RegisterEvent("MODIFIER_STATE_CHANGED")
    driver:RegisterEvent("BAG_UPDATE_DELAYED")
    driver:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
    driver:RegisterEvent("PLAYER_ENTERING_WORLD")
    driver:RegisterEvent("ITEM_DATA_LOAD_RESULT")
end

driver:SetScript("OnEvent", function(_, event, arg, success)
    if event == "MODIFIER_STATE_CHANGED" then
        if arg == "LSHIFT" or arg == "RSHIFT" then
            refreshTooltips()
        end
    elseif event == "ITEM_DATA_LOAD_RESULT" then
        if addon.Readable(arg, "number") and not issecretvalue(success) and success then
            counts = nil
            if itemLoads[arg] then
                itemLoads[arg] = nil
                refreshTooltips()
            end
        end
    else
        counts = nil
        refreshTooltips()
    end
end)
