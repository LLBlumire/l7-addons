local _, addon = ...
local driver = CreateFrame("Frame")
local tooltips = setmetatable({}, {__mode = "k"})
local refreshQueued = false

local function readable(value, kind)
    return not issecretvalue(value) and type(value) == kind
end

local function number(value)
    if readable(value, "number") and value >= 0 and value < math.huge then
        return value
    end
end

local function tooltipTimings(data)
    local channeled = false
    local cooldown
    local runningCost
    if not readable(data.lines, "table") then
        return
    end
    for _, line in ipairs(data.lines) do
        if readable(line, "table") then
            for _, key in ipairs({"leftText", "rightText"}) do
                local text = line[key]
                if readable(text, "string") then
                    if text == SPELL_CAST_CHANNELED or text == "Channeled" then
                        channeled = true
                    end
                    text = text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub(",", ""):lower()
                    local amount, unit = text:match("^(%d+%.?%d*)%s+(%a+) cooldown$")
                    if not amount then
                        amount, unit = text:match("^recast: (%d+%.?%d*)%s+(%a+)$")
                    end
                    if amount and (unit == "sec" or unit == "min") then
                        cooldown = tonumber(amount) * (unit == "min" and 60 or 1)
                    end
                    local initial, perSecond = text:match("^(%d+%.?%d*) mana plus (%d+%.?%d*) per sec")
                    if not perSecond then
                        perSecond = text:match("^(%d+%.?%d*) mana per sec")
                    end
                    if perSecond then
                        runningCost = {initial = tonumber(initial) or 0, perSecond = tonumber(perSecond)}
                    end
                end
            end
        end
    end
    return channeled, cooldown, runningCost
end

local function manaCost(spellID, duration, runningCost)
    local costs = C_Spell.GetSpellPowerCost(spellID)
    if not readable(costs, "table") then
        return
    end
    local selected
    local selectedPriority = 0
    for _, cost in ipairs(costs) do
        if not readable(cost, "table") then
            return
        end
        local resource = number(cost.type)
        local required = number(cost.requiredAuraID)
        if not resource or not required or issecretvalue(cost.hasRequiredAura) then
            return
        end
        if resource == Enum.PowerType.Mana then
            local priority = required == 0 and 1 or (cost.hasRequiredAura and 2 or 0)
            if priority > selectedPriority then
                selected = cost
                selectedPriority = priority
            end
        end
    end
    if not selected then
        return
    end
    local amount = number(selected.cost)
    local perSecond = number(selected.costPerSec)
    if not amount or not perSecond then
        return
    end
    if perSecond > 0 then
        if not runningCost or duration <= 0 then
            return
        end
        return runningCost.initial + runningCost.perSecond * duration
    end
    return amount
end

local function format(value, decimals)
    if value == math.huge then
        return "∞"
    end
    return string.format("%." .. decimals .. "f", value):gsub("(%..-)0+$", "%1"):gsub("%.$", "")
end

local function addMetrics(tooltip, data)
    if not readable(data, "table") then
        return
    end
    local spellID = number(data.id)
    if not spellID or spellID == 0 then
        return
    end
    local known = C_SpellBook.IsSpellKnown(spellID)
    if issecretvalue(known) or not known then
        return
    end
    tooltips[tooltip] = true
    local info = C_Spell.GetSpellInfo(spellID)
    if not readable(info, "table") then
        return
    end
    local cast = number(info.castTime)
    local description = C_Spell.GetSpellDescription(spellID)
    if not cast or not readable(description, "string") then
        return
    end
    if description == "" then
        C_Spell.RequestLoadSpellData(spellID)
        return
    end
    local output = addon.ParseDescription(description)
    if not output then
        return
    end
    local channeled, tooltipCooldown, runningCost = tooltipTimings(data)
    if channeled == nil then
        return
    end
    local baseCooldown, baseGCD = GetSpellBaseCooldown(spellID)
    baseCooldown = number(baseCooldown)
    baseGCD = number(baseGCD)
    if not baseCooldown or not baseGCD then
        return
    end
    local cooldown = tooltipCooldown or baseCooldown / 1000
    local mana = manaCost(spellID, output.duration, runningCost)
    local maximumMana = number(UnitPowerMax("player", Enum.PowerType.Mana))
    local metrics = addon.Calculate(output, cast / 1000, baseGCD / 1000, cooldown, channeled, mana, maximumMana)
    if not metrics or not next(metrics) then
        return
    end
    tooltip:AddLine(" ")
    for _, key in ipairs({"DPS", "HPS", "MPS", "DPM", "HPM"}) do
        if metrics[key] then
            local value = format(metrics[key], (key == "DPS" or key == "HPS") and 1 or 2)
            if key == "MPS" then
                value = value .. "%"
            end
            tooltip:AddDoubleLine(key, value, 1, 1, 1, 1, 0.82, 0)
        end
    end
end

local function queueRefresh()
    if refreshQueued then
        return
    end
    refreshQueued = true
    C_Timer.After(0, function()
        refreshQueued = false
        for tooltip in pairs(tooltips) do
            if tooltip:IsShown() and tooltip:IsTooltipType(Enum.TooltipDataType.Spell) then
                tooltip:RebuildFromTooltipInfo()
            else
                tooltips[tooltip] = nil
            end
        end
    end)
end

local function supported()
    local locale = GetLocale()
    return (locale == "enUS" or locale == "enGB")
        and TooltipDataProcessor and type(TooltipDataProcessor.AddTooltipPostCall) == "function"
        and Enum and Enum.TooltipDataType and type(Enum.TooltipDataType.Spell) == "number"
        and Enum.PowerType and type(Enum.PowerType.Mana) == "number"
        and C_Spell and type(C_Spell.GetSpellInfo) == "function"
        and type(C_Spell.GetSpellDescription) == "function" and type(C_Spell.GetSpellPowerCost) == "function"
        and type(C_Spell.RequestLoadSpellData) == "function"
        and C_SpellBook and type(C_SpellBook.IsSpellKnown) == "function"
        and type(GetSpellBaseCooldown) == "function" and type(UnitPowerMax) == "function"
        and type(issecretvalue) == "function" and C_Timer and type(C_Timer.After) == "function"
end

driver:SetScript("OnEvent", function(self, event, unit)
    if event == "PLAYER_LOGIN" then
        self:UnregisterEvent(event)
        if not supported() then
            print("L7 Spell Metrics: requires English spell descriptions and the Forever spell tooltip APIs.")
            return
        end
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Spell, addMetrics)
        for _, name in ipairs({
            "PLAYER_ENTERING_WORLD",
            "PLAYER_EQUIPMENT_CHANGED",
            "SPELLS_CHANGED",
            "SPELL_TEXT_UPDATE",
            "SPELL_DATA_LOAD_RESULT",
            "UNIT_STATS",
            "UNIT_AURA",
            "UNIT_MAXPOWER",
            "UNIT_SPELL_HASTE",
        }) do
            self:RegisterEvent(name)
        end
    elseif event:sub(1, 5) == "UNIT_" and (issecretvalue(unit) or unit ~= "player") then
        return
    else
        queueRefresh()
    end
end)

driver:RegisterEvent("PLAYER_LOGIN")
