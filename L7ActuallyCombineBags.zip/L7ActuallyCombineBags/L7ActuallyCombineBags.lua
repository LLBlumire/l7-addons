local addonName = ...
local driver = CreateFrame("Frame")
local defaults = {
    mergeReagent = true,
    mergeKeyring = true,
    keepKeyringTogether = true,
    colorReagent = true,
    colorKeyring = true,
    bagOrder = 1,
    layoutMode = "BAG",
    separateSetGear = false,
    columns = 10,
}
local minimumColumns, maximumColumns = 4, 20
local itemGroups = {consumables = 0, equipment = 1, reagents = 2, quest = 3, keys = 4, other = 5}
local bagOrders = {
    {"keyring", "bags", "reagent"},
    {"keyring", "reagent", "bags"},
    {"bags", "keyring", "reagent"},
    {"bags", "reagent", "keyring"},
    {"reagent", "keyring", "bags"},
    {"reagent", "bags", "keyring"},
}
local bagLabels = {keyring = "Keyring", bags = "Regular bags", reagent = "Reagent bag"}
local options
local modeSetting
local combined
local nativeWidth, nativeHeight
local nativeLayoutApplied = true
local appliedLayoutMode = "NATIVE"
local dockedBags = {}
local backpackKeys = ""
local backgrounds = setmetatable({}, {__mode = "k"})
local reagentColor = {0.1, 0.45, 1, 0.35}
local keyringColor = {1, 0.72, 0.12, 0.35}
local itemCategories = {}
local itemTypes = {}
local itemLoads = {}
local categoryLayout
local categoryTimer
local equipmentMembers = {}
local equipmentDirty = true
local extraCategories = {junk = 100, empty = 101, reagent = 102, keyring = 103, locked = 104, combinedKeyring = 105}
local refreshQueued = false
local refreshPending = false
local forceRefresh = false

local function reagentBag(bagID)
    return bagID > NUM_BAG_FRAMES and bagID <= NUM_TOTAL_BAG_FRAMES
end

local function keyringAvailable()
    return C_ActionBar.ShouldShowKeyring() and GetCVarBool("showKeyring")
end

local function colorSlot(button)
    local bagID = button:GetBagID()
    local color
    if reagentBag(bagID) and options.colorReagent then
        color = reagentColor
    elseif bagID == KEYRING_CONTAINER and options.colorKeyring then
        color = keyringColor
    end
    local background = backgrounds[button]
    if color then
        if not background then
            background = button:CreateTexture(nil, "BACKGROUND", nil, 1)
            background:SetPoint("TOPLEFT", button, "TOPLEFT", -2, 2)
            background:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", 2, -2)
            backgrounds[button] = background
        end
        background:SetColorTexture(unpack(color))
        background:Show()
    elseif background then
        background:Hide()
    end
end

local function readable(value, kind)
    return not issecretvalue(value) and type(value) == kind
end

local function itemGUID(location)
    local exists = C_Item.DoesItemExist(location)
    if not issecretvalue(exists) and exists then
        local guid = C_Item.GetItemGUID(location)
        if readable(guid, "string") and guid ~= "" then
            return guid
        end
    end
end

local function rebuildEquipmentMembers()
    equipmentMembers = {}
    for _, setID in ipairs(C_EquipmentSet.GetEquipmentSetIDs()) do
        local ignored = C_EquipmentSet.GetIgnoredSlots(setID) or {}
        for equipmentSlot, packed in pairs(C_EquipmentSet.GetItemLocations(setID) or {}) do
            if not ignored[equipmentSlot] and readable(packed, "number") and packed >= 0 then
                local data = EquipmentManager_GetLocationData(packed)
                local location
                if data.isBags and not data.isBank and readable(data.bag, "number")
                    and data.bag >= 0 and data.bag <= NUM_TOTAL_BAG_FRAMES and data.slot > 0 then
                    location = ItemLocation:CreateFromBagAndSlot(data.bag, data.slot)
                elseif data.isPlayer and not data.isBags and not data.isBank and data.slot > 0 then
                    location = ItemLocation:CreateFromEquipmentSlot(data.slot)
                end
                if location then
                    local guid = itemGUID(location)
                    if guid then
                        equipmentMembers[guid] = true
                    end
                end
            end
        end
    end
    equipmentDirty = false
end

local function requestItemData(itemID)
    if itemLoads[itemID] == nil then
        itemLoads[itemID] = "pending"
        C_Item.RequestLoadItemDataByID(itemID)
    end
end

local function itemType(itemID)
    if itemTypes[itemID] then
        return itemTypes[itemID]
    end
    local _, _, _, _, _, classID, subclassID = C_Item.GetItemInfoInstant(itemID)
    if not readable(classID, "number") then
        requestItemData(itemID)
        return
    end
    local result = {class = classID, subclass = readable(subclassID, "number") and subclassID or 0}
    itemTypes[itemID] = result
    return result
end

local function classCategory(classID)
    if classID == Enum.ItemClass.Weapon or classID == Enum.ItemClass.Armor or classID == Enum.ItemClass.Profession then
        return itemGroups.equipment
    elseif classID == Enum.ItemClass.Consumable or classID == Enum.ItemClass.Projectile
        or classID == Enum.ItemClass.ItemEnhancement or classID == Enum.ItemClass.Glyph then
        return itemGroups.consumables
    elseif classID == Enum.ItemClass.Reagent or classID == Enum.ItemClass.Tradegoods then
        return itemGroups.reagents
    elseif classID == Enum.ItemClass.Questitem then
        return itemGroups.quest
    elseif classID == Enum.ItemClass.Key then
        return itemGroups.keys
    end
    return itemGroups.other
end

local function itemCategory(itemID)
    if itemCategories[itemID] then
        return itemCategories[itemID]
    end
    local item = itemType(itemID)
    if not item then
        return itemGroups.other
    end
    local classID = item.class
    if classID == Enum.ItemClass.Reagent or classID == Enum.ItemClass.Tradegoods then
        itemCategories[itemID] = itemGroups.reagents
    elseif classID == Enum.ItemClass.Key then
        itemCategories[itemID] = itemGroups.keys
    else
        local craftingReagent = select(17, C_Item.GetItemInfo(itemID))
        if readable(craftingReagent, "boolean") then
            itemCategories[itemID] = craftingReagent and itemGroups.reagents or classCategory(classID)
        else
            requestItemData(itemID)
        end
    end
    return itemCategories[itemID] or classCategory(classID)
end

local function slotCategory(button)
    if button:IsExtended() then
        return extraCategories.locked
    end
    local bagID = button:GetBagID()
    local info = C_Container.GetContainerItemInfo(bagID, button:GetID())
    if options.keepKeyringTogether and bagID == KEYRING_CONTAINER then
        local itemID = info and readable(info.itemID, "number") and info.itemID or nil
        return extraCategories.combinedKeyring, itemID
    end
    if not info then
        if bagID == KEYRING_CONTAINER then
            return extraCategories.keyring
        elseif reagentBag(bagID) then
            return extraCategories.reagent
        end
        return extraCategories.empty
    end
    local itemID = readable(info.itemID, "number") and info.itemID or nil
    if readable(info.quality, "number") and info.quality == Enum.ItemQuality.Poor
        and readable(info.hasNoValue, "boolean") and not info.hasNoValue then
        return extraCategories.junk, itemID
    end
    if not readable(info.quality, "number") and itemID then
        requestItemData(itemID)
    end
    if bagID == KEYRING_CONTAINER then
        return itemGroups.keys, itemID
    elseif reagentBag(bagID) then
        return itemGroups.reagents, itemID
    elseif itemID then
        return itemCategory(itemID), itemID
    end
    return itemGroups.other
end

local function bagGroup(bagID)
    if bagID == KEYRING_CONTAINER then
        return "keyring"
    elseif reagentBag(bagID) then
        return "reagent"
    end
    return "bags"
end

local function sortBagItems(items, ascending, sortKeys)
    local accountSecured = IsAccountSecured()
    local ranks = {}
    for rank, group in ipairs(bagOrders[options.bagOrder]) do
        ranks[group] = rank
    end
    table.sort(items, function(left, right)
        if sortKeys then
            local leftKey, rightKey = sortKeys[left], sortKeys[right]
            if leftKey.bagPriority ~= rightKey.bagPriority then
                return leftKey.bagPriority < rightKey.bagPriority
            end
            if leftKey.class ~= rightKey.class then
                return leftKey.class < rightKey.class
            end
            if leftKey.subclass ~= rightKey.subclass then
                return leftKey.subclass < rightKey.subclass
            end
            if leftKey.itemID ~= rightKey.itemID then
                return leftKey.itemID < rightKey.itemID
            end
        end
        if ascending then
            left, right = right, left
        end
        local leftBag, rightBag = left:GetBagID(), right:GetBagID()
        local leftRank, rightRank = ranks[bagGroup(leftBag)], ranks[bagGroup(rightBag)]
        if leftRank ~= rightRank then
            return leftRank > rightRank
        end
        if not accountSecured then
            local leftExtended, rightExtended = left:IsExtended(), right:IsExtended()
            if leftExtended ~= rightExtended then
                return not leftExtended
            end
        end
        if leftBag ~= rightBag then
            return leftBag > rightBag
        end
        return left:GetID() > right:GetID()
    end)
end

local function getCategoryLayout(items, columns)
    if options.separateSetGear and equipmentDirty then
        rebuildEquipmentMembers()
    end
    local groups, byCategory, sortKeys = {}, {}, {}
    for _, button in ipairs(items) do
        local category, itemID = slotCategory(button)
        local item = itemID and itemType(itemID)
        sortKeys[button] = {
            bagPriority = category == itemGroups.reagents and not reagentBag(button:GetBagID()) and 1 or 0,
            class = item and item.class or math.huge,
            subclass = item and item.subclass or 0,
            itemID = itemID or 0,
        }
        local inSet = false
        if options.separateSetGear and (category == itemGroups.equipment or category == extraCategories.junk) then
            local guid = itemGUID(ItemLocation:CreateFromBagAndSlot(button:GetBagID(), button:GetID()))
            inSet = guid and equipmentMembers[guid] == true
        end
        local groupID = category * 2 + (inSet and 0 or 1)
        local group = byCategory[groupID]
        if not group then
            group = {category = groupID, items = {}}
            byCategory[groupID] = group
            groups[#groups + 1] = group
        end
        group.items[#group.items + 1] = button
    end
    table.sort(groups, function(left, right) return left.category < right.category end)
    local rows = 0
    for _, group in ipairs(groups) do
        sortBagItems(group.items, true, sortKeys)
        group.row = rows
        rows = rows + math.ceil(#group.items / columns)
    end
    return {groups = groups, rows = rows, columns = columns}
end

local function sameCategoryLayout(left, right)
    if not left or left.columns ~= right.columns or #left.groups ~= #right.groups then
        return false
    end
    for index, group in ipairs(left.groups) do
        local other = right.groups[index]
        if group.category ~= other.category or #group.items ~= #other.items then
            return false
        end
        for slot, button in ipairs(group.items) do
            if button ~= other.items[slot] then
                return false
            end
        end
    end
    return true
end

local function inventoryLocked(items)
    for _, button in ipairs(items) do
        local info = C_Container.GetContainerItemInfo(button:GetBagID(), button:GetID())
        if info and (issecretvalue(info.isLocked) or info.isLocked) then
            return true
        end
    end
    return false
end

local function colorBag(container)
    if container:IsShown() then
        for _, button in container:EnumerateValidItems() do
            colorSlot(button)
        end
    end
end

local function anchorOf(region)
    if region:GetNumPoints() == 1 then
        local point, relativeTo, relativePoint, x, y = region:GetPoint(1)
        if readable(point, "string") and not issecretvalue(relativeTo)
            and readable(relativePoint, "string") and readable(x, "number") and readable(y, "number") then
            return {point, relativeTo, relativePoint, x, y}
        end
    end
end

local function parked(anchor)
    return anchor and anchor[1] == "TOPRIGHT" and anchor[2] == UIParent and anchor[3] == "BOTTOMLEFT"
        and anchor[4] == -32 and anchor[5] == -32
end

local function windowAnchor(container)
    local anchor = anchorOf(container)
    local dock = dockedBags[container]
    return parked(anchor) and dock and dock.anchor or anchor
end

local function moveTo(region, anchor)
    region:ClearAllPoints()
    region:SetPoint(unpack(anchor, 1, 5))
end

local function canMove(region)
    if not InCombatLockdown() then
        return true
    end
    local protected = region:IsProtected()
    return readable(protected, "boolean") and not protected
end

local function collectDock(container)
    local anchor = windowAnchor(container)
    local effectiveScale = container:GetEffectiveScale()
    local combinedScale = combined:GetEffectiveScale()
    if not anchor or parked(anchor) or container:IsClampedToScreen()
        or not readable(effectiveScale, "number") or effectiveScale <= 0
        or not readable(combinedScale, "number") or combinedScale <= 0 then
        return
    end
    local scale = combinedScale / effectiveScale
    local dock = dockedBags[container]
    local slots = {}
    for _, button in container:EnumerateValidItems() do
        local point = anchorOf(button)
        local old = dock and dock.slots[button]
        if point and point[2] == combined.MoneyFrame then
            point = old and old.anchor
        end
        if not point then
            return
        end
        local buttonScale = button:GetScale()
        if not readable(buttonScale, "number") then
            return
        end
        if old and math.abs(buttonScale - old.appliedScale) < 0.0001 then
            buttonScale = old.scale
        end
        slots[button] = {anchor = point, scale = buttonScale, appliedScale = scale}
    end
    if next(slots) then
        return {anchor = anchor, slots = slots}
    end
end

local function collectDocks()
    local docks = {}
    local containers = ContainerFrameContainer.ContainerFrames
    for _, container in ipairs(containers) do
        if container:IsShown() then
            local bagID = container:GetBagID()
            if readable(bagID, "number") and (options.mergeReagent and reagentBag(bagID)
                or options.mergeKeyring and bagID == KEYRING_CONTAINER) then
                docks[container] = collectDock(container)
            end
        end
    end
    for _, container in ipairs(containers) do
        if container:IsShown() and not docks[container] then
            local point = windowAnchor(container)
            if not point then
                return {}
            end
            while docks[point[2]] do
                local dependent = docks[point[2]]
                docks[point[2]] = nil
                point = dependent.anchor
            end
        end
    end
    return docks
end

local function restoreSlot(button, slot)
    local anchor = anchorOf(button)
    if anchor and anchor[2] == combined.MoneyFrame then
        moveTo(button, slot.anchor)
    end
    local scale = button:GetScale()
    if readable(scale, "number") and math.abs(scale - slot.appliedScale) < 0.0001
        and math.abs(scale - slot.scale) >= 0.0001 then
        button:SetScale(slot.scale)
    end
end

local function restoreDock(container, dock)
    if not canMove(container) then
        return
    end
    for button in pairs(dock.slots) do
        if not canMove(button) then
            return
        end
    end
    if parked(anchorOf(container)) then
        moveTo(container, dock.anchor)
    end
    for button, slot in pairs(dock.slots) do
        restoreSlot(button, slot)
    end
    dockedBags[container] = nil
end

local function applyDocks(docks)
    for container, dock in pairs(dockedBags) do
        local current = docks[container]
        if not current then
            restoreDock(container, dock)
        else
            for button, slot in pairs(dock.slots) do
                if not current.slots[button] then
                    restoreSlot(button, slot)
                end
            end
        end
    end
    for container, dock in pairs(docks) do
        if not parked(anchorOf(container)) then
            moveTo(container, {"TOPRIGHT", UIParent, "BOTTOMLEFT", -32, -32})
        end
        for button, slot in pairs(dock.slots) do
            if math.abs(button:GetScale() - slot.appliedScale) >= 0.0001 then
                button:SetScale(slot.appliedScale)
            end
        end
        dockedBags[container] = dock
    end
end

local function raiseDockedBags()
    if not combined:IsShown() or not next(dockedBags) then
        return
    end
    if canMove(ContainerFrameContainer) then
        ContainerFrameContainer:Raise()
    end
    for container in pairs(dockedBags) do
        if container:IsShown() and canMove(container) then
            container:Raise()
        end
    end
end

local function mouseOverBags()
    local foci = GetMouseFoci()
    if not readable(foci, "table") then
        return false
    end
    for _, focus in ipairs(foci) do
        local frame = focus
        while frame and not issecretvalue(frame) do
            if frame == combined or dockedBags[frame] then
                return true
            end
            frame = frame:GetParent()
        end
    end
    return false
end

local function refreshBackpackBinding()
    if InCombatLockdown() then
        return
    end
    local keys = {}
    if options.mergeReagent and GetCVarBool("combinedBags") and not InputUtil.IsGamepadUIEnabled() then
        local slots = C_Container.GetContainerNumSlots(NUM_BAG_FRAMES + 1)
        if readable(slots, "number") and slots > 0 then
            keys = {GetBindingKey("TOGGLEBACKPACK")}
        end
    end
    local keyList = table.concat(keys, " ")
    if backpackKeys == keyList then
        return
    end
    backpackKeys = keyList
    ClearOverrideBindings(driver)
    for _, key in ipairs(keys) do
        SetOverrideBinding(driver, false, key, "OPENALLBAGS")
    end
end

local function applyLayout(items, nativeCount, columns, rows, groups)
    local template = C_XMLUtil.GetTemplateInfo(combined.itemButtonPool:GetTemplate())
    local nativeLayout = combined:GetAnchorLayout()
    local paddingX, paddingY = nativeLayout.paddingX, nativeLayout.paddingY
    local stepX, stepY = template.width + paddingX, template.height + paddingY
    local nativeRows = math.ceil(nativeCount / nativeLayout.stride)
    local width = nativeWidth + (columns - nativeLayout.stride) * stepX
    local height = nativeHeight + (rows - nativeRows) * stepY
    if combined:GetWidth() ~= width or combined:GetHeight() ~= height then
        combined:SetSize(width, height)
        NineSliceUtil.UpdateCornerCropping(combined, height)
    end

    local initialAnchor = combined:GetInitialItemAnchor()
    if groups then
        local _, relativeTo, relativePoint, x, y = initialAnchor:Get()
        local left, top = x - columns * stepX + paddingX, y + rows * stepY - paddingY
        local layout = AnchorUtil.CreateGridLayout(GridLayoutMixin.Direction.TopLeftToBottomRight,
            columns, paddingX, paddingY)
        for _, group in ipairs(groups) do
            local anchor = AnchorUtil.CreateAnchor("TOPLEFT", relativeTo, relativePoint, left, top - group.row * stepY)
            AnchorUtil.GridLayout(group.items, anchor, layout)
        end
    else
        sortBagItems(items)
        local layout = AnchorUtil.CreateGridLayout(GridLayoutMixin.Direction.BottomRightToTopLeft,
            columns, paddingX, paddingY)
        AnchorUtil.GridLayout(items, initialAnchor, layout)
    end

    if BagItemSearchBox and BagItemSearchBox:GetParent() == combined and BagItemSearchBox:GetWidth() ~= width - 100 then
        BagItemSearchBox:SetWidth(width - 100)
    end
end

local queueCategoryRefresh

local function refresh()
    local customLayout = combined:IsShown() and not InputUtil.IsGamepadUIEnabled()
    if InCombatLockdown() or CursorHasItem() then
        if forceRefresh or not customLayout then
            applyDocks({})
        end
        return
    end
    local force = forceRefresh
    refreshPending = false
    forceRefresh = false
    if force then
        refreshBackpackBinding()
        colorBag(combined)
        for _, container in ipairs(ContainerFrameContainer.ContainerFrames) do
            colorBag(container)
        end
    end
    if not customLayout then
        applyDocks({})
        categoryLayout = nil
        appliedLayoutMode = "NATIVE"
        return
    end
    local docks = collectDocks()
    local columns = options.columns
    local nativeBagLayout = options.layoutMode == "BAG" and columns == combined:GetColumns() and not next(docks)
    if nativeBagLayout and nativeLayoutApplied and combined:GetWidth() == nativeWidth and combined:GetHeight() == nativeHeight then
        applyDocks(docks)
        categoryLayout = nil
        appliedLayoutMode = "BAG"
        return
    end

    local items = {}
    for _, button in combined:EnumerateValidItems() do
        items[#items + 1] = button
    end
    local nativeCount = #items
    if nativeCount == 0 then
        applyDocks({})
        return
    end
    for _, dock in pairs(docks) do
        for button in pairs(dock.slots) do
            items[#items + 1] = button
        end
    end

    if options.layoutMode == "CATEGORY" then
        if not force and inventoryLocked(items) then
            queueCategoryRefresh()
            return
        end
        local current = getCategoryLayout(items, columns)
        if force or not sameCategoryLayout(categoryLayout, current) then
            applyDocks(docks)
            applyLayout(items, nativeCount, columns, current.rows, current.groups)
            categoryLayout = current
        end
    elseif force then
        applyDocks(docks)
        applyLayout(items, nativeCount, columns, math.ceil(#items / columns))
        categoryLayout = nil
    end
    if force then
        raiseDockedBags()
    end
    nativeLayoutApplied = nativeBagLayout
    appliedLayoutMode = options.layoutMode
end

local function queueRefresh(force)
    if not combined then
        return
    end
    refreshPending = true
    forceRefresh = forceRefresh or force
    if refreshQueued then
        return
    end
    refreshQueued = true
    C_Timer.After(0, function()
        refreshQueued = false
        refresh()
    end)
end

queueCategoryRefresh = function()
    if options.layoutMode ~= "CATEGORY" or not combined:IsShown() or InputUtil.IsGamepadUIEnabled() then
        return
    end
    if categoryTimer then
        categoryTimer:Cancel()
    end
    categoryTimer = C_Timer.NewTimer(0.25, function()
        categoryTimer = nil
        queueRefresh()
    end)
end

local function registerOptions()
    local category = Settings.RegisterVerticalLayoutCategory("L7 Actually Combine Bags")
    local function toggle(key, name, tooltip)
        local setting = Settings.RegisterProxySetting(
            category, "L7ActuallyCombineBags_" .. key, Settings.VarType.Boolean, name, defaults[key],
            function() return options[key] end,
            function(value)
                options[key] = value
                queueRefresh(true)
            end
        )
        Settings.CreateCheckbox(category, setting, tooltip)
    end
    toggle("mergeReagent", "Merge reagent bag",
        "Show the open reagent bag in the combined backpack. Your backpack key opens both windows together.")
    toggle("mergeKeyring", "Merge keyring",
        "Show keyring slots in the combined backpack when you open the keyring.")
    toggle("keepKeyringTogether", "Keep keyring together",
        "Keep open keyring slots together at the bottom in Category mode.")
    toggle("colorReagent", "Colour reagent slot backgrounds",
        "Give reagent bag slots a blue background in Blizzard's bag windows.")
    toggle("colorKeyring", "Colour keyring slot backgrounds",
        "Give keyring slots a gold background in Blizzard's bag windows.")
    toggle("separateSetGear", "Separate equipment set gear",
        "In category mode, put weapons and armour saved in an equipment set on separate rows from other gear.")
    modeSetting = Settings.RegisterProxySetting(
        category, "L7ActuallyCombineBags_layoutMode", Settings.VarType.String, "Layout mode", defaults.layoutMode,
        function() return options.layoutMode end,
        function(value)
            options.layoutMode = value
            queueRefresh(true)
        end
    )
    local function modeChoices()
        local choices = Settings.CreateControlTextContainer()
        choices:Add("BAG", "Bag mode")
        choices:Add("CATEGORY", "Category mode")
        return choices:GetData()
    end
    Settings.CreateDropdown(category, modeSetting, modeChoices,
        "With mouse and keyboard, use bag slot order or start a new row for each item category. Changes apply after combat or after placing a held item.")
    local width = Settings.RegisterProxySetting(
        category, "L7ActuallyCombineBags_columns", Settings.VarType.Number, "Slots per row", defaults.columns,
        function() return options.columns end,
        function(value)
            options.columns = math.floor(math.max(minimumColumns, math.min(maximumColumns, value)) + 0.5)
            queueRefresh(true)
        end
    )
    local widthOptions = Settings.CreateSliderOptions(minimumColumns, maximumColumns, 1)
    widthOptions:SetLabelFormatter(MinimalSliderWithSteppersMixin.Label.Right, function(value) return string.format("%d", value) end)
    Settings.CreateSlider(category, width, widthOptions,
        "With mouse and keyboard, choose the number of slots across the combined bag. Changes apply after combat or after placing a held item.")
    local order = Settings.RegisterProxySetting(
        category, "L7ActuallyCombineBags_bagOrder", Settings.VarType.Number, "Bag order (top to bottom)", defaults.bagOrder,
        function() return options.bagOrder end,
        function(value)
            options.bagOrder = value
            queueRefresh(true)
        end
    )
    local function orderChoices()
        local choices = Settings.CreateControlTextContainer()
        for value, groups in ipairs(bagOrders) do
            local labels = {}
            for _, group in ipairs(groups) do
                labels[#labels + 1] = bagLabels[group]
            end
            choices:Add(value, table.concat(labels, " > "))
        end
        return choices:GetData()
    end
    Settings.CreateDropdown(category, order, orderChoices,
        "Choose the order of bag slots in Bag mode. The combined backpack includes bags that are open.")
    Settings.RegisterAddOnCategory(category)
end

local function supported()
    local frame = ContainerFrameCombinedBags
    local pool = frame and frame.itemButtonPool
    return frame and type(frame.EnumerateValidItems) == "function"
        and type(frame.UpdateItemLayout) == "function" and type(frame.UpdateFrameSize) == "function"
        and type(frame.SetSearchBoxPoint) == "function"
        and type(frame.GetColumns) == "function"
        and type(frame.GetAnchorLayout) == "function" and type(frame.GetInitialItemAnchor) == "function"
        and pool and type(pool.GetTemplate) == "function"
        and ContainerFrameContainer and type(ContainerFrameContainer.ContainerFrames) == "table"
        and type(UpdateContainerFrameAnchors) == "function"
        and type(ContainerFrame_GetContainerNumSlots) == "function"
        and type(GetMouseFoci) == "function" and type(SetOverrideBinding) == "function"
        and type(ClearOverrideBindings) == "function"
        and C_XMLUtil and type(C_XMLUtil.GetTemplateInfo) == "function"
        and NineSliceUtil and type(NineSliceUtil.UpdateCornerCropping) == "function"
        and C_Item and type(C_Item.GetItemInfoInstant) == "function"
        and type(C_Item.GetItemInfo) == "function" and type(C_Item.RequestLoadItemDataByID) == "function"
        and type(C_Item.DoesItemExist) == "function" and type(C_Item.GetItemGUID) == "function"
        and C_EquipmentSet and type(C_EquipmentSet.GetEquipmentSetIDs) == "function"
        and type(C_EquipmentSet.GetItemLocations) == "function" and type(C_EquipmentSet.GetIgnoredSlots) == "function"
        and type(EquipmentManager_GetLocationData) == "function"
        and ItemLocation and type(ItemLocation.CreateFromBagAndSlot) == "function"
        and type(ItemLocation.CreateFromEquipmentSlot) == "function"
        and Menu and type(Menu.ModifyMenu) == "function" and Enum and Enum.ItemClass
        and C_ActionBar and type(C_ActionBar.ShouldShowKeyring) == "function"
        and type(NUM_BAG_FRAMES) == "number" and type(NUM_TOTAL_BAG_FRAMES) == "number"
        and type(KEYRING_CONTAINER) == "number"
end

local function install()
    if combined or not options or not supported() then
        return
    end
    combined = ContainerFrameCombinedBags
    nativeWidth, nativeHeight = combined:GetSize()
    hooksecurefunc(combined, "UpdateFrameSize", function(frame)
        nativeWidth, nativeHeight = frame:GetSize()
        queueRefresh(true)
    end)
    hooksecurefunc(combined, "UpdateItemLayout", function()
        nativeLayoutApplied = true
        queueRefresh(true)
    end)
    hooksecurefunc(combined, "SetSearchBoxPoint", function(frame, searchBox)
        local width = frame:GetWidth() - 100
        if not InCombatLockdown() and not InputUtil.IsGamepadUIEnabled() and width > 0 and searchBox:GetWidth() ~= width then
            searchBox:SetWidth(width)
        end
    end)
    hooksecurefunc("UpdateContainerFrameAnchors", function()
        queueRefresh(true)
    end)

    Menu.ModifyMenu("MENU_CONTAINER_FRAME_COMBINED", function(_, root)
        if InputUtil.IsGamepadUIEnabled() then
            return
        end
        root:CreateDivider()
        root:CreateTitle("Layout")
        root:CreateRadio("Bag mode", function() return options.layoutMode == "BAG" end,
            function() modeSetting:SetValue("BAG") end)
        root:CreateRadio("Category mode", function() return options.layoutMode == "CATEGORY" end,
            function() modeSetting:SetValue("CATEGORY") end)
    end)

    queueRefresh(true)
end

driver:RegisterEvent("ADDON_LOADED")
driver:RegisterEvent("ADDON_ACTION_BLOCKED")
driver:RegisterEvent("ADDON_ACTION_FORBIDDEN")
driver:RegisterEvent("PLAYER_LOGIN")
driver:RegisterEvent("PLAYER_ENTERING_WORLD")
driver:RegisterEvent("PLAYER_REGEN_ENABLED")
driver:RegisterEvent("BAG_UPDATE_DELAYED")
driver:RegisterEvent("ITEM_LOCK_CHANGED")
driver:RegisterEvent("EQUIPMENT_SETS_CHANGED")
driver:RegisterEvent("EQUIPMENT_SWAP_FINISHED")
driver:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
driver:RegisterEvent("ITEM_DATA_LOAD_RESULT")
driver:RegisterEvent("CURSOR_CHANGED")
driver:RegisterEvent("CVAR_UPDATE")
driver:RegisterEvent("UPDATE_BINDINGS")
driver:RegisterEvent("GLOBAL_MOUSE_DOWN")
driver:RegisterEvent("GLOBAL_MOUSE_UP")
driver:SetScript("OnEvent", function(_, event, name, success)
    if event == "ADDON_LOADED" then
        if name == addonName then
            if type(L7ActuallyCombineBagsDB) ~= "table" then
                L7ActuallyCombineBagsDB = {}
            end
            options = L7ActuallyCombineBagsDB
            for key, default in pairs(defaults) do
                if type(options[key]) ~= type(default) then
                    options[key] = default
                end
            end
            if not bagOrders[options.bagOrder] then
                options.bagOrder = defaults.bagOrder
            end
            if options.layoutMode ~= "BAG" and options.layoutMode ~= "CATEGORY" then
                options.layoutMode = defaults.layoutMode
            end
            options.columns = math.floor(math.max(minimumColumns, math.min(maximumColumns, options.columns)) + 0.5)
            registerOptions()
        end
        install()
    elseif event == "ADDON_ACTION_BLOCKED" or event == "ADDON_ACTION_FORBIDDEN" then
        if name == addonName and options then
            local stack = debugstack(2)
            options.lastBlockedAction = {
                event = event,
                action = readable(success, "string") and success or "unavailable",
                stack = readable(stack, "string") and stack or "unavailable",
                version = C_AddOns.GetAddOnMetadata(addonName, "Version"),
                build = select(2, GetBuildInfo()),
                layoutMode = combined and combined:IsShown() and appliedLayoutMode or "NATIVE",
                combat = InCombatLockdown(),
            }
            print("L7 Actually Combine Bags: blocked action " .. options.lastBlockedAction.action
                .. ". Use /l7bags error to show the saved report.")
        end
    elseif event == "PLAYER_LOGIN" then
        install()
        if not combined then
            print("L7 Actually Combine Bags: required native bag APIs are unavailable.")
        end
    elseif not combined then
        return
    elseif event == "PLAYER_ENTERING_WORLD" or event == "PLAYER_REGEN_ENABLED" then
        queueRefresh(true)
    elseif event == "CVAR_UPDATE" then
        if readable(name, "string") and name:lower() == "combinedbags" then
            queueRefresh(true)
        end
    elseif event == "UPDATE_BINDINGS" then
        refreshBackpackBinding()
    elseif event == "GLOBAL_MOUSE_DOWN" or event == "GLOBAL_MOUSE_UP" then
        if combined:IsShown() and next(dockedBags) and mouseOverBags() then
            raiseDockedBags()
            C_Timer.After(0, raiseDockedBags)
        end
    elseif event == "CURSOR_CHANGED" then
        if refreshPending then
            queueRefresh()
        end
    elseif event == "ITEM_DATA_LOAD_RESULT" then
        if readable(name, "number") and itemLoads[name] == "pending" then
            itemLoads[name] = success
            queueCategoryRefresh()
        end
    elseif event == "ITEM_LOCK_CHANGED" then
        if readable(name, "number") and (name >= 0 and name <= NUM_TOTAL_BAG_FRAMES or name == KEYRING_CONTAINER) then
            queueCategoryRefresh()
        end
    elseif event == "EQUIPMENT_SETS_CHANGED" or event == "EQUIPMENT_SWAP_FINISHED"
        or event == "PLAYER_EQUIPMENT_CHANGED" then
        equipmentDirty = true
        if options.separateSetGear then
            queueCategoryRefresh()
        end
    elseif event == "BAG_UPDATE_DELAYED" then
        refreshBackpackBinding()
        equipmentDirty = true
        queueCategoryRefresh()
    end
end)

SLASH_L7ACTUALLYCOMBINEBAGS1 = "/l7bags"
SlashCmdList.L7ACTUALLYCOMBINEBAGS = function(message)
    if message:match("^%s*error%s*$") then
        local report = options and options.lastBlockedAction
        if type(report) ~= "table" then
            print("L7 Actually Combine Bags: no blocked action has been recorded.")
            return
        end
        print("L7 Actually Combine Bags: " .. tostring(report.event) .. ", action " .. tostring(report.action)
            .. ", version " .. tostring(report.version) .. ", build " .. tostring(report.build)
            .. ", layout " .. tostring(report.layoutMode) .. ", combat " .. tostring(report.combat))
        print(report.stack or "Call stack unavailable.")
        return
    end
    if not combined then
        print("L7 Actually Combine Bags: not initialized.")
        return
    end
    local cursor = GetCursorInfo()
    local mode = combined:IsShown() and appliedLayoutMode or "NATIVE"
    print("L7 Actually Combine Bags: selected " .. options.layoutMode .. ", applied " .. mode
        .. ", combined open " .. tostring(combined:IsShown())
        .. ", combat " .. tostring(InCombatLockdown())
        .. ", cursor " .. (readable(cursor, "string") and cursor or "empty/unavailable"))
    local count = 0
    local inspectBags = {}
    for bagID = 0, NUM_TOTAL_BAG_FRAMES do
        inspectBags[#inspectBags + 1] = bagID
    end
    if keyringAvailable() then
        inspectBags[#inspectBags + 1] = KEYRING_CONTAINER
    end
    for _, bagID in ipairs(inspectBags) do
        for slot = 1, ContainerFrame_GetContainerNumSlots(bagID) do
            local info = C_Container.GetContainerItemInfo(bagID, slot)
            if info and (issecretvalue(info.isLocked) or info.isLocked) then
                count = count + 1
                if count <= 10 then
                    local item = readable(info.hyperlink, "string") and info.hyperlink
                        or (readable(info.itemID, "number") and ("item " .. info.itemID)) or "item unavailable"
                    print("Bag " .. bagID .. ", slot " .. slot .. ": " .. item
                        .. (issecretvalue(info.isLocked) and " (lock status unavailable)" or " (locked)"))
                end
            end
        end
    end
    print("L7 Actually Combine Bags: " .. count .. " locked or unreadable slots."
        .. (count > 10 and " First 10 shown." or ""))
end
