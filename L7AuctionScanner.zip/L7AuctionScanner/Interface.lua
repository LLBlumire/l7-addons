local addonName, addon = ...
local driver = CreateFrame("Frame")
local button, ticker
local hookedFrame

function addon.UpdateButton()
    if not button or not addon.options then
        return
    end
    local parent = button:GetParent()
    local level = parent:GetFrameLevel()
    for _, name in ipairs({"NineSlice", "TitleContainer", "CloseButton"}) do
        local layer = parent[name]
        if layer then
            level = math.max(level, layer:GetFrameLevel())
        end
    end
    button:SetFrameLevel(level + 1)
    local scan, open, cooldown = addon.ScanState()
    local market = addon.DetectMarket()
    button:SetText("Scan Prices")
    if scan then
        if scan.state == "waiting" then
            button.status:SetText("Waiting for auction data...")
        else
            local progress = (scan.index - #scan.pending) / math.max(1, scan.total)
            button.status:SetText(string.format("Scanning %d%%", math.floor(100 * progress)))
        end
    elseif cooldown > 0 then
        button.status:SetText(string.format("Available in %d:%02d", math.floor(cooldown / 60), cooldown % 60))
    else
        button.status:SetText("")
    end
    button:SetEnabled(open and not scan and cooldown == 0 and market ~= nil and addon.ScanSupported())
end

function addon.AttachButton()
    local parent = AuctionHouseFrame
    if not parent or not addon.options then
        return
    end
    if not button then
        button = CreateFrame("Button", "L7AuctionScannerScanButton", parent, "UIPanelButtonTemplate")
        button:SetSize(130, 22)
        button:SetPoint("TOPRIGHT", parent, "BOTTOMRIGHT", -12, -4)
        button.status = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        button.status:SetPoint("RIGHT", button, "LEFT", -10, 0)
        button.status:SetTextColor(0.7, 0.7, 0.7)
        button:SetMotionScriptsWhileDisabled(true)
        button:SetScript("OnClick", addon.StartScan)
        button:SetScript("OnEnter", function(self)
            local market = addon.DetectMarket()
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:ClearLines()
            GameTooltip:AddLine(addon.markets[market] or "Unknown auction house", 1, 1, 1)
            local snapshot = market and addon.Snapshot(market)
            if not addon.ScanSupported() then
                GameTooltip:AddLine("Scanning unavailable", 1, 0.3, 0.3)
            else
                GameTooltip:AddLine(snapshot and ("Scanned " .. addon.FormatAge(snapshot.scannedAt)) or "No saved scan", 0.7, 0.7, 0.7)
            end
            GameTooltip:Show()
        end)
        button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    button:Show()
    addon.UpdateButton()
    if not ticker then
        ticker = C_Timer.NewTicker(1, addon.UpdateButton)
    end
end

function addon.HideButton()
    if button then
        if GameTooltip:IsOwned(button) then
            GameTooltip:Hide()
        end
        button:Hide()
    end
    if ticker then
        ticker:Cancel()
        ticker = nil
    end
end

local function hookAuctionHouse()
    local parent = AuctionHouseFrame
    if not parent or not addon.options then
        return
    end
    if hookedFrame ~= parent then
        parent:HookScript("OnShow", function() addon.SetAuctionHouseOpen(true) end)
        parent:HookScript("OnHide", function() addon.SetAuctionHouseOpen(false) end)
        hookedFrame = parent
    end
    if parent:IsShown() then
        addon.SetAuctionHouseOpen(true)
    end
    driver:UnregisterEvent("ADDON_LOADED")
end

SLASH_L7AUCTIONSCANNER1 = "/l7ah"
SlashCmdList.L7AUCTIONSCANNER = function(message)
    if not addon.options then
        return
    end
    if not AuctionHouseFrame or not AuctionHouseFrame:IsShown() then
        print("Auction Scanner: open the auction house first.")
        return
    end
    addon.SetAuctionHouseOpen(true)
    addon.AttachButton()
    if message:lower():match("^%s*scan%s*$") then
        addon.StartScan()
    else
        print("Auction Scanner: click Scan Prices, or use /l7ah scan to start a manual scan.")
    end
end

local function registerOptions()
    local category = Settings.RegisterVerticalLayoutCategory("L7 Auction Scanner")
    local setting = Settings.RegisterProxySetting(
        category, "L7AuctionScanner_Market", Settings.VarType.String, "Tooltip auction house", UnitFactionGroup("player"),
        addon.SelectedMarket, function(value)
            if addon.markets[value] then
                addon.options.market = value
            end
        end
    )
    Settings.CreateDropdown(category, setting, function()
        local choices = Settings.CreateControlTextContainer()
        for _, market in ipairs({"Alliance", "Horde", "Neutral"}) do
            choices:Add(market, addon.markets[market])
        end
        return choices:GetData()
    end, "Show this auction house's last manual scan for your current region and ruleset. Visiting another auction house does not change this choice. Prices are per item; hold Shift for the total value of matching carried items. Auction prices are the lowest buyout, before fees.")
    Settings.RegisterAddOnCategory(category)
end

driver:RegisterEvent("ADDON_LOADED")
driver:SetScript("OnEvent", function(_, _, name)
    if name == addonName then
        addon.Initialize()
        registerOptions()
        addon.InstallTooltips()
        hookAuctionHouse()
    elseif name == "Blizzard_AuctionHouseUI" then
        hookAuctionHouse()
    end
end)
