local _, addon = ...
local recipes = {}
local indexed = {}

for _, profession in pairs(addon.catalogue) do
    for recipeID, record in pairs(profession) do
        if record.output and not indexed[recipeID] then
            indexed[recipeID] = record.output
            local output = recipes[record.output] or {}
            output[#output + 1] = recipeID
            recipes[record.output] = output
        end
    end
end
for _, output in pairs(recipes) do
    table.sort(output)
end

function addon.CreateReagentCostCalculator(market)
    local calculator = {}
    local quotes, schematics = {}, {}
    local visits = 0
    local allowCrafting = addon.options.craftReagents and Professions.InLocalCraftingMode()

    local function quote(id)
        if not quotes[id] then
            local auction, scannedAt
            if L7AuctionScanner and type(L7AuctionScanner.GetPrice) == "function" then
                auction, scannedAt = L7AuctionScanner.GetPrice(id, market)
            end
            calculator.scannedAt = scannedAt or calculator.scannedAt
            local vendor, offer = addon.GetVendorPrice(id)
            quotes[id] = {auction = auction, vendor = vendor, offer = offer, unit = vendor or auction}
        end
        return quotes[id]
    end

    local function recipe(id)
        if schematics[id] == nil then
            schematics[id] = false
            local ok, info = pcall(C_TradeSkillUI.GetRecipeInfo, id)
            if ok and info and info.learned and not info.disabled and not info.isRecraft then
                local valid, schematic = pcall(C_TradeSkillUI.GetRecipeSchematic, id, false)
                if valid and schematic and schematic.recipeType == Enum.TradeskillRecipeType.Item
                    and addon.Readable(schematic.quantityMin, "number") and schematic.quantityMin >= 1 then
                    local materials, counts = {}, {}
                    local supported = true
                    for _, slot in ipairs(schematic.reagentSlotSchematics) do
                        if slot.required or slot.reagentType == Enum.CraftingReagentType.Basic then
                            local reagent = slot.reagents[1]
                            local quantity = slot.quantityRequired
                            for _, variable in ipairs(slot.variableQuantities or {}) do
                                if reagent and variable.reagent.itemID == reagent.itemID then
                                    quantity = variable.quantity
                                    break
                                end
                            end
                            if #slot.reagents ~= 1 or not reagent or not addon.Readable(reagent.itemID, "number")
                                or reagent.itemID <= 0 or not addon.Readable(quantity, "number") or quantity <= 0 then
                                supported = false
                                break
                            end
                            if not counts[reagent.itemID] then
                                materials[#materials + 1] = reagent.itemID
                                counts[reagent.itemID] = 0
                            end
                            counts[reagent.itemID] = counts[reagent.itemID] + quantity
                        end
                    end
                    if supported and #materials > 0 then
                        local cooldown, day, charges, maximum = C_TradeSkillUI.GetRecipeCooldown(id)
                        local output = schematic.outputItemID
                        if not addon.Readable(output, "number") or output <= 0 then
                            output = indexed[id]
                        end
                        schematics[id] = {
                            id = id, name = info.name, output = output,
                            yield = schematic.quantityMin, materials = materials, counts = counts,
                            cooldown = cooldown, day = day, charges = charges, maximum = maximum,
                        }
                    end
                end
            end
        end
        return schematics[id] or nil
    end

    local resolve
    resolve = function(id, quantity, path, depth)
        local result = {id = id, quantity = quantity}
        if not addon.Readable(id, "number") or id <= 0 then
            return result
        end
        local purchase = quote(id)
        result.auction = purchase.auction and math.ceil(purchase.auction * quantity)
        result.vendor = purchase.vendor and math.ceil(purchase.vendor * quantity)
        result.offer = purchase.offer
        result.purchase = purchase.unit and math.ceil(purchase.unit * quantity)
        result.cost = result.purchase
        result.source = purchase.vendor and "Vendor" or (purchase.auction and "AH")
        visits = visits + 1
        if not allowCrafting or path[id] or depth >= 20 or visits > 1000 then
            return result
        end
        path[id] = true
        local best
        for _, recipeID in ipairs(recipes[id] or {}) do
            local craft = recipe(recipeID)
            if craft and craft.output == id then
                local function evaluate(casts, bought)
                    if casts <= 0 then
                        return
                    end
                    if craft.maximum and craft.maximum > 0 then
                        if not craft.charges or casts > craft.charges then
                            return
                        end
                    elseif (craft.cooldown and craft.cooldown > 0) or (craft.day and casts > 1) then
                        return
                    end
                    local plan = {
                        recipeID = recipeID, name = craft.name, casts = casts,
                        produced = casts * craft.yield, bought = bought, materials = {}, cost = 0,
                    }
                    for _, itemID in ipairs(craft.materials) do
                        local material = resolve(itemID, craft.counts[itemID] * casts, path, depth + 1)
                        if material.cost == nil then
                            return
                        end
                        plan.materials[#plan.materials + 1] = material
                        plan.cost = plan.cost + material.cost
                    end
                    if bought > 0 then
                        if purchase.unit == nil then
                            return
                        end
                        plan.purchaseCost = math.ceil(purchase.unit * bought)
                        plan.cost = plan.cost + plan.purchaseCost
                    end
                    if not best or plan.cost < best.cost then
                        best = plan
                    end
                end
                evaluate(math.ceil(quantity / craft.yield), 0)
                local remainder = quantity % craft.yield
                if remainder > 0 and purchase.unit ~= nil then
                    evaluate(math.floor(quantity / craft.yield), remainder)
                end
            end
        end
        path[id] = nil
        result.craft = best
        if best and (result.cost == nil or best.cost < result.cost) then
            result.cost = best.cost
            result.source = "Craft"
        end
        return result
    end

    function calculator:Resolve(id, quantity)
        return resolve(id, quantity, {}, 0)
    end

    return calculator
end
