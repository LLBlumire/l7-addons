local _, addon = ...

local schools = {
    arcane = true,
    fire = true,
    frost = true,
    holy = true,
    nature = true,
    physical = true,
    shadow = true,
    spell = true,
}

local function average(low, high)
    return string.format("%.8f", (tonumber(low) + tonumber(high)) / 2)
end

local function normalize(text)
    return text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
        :gsub("|H.-|h(.-)|h", "%1"):gsub("|T.-|t", ""):gsub("|A.-|a", "")
        :gsub("\194\160", " "):gsub("–", "-"):gsub("−", "-"):gsub(",", ""):lower()
        :gsub("between%s+(%d+%.?%d*)%s+and%s+(%d+%.?%d*)", average)
        :gsub("(%d+%.?%d*)%s+to%s+(%d+%.?%d*)", average)
        :gsub("(%d+%.?%d*)%s*%-%s*(%d+%.?%d*)", average)
        :gsub("%f[%a]seconds?%f[%A]", "sec"):gsub("%f[%a]minutes?%f[%A]", "min")
end

local function seconds(text, word)
    local amount, unit = text:match("%f[%a]" .. word .. "%s+(%d+%.?%d*)%s*(%a+)")
    amount = tonumber(amount)
    if amount and unit == "sec" then
        return amount
    elseif amount and unit == "min" then
        return amount * 60
    end
end

local function containsWord(text, words)
    for word in text:gmatch("%a+") do
        if words[word] then
            return true
        end
    end
    return false
end

local healingWords = {
    heal = true, heals = true, healing = true,
    restore = true, restores = true, restoring = true,
    regenerate = true, regenerates = true, regenerating = true,
}

local conditionalWords = {
    chance = true, whenever = true, ["if"] = true,
    increases = true, increased = true, reduces = true, reduced = true,
    absorbs = true, absorbing = true, absorb = true,
}

local function effectKind(before, after)
    local sentence = before:match(".*%.%s+(.*)$") or before
    sentence = sentence:match(".*[;\n](.*)$") or sentence
    if containsWord(sentence, conditionalWords) or after:match("^%s*%%") then
        return
    end
    if after:match("^%s+damage%f[%A]") or after:match("^%s+points? of damage%f[%A]") then
        return "damage"
    end
    local school = after:match("^%s+(%a+)%s+damage%f[%A]")
        or after:match("^%s+points? of (%a+)%s+damage%f[%A]")
    if schools[school] then
        return "damage"
    end
    if after:match("^%s+healing%f[%A]") then
        return "healing"
    end
    if after:match("^%s+health%f[%A]") then
        if sentence:find("drain") then
            return "damage", true
        elseif sentence:find("transfer") then
            if after:find("from%s+the%s+target") or after:find("from%s+target")
                or after:find("to%s+the%s+caster") then
                return "damage", true
            end
            return "healing"
        elseif containsWord(sentence, healingWords) then
            return "healing"
        end
    end
    if containsWord(sentence, healingWords) and
        (before:match("for%s*$") or before:match("another%s*$") or before:match("additional%s*$")
        or before:match("heals?%s*$") or before:match("restores?%s*$")) then
        local unit = after:match("^%s+(%a+)")
        if not unit or unit == "over" or unit == "every" or unit == "each" or unit == "per"
            or unit == "and" or unit == "plus" then
            return "healing"
        end
    end
end

function addon.ParseDescription(description)
    local text = normalize(description)
    if text:find("weapon", 1, true) or text:find("combo point", 1, true)
        or text:find("when hit", 1, true) or text:find("when struck", 1, true)
        or text:find("attackers", 1, true) or text:find("that strikes", 1, true)
        or text:find("each hit", 1, true) or text:find("per hit", 1, true) then
        return
    end
    local effects = {}
    local position = 1
    while true do
        local first, last = text:find("%d+%.?%d*", position)
        if not first then
            break
        end
        local before, after = text:sub(1, first - 1), text:sub(last + 1)
        local kind, transfer = effectKind(before, after)
        if not kind and #effects > 0 and (after:match("^%s+over%f[%A]") or after:match("^%s+every%f[%A]"))
            and (before:match("another%s*$") or before:match("additional%s*$") or before:match("plus%s*$")
                or before:match("and%s*$")) then
            kind = effects[#effects].kind
        end
        if kind then
            effects[#effects + 1] = {
                kind = kind,
                amount = tonumber(text:sub(first, last)),
                first = first,
                last = last,
                transfer = transfer,
            }
        end
        position = last + 1
    end
    for index, effect in ipairs(effects) do
        local following = effects[index + 1]
        local tail = text:sub(effect.last + 1, following and following.first - 1 or #text)
        if tail:find("for each", 1, true) or tail:find("per hit", 1, true) then
            return
        end
        local tick = seconds(tail, "every") or seconds(tail, "each")
        if not tick and (tail:find("per sec", 1, true) or tail:find("each sec", 1, true)
            or tail:find("every sec", 1, true)) then
            tick = 1
        end
        local duration = seconds(tail, "over")
        if tick then
            duration = duration or seconds(tail, "for") or seconds(text, "lasts")
            if not duration or duration <= 0 or tick <= 0 then
                return
            end
            effect.amount = effect.amount * math.floor(duration / tick + 0.000001)
        end
        if duration and duration <= 0 then
            return
        end
        effect.duration = duration
        if effect.kind == "damage" and not effect.transfer then
            for _, target in ipairs({"himself", "yourself", "the caster"}) do
                if tail:find("damage to " .. target, 1, true) then
                    effect.amount = 0
                end
            end
        end
    end
    if #effects == 0 then
        return
    end
    local healingPercent = text:match("heals?.-for%s+(%d+%.?%d*)%%%s+of%s+the%s+damage")
        or text:match("heals?.-for%s+(%d+%.?%d*)%%%s+of%s+damage")
    local damage, healing, duration = 0, 0, 0
    for _, effect in ipairs(effects) do
        if (text:find("summon", 1, true) or text:find("totem", 1, true)) and not effect.duration then
            return
        end
        if effect.kind == "damage" then
            damage = damage + effect.amount
            if effect.transfer then
                healing = healing + effect.amount
            end
        else
            healing = healing + effect.amount
        end
        duration = math.max(duration, effect.duration or 0)
    end
    if healing == 0 and healingPercent then
        healing = damage * tonumber(healingPercent) / 100
    end
    return {damage = damage, healing = healing, duration = duration}
end

function addon.Calculate(output, castTime, gcd, cooldown, channeled, mana, maximumMana)
    if channeled and output.duration <= 0 then
        return
    end
    local interval = math.max(castTime, gcd, output.duration,
        cooldown + (channeled and 0 or castTime))
    if interval <= 0 then
        return
    end
    local metrics = {}
    if output.damage > 0 then
        metrics.DPS = output.damage / interval
    end
    if output.healing > 0 then
        metrics.HPS = output.healing / interval
    end
    if mana then
        if maximumMana and maximumMana > 0 then
            metrics.MPS = mana / interval / maximumMana * 100
        end
        if output.damage > 0 then
            metrics.DPM = mana > 0 and output.damage / mana or math.huge
        end
        if output.healing > 0 then
            metrics.HPM = mana > 0 and output.healing / mana or math.huge
        end
    end
    return metrics
end
