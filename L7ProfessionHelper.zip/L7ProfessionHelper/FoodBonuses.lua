local _, addon = ...
local driver = CreateFrame("Frame")
local scrollBox
local queued = false
local cache = {}
local categories = {}
local itemLoads = {}
local instances = {}
local itemInstances = {}
local stats = {}
local statNames = {}
local categoryStats = {
    ["delightful drinks"] = "spirit",
    ["soothing drinks"] = "healing power",
    ["fisherman's delights"] = "fishing",
    ["combat prowess food"] = "critical strike",
}

for _, names in ipairs({
    {"Attack Power", "ATTACK_POWER", "ITEM_MOD_ATTACK_POWER_SHORT", short = "AP"},
    {"Healing Power", "Healing Done", "Healing", "ITEM_MOD_SPELL_HEALING_DONE_SHORT", short = "Heal"},
    {"Spell Damage", "Spell Power", "ITEM_MOD_SPELL_POWER_SHORT", short = "SP"},
    {"Strength", "STRENGTH", "ITEM_MOD_STRENGTH_SHORT", short = "Str"},
    {"Agility", "AGILITY", "ITEM_MOD_AGILITY_SHORT", short = "Agi"},
    {"Intellect", "INTELLECT", "ITEM_MOD_INTELLECT_SHORT", short = "Int"},
    {"Stamina", "STAMINA", "ITEM_MOD_STAMINA_SHORT", short = "Sta"},
    {"Spirit", "SPIRIT", "ITEM_MOD_SPIRIT_SHORT", short = "Spi"},
    {"Fishing", "Fishing Skill", "PROFESSIONS_FISHING"},
    {"Herbalism", "Herbalism Skill", "PROFESSIONS_HERBALISM"},
    {"Armor", "ARMOR", "ITEM_MOD_ARMOR_SHORT"},
    {"Movement Speed", short = "Speed"},
    {"Energy", "ENERGY"},
    {"Resistance", "Resistances", "ITEM_MOD_RESISTANCE_SHORT", short = "Resist"},
    {"Critical Strike", "Critical", "Crit", "ITEM_MOD_CRIT_RATING_SHORT", short = "Crit"},
    {"Haste", "ITEM_MOD_HASTE_RATING_SHORT"},
    {"Mana Regeneration", "Mana Regen", "ITEM_MOD_MANA_REGENERATION_SHORT"},
    {"Health Regeneration", "Health Regen", "ITEM_MOD_HEALTH_REGENERATION_SHORT"},
}) do
    local aliases = {}
    for _, name in ipairs(names) do
        local text = _G[name] or name
        if addon.Readable(text, "string") and text ~= "" then
            aliases[#aliases + 1] = text:lower()
        end
    end
    stats[#stats + 1] = aliases
    statNames[aliases] = {name = names[1], short = names.short or names[1]}
end

local function categoryStat(id)
    if not addon.Readable(id, "number") or id <= 0 then
        return
    end
    if categories[id] ~= nil then
        return categories[id] or nil
    end
    local info = C_TradeSkillUI.GetCategoryInfo(id)
    if not info or not addon.Readable(info.name, "string") then
        return
    end
    local name = info.name:lower()
    name = categoryStats[name] or name
    for _, aliases in ipairs(stats) do
        for _, alias in ipairs(aliases) do
            if name:find(alias, 1, true) then
                categories[id] = aliases
                return aliases
            end
        end
    end
    categories[id] = false
end

local function parseBonus(text, aliases)
    text = text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
        :gsub("|H.-|h(.-)|h", "%1"):lower()
    for _, alias in ipairs(aliases) do
        local pattern = alias:gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1"):gsub("%s+", "%%s+")
        local amount, percent = text:match("([%+%-]?%d[%d%.,]*)%s*(%%?)%s+" .. pattern)
        if not amount then
            amount, percent = text:match(pattern .. "%s+by%s+([%+%-]?%d[%d%.,]*)%s*(%%?)")
        end
        if not amount then
            amount, percent = text:match("([%+%-]?%d[%d%.,]*)%s*(%%?)%s+[%a%s]+%s+and%s+" .. pattern)
        end
        if amount then
            amount = amount:gsub("[%.,]$", "")
            return (amount:sub(1, 1) == "-" and "" or "+") .. amount:gsub("^%+", "") .. percent
        end
    end
end

local function foodBonus(id, aliases)
    local key = aliases or stats
    if cache[id] and cache[id][key] ~= nil then
        return cache[id][key] or nil
    end
    if not C_Item.IsItemDataCachedByID(id) and not itemLoads[id] then
        itemLoads[id] = true
        C_Item.RequestLoadItemDataByID(id)
    end
    local tooltip = C_TooltipInfo.GetItemByID(id)
    if not tooltip then
        return
    end
    if addon.Readable(tooltip.dataInstanceID, "number") then
        if itemInstances[id] then
            instances[itemInstances[id]] = nil
        end
        instances[tooltip.dataInstanceID] = id
        itemInstances[id] = tooltip.dataInstanceID
    end
    cache[id] = cache[id] or {}
    local values, labels = {}, {}
    for _, line in ipairs(tooltip.lines or {}) do
        if addon.Readable(line.leftText, "string") then
            for _, stat in ipairs(stats) do
                if not values[stat] then
                    local value = parseBonus(line.leftText, stat)
                    if value then
                        local name = statNames[stat].name
                        if name == "Movement Speed" then
                            local zone = line.leftText:match("[Mm]ovement%s+[Ss]peed%s+while in%s+(.-)%s+for%s+%d")
                            name = "Speed" .. (zone and (" (" .. zone .. ")") or "")
                        end
                        values[stat] = {value = value, name = name, stat = stat}
                    end
                end
            end
            local text = line.leftText:lower()
            if text:find("belch flame", 1, true) then
                labels["Fire proc"] = true
            elseif text:find("stamina-boosting food", 1, true) then
                labels["Stamina feast"] = true
            elseif text:find("eat me.", 1, true) then
                labels["Special effect"] = true
            end
        end
    end
    local bonuses = {}
    for _, stat in ipairs(stats) do
        if values[stat] then
            bonuses[#bonuses + 1] = values[stat]
        end
    end
    local result = {}
    for _, bonus in ipairs(bonuses) do
        local name = #bonuses > 1 and statNames[bonus.stat].short or bonus.name
        result[#result + 1] = bonus.value .. ((#bonuses == 1 and bonus.stat == aliases) and "" or (" " .. name))
    end
    for _, label in ipairs({"Fire proc", "Stamina feast", "Special effect"}) do
        if labels[label] then
            result[#result + 1] = label
        end
    end
    cache[id][key] = #result > 0 and table.concat(result, " / ") or false
    return cache[id][key] or nil
end

local function layoutBonus(row)
    local bonus = row.l7FoodBonus
    local bonusWidth = bonus:IsShown() and (bonus:GetStringWidth() + 8) or 0
    local lockedWidth = row.LockedIcon:IsShown() and row.LockedIcon:GetWidth() or 0
    local countWidth = row.Count:IsShown() and row.Count:GetStringWidth() or 0
    local available = math.max(1, row:GetWidth() - row.SkillUps:GetWidth() - lockedWidth - countWidth - bonusWidth - 10)
    row.Label:SetWidth(row:GetWidth())
    row.Label:SetWidth(math.min(available, row.Label:GetStringWidth()))
    bonus:ClearAllPoints()
    if row.LockedIcon:IsShown() then
        bonus:SetPoint("RIGHT", row.LockedIcon, "LEFT", -6, 0)
    else
        bonus:SetPoint("RIGHT", row, "RIGHT", -6, 0)
    end
end

local function updateRow(row, node)
    local data = node:GetData()
    local info = data.recipeInfo and (Professions.GetHighestLearnedRecipe(data.recipeInfo) or data.recipeInfo)
    local record = info and addon.catalogue[185][info.recipeID]
    if not info or (not record and not C_TradeSkillUI.IsRecipeInSkillLine(info.recipeID, 185)) then
        if row.l7FoodBonus then
            row.l7FoodBonus:Hide()
        end
        return
    end
    local aliases = categoryStat(info.categoryID)
    local output = record and record.output
    if not output then
        local schematic = C_TradeSkillUI.GetRecipeSchematic(info.recipeID, false)
        output = schematic and schematic.outputItemID
    end
    local value = addon.Readable(output, "number") and output > 0 and foodBonus(output, aliases)
    if not value then
        if row.l7FoodBonus and row.l7FoodBonus:IsShown() then
            row.l7FoodBonus:Hide()
            layoutBonus(row)
        end
        return
    end
    if not row.l7FoodBonus then
        row.l7FoodBonus = row:CreateFontString(nil, "OVERLAY")
        row.l7FoodBonus:SetFontObject(row.Label:GetFontObject())
        row.l7FoodBonus:SetTextColor(row:GetLabelColor():GetRGB())
        hooksecurefunc(row, "SetLabelFontColors", function(self, color)
            self.l7FoodBonus:SetTextColor(color:GetRGB())
        end)
        hooksecurefunc(row, "SetCraftableCount", function(self)
            if self.l7FoodBonus:IsShown() then
                layoutBonus(self)
            end
        end)
    end
    row.l7FoodBonus:SetText(value)
    row.l7FoodBonus:Show()
    layoutBonus(row)
end

local function refresh()
    if not queued and scrollBox then
        queued = true
        C_Timer.After(0, function()
            queued = false
            if scrollBox:IsShown() then
                scrollBox:ForEachFrame(updateRow)
            end
        end)
    end
end

function addon.InstallFoodBonuses()
    if scrollBox or not ProfessionsFrame or not ProfessionsFrame.CraftingPage then
        return
    end
    scrollBox = ProfessionsFrame.CraftingPage.RecipeList.ScrollBox
    scrollBox:RegisterCallback(ScrollBoxListMixin.Event.OnInitializedFrame, function(_, row, node)
        updateRow(row, node)
    end, driver)
    scrollBox:HookScript("OnShow", refresh)
    scrollBox:HookScript("OnSizeChanged", refresh)
    driver:UnregisterEvent("ADDON_LOADED")
    driver:RegisterEvent("ITEM_DATA_LOAD_RESULT")
    driver:RegisterEvent("TOOLTIP_DATA_UPDATE")
    driver:RegisterEvent("PLAYER_LEVEL_UP")
    refresh()
end

driver:RegisterEvent("ADDON_LOADED")
driver:SetScript("OnEvent", function(_, event, id)
    if event == "ADDON_LOADED" then
        addon.InstallFoodBonuses()
    elseif event == "PLAYER_LEVEL_UP" then
        cache, instances, itemInstances = {}, {}, {}
        refresh()
    elseif event == "ITEM_DATA_LOAD_RESULT" and addon.Readable(id, "number") and itemLoads[id] then
        cache[id] = nil
        refresh()
    elseif event == "TOOLTIP_DATA_UPDATE" and addon.Readable(id, "number") and instances[id] then
        cache[instances[id]] = nil
        refresh()
    end
end)
