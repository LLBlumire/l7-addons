local addonName, addon = ...
local driver = CreateFrame("Frame")
local recipes = {}
local schematics = {}
local itemLoads = {}
local refreshQueued = false
local showCannotLearn = false
local getNativeSourceText

for _, profession in pairs(addon.catalogue) do
    for id, record in pairs(profession) do
        recipes[id] = record
    end
end

local function queueRefresh()
    if refreshQueued then
        return
    end
    refreshQueued = true
    C_Timer.After(0, function()
        refreshQueued = false
        local frame = ProfessionsFrame
        if frame and frame.CraftingPage:IsShown() and not C_TradeSkillUI.IsDataSourceChanging() then
            local page = frame.CraftingPage
            page:Refresh(Professions.GetProfessionInfo())
        end
    end)
end

local function placeholderName(name)
    if type(name) ~= "string" or not name:find("%S") then
        return true
    end
    name = name:lower():match("^%s*(.-)%s*$")
    for _, marker in ipairs({"ph", "dnt", "test", "unused", "deprecated", "placeholder", "dummy"}) do
        if name:find("%[" .. marker .. "%]") or name:find("%(" .. marker .. "%)") then
            return true
        end
    end
    for _, marker in ipairs({"test", "unused", "deprecated", "placeholder", "dummy", "dnt"}) do
        if name == marker or name:find("^" .. marker .. "[%s:_%-]") then
            return true
        end
    end
    return name:find("^zzold") ~= nil or name:find("^zzz") ~= nil
end

local function matchesFilters(info, record, skill)
    local query = C_TradeSkillUI.GetRecipeItemNameFilter()
    if query and query ~= "" and not info.name:lower():find(query:lower(), 1, true) then
        return false
    end
    if C_TradeSkillUI.GetOnlyShowSkillUpRecipes() then
        local maximum = info.maxTrivialLevel
        if type(maximum) ~= "number" or maximum <= 0 then
            maximum = record.difficulty and record.difficulty[4]
        end
        if info.relativeDifficulty == Enum.TradeskillRelativeDifficulty.Trivial
            or (type(skill) == "number" and type(record.skill) == "number" and skill < record.skill)
            or (type(skill) == "number" and type(maximum) == "number" and skill >= maximum)
            or not info.canSkillUp then
            return false
        end
    end
    if C_TradeSkillUI.AreAnyInventorySlotsFiltered() then
        if not record.output then
            return false
        end
        local _, _, _, equipLoc = C_Item.GetItemInfoInstant(record.output)
        local slotName = equipLoc and _G[equipLoc]
        local matched = false
        for index = 1, C_TradeSkillUI.GetAllFilterableInventorySlotsCount() do
            if slotName == C_TradeSkillUI.GetFilterableInventorySlotName(index) then
                matched = true
                if C_TradeSkillUI.IsInventorySlotFiltered(index) then
                    return false
                end
            end
        end
        if not matched then
            return false
        end
    end
    return true
end

local function hasMaterials(schematic)
    local items, currencies = {}, {}
    for _, slot in ipairs(schematic.reagentSlotSchematics) do
        if slot.required or slot.reagentType == Enum.CraftingReagentType.Basic then
            local needed = slot.quantityRequired
            for _, reagent in ipairs(slot.reagents) do
                local counts = reagent.itemID and items or currencies
                local id = reagent.itemID or reagent.currencyID
                if counts[id] == nil then
                    counts[id] = ProfessionsUtil.GetReagentQuantityInPossession(reagent)
                end
                local used = math.min(needed, counts[id])
                counts[id] = counts[id] - used
                needed = needed - used
                if needed <= 0 then
                    break
                end
            end
            if needed > 0 then
                return false
            end
        end
    end
    return true
end

local function outputAvailable(schematic, record)
    local id = schematic.outputItemID
    if type(id) ~= "number" or id <= 0 then
        id = record.output
    end
    if type(id) ~= "number" or id <= 0 then
        return schematic.recipeType ~= Enum.TradeskillRecipeType.Item
    end
    if C_Item.IsItemDataCachedByID(id) then
        local name = C_Item.GetItemInfo(id)
        return not placeholderName(name)
    end
    if not C_Item.DoesItemExistByID(id) then
        return false
    end
    if itemLoads[id] == nil then
        itemLoads[id] = "pending"
        C_Item.RequestLoadItemDataByID(id)
    end
    if itemLoads[id] == true then
        local name = C_Item.GetItemInfo(id)
        return not placeholderName(name)
    end
    return false
end

local function sortCategoryInfo(left, right)
    if left.uiOrder ~= right.uiOrder then
        return left.uiOrder < right.uiOrder
    end
    local order = strcmputf8i(left.name, right.name)
    return order < 0 or (order == 0 and left.categoryID < right.categoryID)
end

local function sortCategories(a, b)
    return sortCategoryInfo(a.info, b.info)
end

local function sortRecipes(a, b)
    local left, right = a.difficulty or 0, b.difficulty or 0
    if left ~= right then
        return left < right
    end
    left, right = a.maxTrivialLevel or 0, b.maxTrivialLevel or 0
    if left ~= right then
        return left > right
    end
    left, right = a.itemLevel or 0, b.itemLevel or 0
    if left ~= right then
        return left > right
    end
    local order = strcmputf8i(a.name, b.name)
    return order < 0 or (order == 0 and a.recipeID < b.recipeID)
end

local function sortCategoryNodes(a, b)
    local left, right = a:GetData(), b:GetData()
    local leftStatus, rightStatus = left.l7Status or 0, right.l7Status or 0
    if leftStatus ~= rightStatus then
        return leftStatus < rightStatus
    end
    if left.categoryInfo and right.categoryInfo then
        return sortCategoryInfo(left.categoryInfo, right.categoryInfo)
    elseif left.categoryInfo or right.categoryInfo then
        return left.categoryInfo ~= nil
    end
    if left.order ~= right.order then
        return left.order < right.order
    end
    if left.recipeInfo and right.recipeInfo then
        return sortRecipes(left.recipeInfo, right.recipeInfo)
    end
    return false
end

local function addRecipeGroup(provider, group, name, entries, searching, noStripCategories, collapses)
    if #entries == 0 then
        return
    end
    local root = provider:GetRootNode()
    local existing = {}
    for _, node in provider:EnumerateEntireRange() do
        local info = node:GetData().categoryInfo
        if info and info.categoryID >= 0 then
            existing[info.categoryID] = node
        end
    end
    root:SetSortComparator(function(a, b)
        local left, right = a:GetData(), b:GetData()
        if left.group ~= right.group then
            return left.group < right.group
        end
        return sortCategoryInfo(left.categoryInfo, right.categoryInfo)
    end, false, false)

    local categories = {}
    local function getCategory(id)
        if not id or id == 0 then
            return
        end
        if not categories[id] then
            local ok, info = pcall(C_TradeSkillUI.GetCategoryInfo, id)
            if not ok or type(info) ~= "table" or type(info.name) ~= "string" or not info.name:find("%S") then
                return
            end
            info = CopyTable(info)
            info.categoryID = id
            info.uiOrder = info.uiOrder or 1000000
            categories[id] = {info = info, children = {}, recipes = {}}
            getCategory(info.parentCategoryID)
        end
        return categories[id]
    end

    for _, info in ipairs(entries) do
        local category = getCategory(info.categoryID)
        if not category then
            categories[0] = categories[0] or {
                info = {name = OTHER, categoryID = 0, uiOrder = 1000000}, children = {}, recipes = {},
            }
            category = categories[0]
        end
        category.recipes[#category.recipes + 1] = info
    end

    if not searching then
        for _, info in ipairs(Professions.GetProfessionCategories()) do
            local id = info.categoryID
            local category = categories[id]
            if category and #category.recipes == 0 and not existing[id]
                and not (noStripCategories and tContains(noStripCategories, id)) then
                categories[id] = nil
            end
        end
    end

    local roots = {}
    for _, category in pairs(categories) do
        local parent = categories[category.info.parentCategoryID]
        local children = parent and parent.children or roots
        children[#children + 1] = category
    end

    local function attach(parent, children)
        table.sort(children, sortCategories)
        for _, category in ipairs(children) do
            local id = category.info.categoryID
            local node = existing[id]
            if not node then
                local info = CopyTable(category.info)
                info.hasProgressBar = false
                info.unlearned = false
                node = parent:Insert({categoryInfo = info, group = 2})
                existing[id] = node
                if collapses and collapses[id] then
                    node:SetCollapsed(true)
                end
            end
            node:SetSortComparator(sortCategoryNodes, false, false)
            attach(node, category.children)
            if #category.recipes > 0 then
                local sectionID = -(id * 10 + group)
                local section = node:Insert({
                    categoryInfo = {name = name, categoryID = sectionID, uiOrder = group, unlearned = true},
                    group = group,
                    l7Status = group,
                })
                if collapses and collapses[sectionID] then
                    section:SetCollapsed(true)
                end
                table.sort(category.recipes, sortRecipes)
                section:Insert({topPadding = true, order = -1})
                for _, recipe in ipairs(category.recipes) do
                    section:Insert({recipeInfo = recipe, order = 0})
                end
                section:Insert({bottomPadding = true, order = 1})
            end
        end
    end
    attach(root, roots)
end

local function addUnlearned(provider, professionID, searching, noStripCategories, collapses)
    local catalogue = addon.catalogue[professionID]
    if not catalogue or (not C_TradeSkillUI.GetShowUnlearned() and not showCannotLearn)
        or C_TradeSkillUI.IsDataSourceChanging() or not Professions.InLocalCraftingMode() then
        return provider
    end

    local candidates = {}
    for _, node in provider:EnumerateEntireRange() do
        local info = node:GetData().recipeInfo
        if info and not info.learned then
            candidates[info.recipeID] = info
        end
    end
    for id, record in pairs(catalogue) do
        if not candidates[id] and not (record.hidden and not record.hiddenBorrowed) then
            local ok, info = pcall(C_TradeSkillUI.GetRecipeInfo, id)
            if ok and type(info) == "table" and info.learned == false then
                candidates[id] = info
            end
        end
    end

    local unlearned, cannotLearn = {}, {}
    local skill = Professions.GetProfessionInfo().skillLevel
    for id, info in pairs(candidates) do
        local record = catalogue[id] or {}
        local tooHigh = type(record.skill) == "number" and type(skill) == "number" and record.skill > skill
        local visible = (tooHigh and showCannotLearn) or (not tooHigh and C_TradeSkillUI.GetShowUnlearned())
        if visible and not placeholderName(info.name)
            and not info.isDummyRecipe and not info.isRecraft
            and not (record.hidden and not record.hiddenBorrowed) and matchesFilters(info, record, skill) then
            if not schematics[id] then
                local ok, schematic = pcall(C_TradeSkillUI.GetRecipeSchematic, id, false)
                if ok and type(schematic) == "table" and type(schematic.reagentSlotSchematics) == "table" then
                    schematics[id] = schematic
                end
            end
            if schematics[id] and (not C_TradeSkillUI.GetOnlyShowMakeableRecipes() or hasMaterials(schematics[id]))
                and outputAvailable(schematics[id], record) then
                local entries = tooHigh and cannotLearn or unlearned
                entries[#entries + 1] = info
            end
        end
    end

    local root = provider:GetRootNode()
    for index = #root:GetNodes(), 1, -1 do
        local node = root:GetNodes()[index]
        local group = node:GetData().group
        if group == 3 or group == 4 then
            root:Remove(node)
        end
    end
    addRecipeGroup(provider, 4, PROFESSIONS_CATEGORY_UNLEARNED, unlearned, searching, noStripCategories, collapses)
    addRecipeGroup(provider, 6, "Cannot Learn", cannotLearn, searching, noStripCategories, collapses)
    return provider
end

local function showSkillRanges(row)
    if not row.SkillUps or not GameTooltip:IsShown() or not GameTooltip:IsOwned(row.SkillUps) then
        return
    end
    local node = row:GetElementData()
    local info = node and node:GetData().recipeInfo
    info = info and (Professions.GetHighestLearnedRecipe(info) or info)
    local record = info and recipes[info.recipeID]
    local bounds = record and record.difficulty
    if not bounds or #bounds ~= 4 then
        return
    end

    GameTooltip:AddLine(" ")
    GameTooltip_AddHighlightLine(GameTooltip, "Skill-up ranges")
    for index, tier in ipairs({
        {"Orange", DIFFICULT_DIFFICULTY_COLOR}, {"Yellow", FAIR_DIFFICULTY_COLOR},
        {"Green", EASY_DIFFICULTY_COLOR}, {"Grey", GRAY_FONT_COLOR},
    }) do
        local first, following = bounds[index], bounds[index + 1]
        local range
        if not following then
            range = first .. "+"
        elseif following <= first then
            range = "—"
        elseif following == first + 1 then
            range = tostring(first)
        else
            range = first .. "–" .. (following - 1)
        end
        local r, g, b = tier[2]:GetRGB()
        GameTooltip:AddDoubleLine(tier[1], range, r, g, b, r, g, b)
    end
    GameTooltip:Show()
end

local function itemLink(id)
    local _, link = C_Item.GetItemInfo(id)
    return link or ("|Hitem:" .. id .. "|h[Recipe item " .. id .. "]|h")
end

local function sourceList(ids, count, kind)
    local result = {}
    for index = 1, math.min(#ids, 3) do
        local id = ids[index]
        if kind == "q" then
            result[#result + 1] = "Quest " .. id
        elseif kind == "c" then
            result[#result + 1] = itemLink(id)
        else
            local name = addon.sourceNames[id] or ("NPC " .. id)
            local faction = addon.sourceFactions[id]
            result[#result + 1] = name .. (faction and (" (" .. faction .. ")") or "")
        end
    end
    local remaining = (count or #ids) - #result
    if remaining > 0 then
        result[#result + 1] = "and " .. remaining .. " others"
    end
    return table.concat(result, ", ")
end

local function sourceText(record)
    local lines = {}
    if record.skill then
        lines[#lines + 1] = "Required skill: " .. record.skill
            .. (record.skillBorrowed and " (Classic estimate)" or "")
    end
    if record.item then
        lines[#lines + 1] = "Learn from: " .. itemLink(record.item)
    end
    if record.acquire == 1 then
        lines[#lines + 1] = "Learned automatically with the profession."
    end
    if record.vendors then
        lines[#lines + 1] = "Forever vendor: " .. sourceList(record.vendors, nil, "v")
    end
    if record.sources then
        if record.sourcesBorrowed then
            lines[#lines + 1] = "Classic sources (unconfirmed in Forever):"
        end
        for _, entry in ipairs({{"t", "Trainer"}, {"v", "Vendor"}, {"d", "Drop"}, {"q", "Quest"}, {"c", "Container"}}) do
            local key, label = entry[1], entry[2]
            local ids = record.sources[key]
            if ids and #ids > 0 then
                lines[#lines + 1] = label .. ": " .. sourceList(ids, record.sources[key .. "n"], key)
            end
        end
    elseif not record.vendors and record.acquire ~= 1 then
        lines[#lines + 1] = "Source not recorded for Forever."
    end
    if record.hidden and record.hiddenBorrowed then
        lines[#lines + 1] = "Availability is unconfirmed for Forever."
    end
    return table.concat(lines, "\n")
end

local function installCategoryClicks()
    local panel = ProfessionsFrame.CraftingPage
    local scrollBox = panel.RecipeList.ScrollBox
    hooksecurefunc(panel, "StoreCollapses", function(self, box)
        local provider = box:GetDataProvider()
        local collapses = self:GetCollapses()
        if provider and collapses then
            for _, node in provider:EnumerateEntireRange() do
                local info = node:GetData().categoryInfo
                if info then
                    collapses[info.categoryID] = node:IsCollapsed() or nil
                end
            end
        end
    end)
    local function initialize(row, node)
        if not node:GetData().categoryInfo or row.l7CategoryClick then
            return
        end
        row.l7CategoryClick = true
        row:HookScript("OnClick", function(self, buttonName)
            if buttonName ~= "LeftButton" then
                return
            end
            local category = self:GetElementData()
            local provider = scrollBox:GetDataProvider()
            if not provider or not category or not category:GetData().categoryInfo then
                return
            end
            if IsShiftKeyDown() and category:IsCollapsed() then
                provider:CollapseAll()
                scrollBox:ForEachFrame(function(button, data)
                    if data:GetData().categoryInfo then
                        button:UpdateCollapsedState(data:IsCollapsed())
                    end
                end)
            end
            panel:StoreCollapses(scrollBox)
        end)
    end
    scrollBox:RegisterCallback(ScrollBoxListMixin.Event.OnInitializedFrame, function(_, row, node)
        initialize(row, node)
    end, driver)
    scrollBox:ForEachFrame(initialize)
end

local function install()
    if not ProfessionsFrame or not ProfessionsFrame.CraftingPage or type(Professions) ~= "table"
        or type(Professions.GetDefaultShowUnlearned) ~= "function"
        or type(Professions.SetDefaultFilters) ~= "function"
        or type(Professions.GenerateCraftingDataProvider) ~= "function"
        or type(C_TradeSkillUI.GetRecipeSourceText) ~= "function"
        or type(Menu) ~= "table" or type(Menu.ModifyMenu) ~= "function" then
        return
    end

    Professions.GetDefaultShowUnlearned = C_TradeSkillUI.GetShowUnlearned

    hooksecurefunc(Professions, "SetDefaultFilters", function()
        showCannotLearn = false
        C_TradeSkillUI.SetShowUnlearned(true)
        queueRefresh()
    end)

    local generate = Professions.GenerateCraftingDataProvider
    Professions.GenerateCraftingDataProvider = function(professionID, searching, noStripCategories, collapses)
        local panel = ProfessionsFrame.CraftingPage
        local scrollBox = panel.RecipeList.ScrollBox
        local current = scrollBox:GetDataProvider()
        if current and current.l7ProfessionID == professionID then
            panel:StoreCollapses(scrollBox)
            collapses = panel:GetCollapses()
        end
        local provider = addUnlearned(generate(professionID, searching, noStripCategories, collapses),
            professionID, searching, noStripCategories, collapses)
        provider.l7ProfessionID = professionID
        return provider
    end

    getNativeSourceText = C_TradeSkillUI.GetRecipeSourceText
    C_TradeSkillUI.GetRecipeSourceText = function(id)
        local text = getNativeSourceText(id)
        if text and text ~= "" then
            return text
        end
        local record = recipes[id]
        return record and sourceText(record) or text
    end

    installCategoryClicks()

    Menu.ModifyMenu("MENU_PROFESSIONS_FILTER", function(_, rootDescription)
        rootDescription:CreateDivider()
        rootDescription:CreateCheckbox(PROFESSION_RECIPES_SHOW_LEARNED, C_TradeSkillUI.GetShowLearned, function()
            C_TradeSkillUI.SetShowLearned(not C_TradeSkillUI.GetShowLearned())
            queueRefresh()
        end)
        rootDescription:CreateCheckbox(PROFESSION_RECIPES_SHOW_UNLEARNED, C_TradeSkillUI.GetShowUnlearned, function()
            C_TradeSkillUI.SetShowUnlearned(not C_TradeSkillUI.GetShowUnlearned())
            queueRefresh()
        end)
        rootDescription:CreateCheckbox("Show Cannot Learn", function() return showCannotLearn end, function()
            showCannotLearn = not showCannotLearn
            queueRefresh()
        end)
    end)

    local tooltipQueued = {}
    EventRegistry:RegisterCallback("Professions.RecipeListOnEnter", function(_, row)
        if not tooltipQueued[row] then
            tooltipQueued[row] = true
            C_Timer.After(0, function()
                tooltipQueued[row] = nil
                showSkillRanges(row)
            end)
        end
    end, driver)

    C_TradeSkillUI.SetShowUnlearned(true)
    addon.InstallPricing()
    addon.InstallFoodBonuses()
    queueRefresh()
    driver:UnregisterEvent("ADDON_LOADED")
end

driver:RegisterEvent("ADDON_LOADED")
driver:RegisterEvent("ITEM_DATA_LOAD_RESULT")
driver:SetScript("OnEvent", function(_, event, name, success)
    if event == "ITEM_DATA_LOAD_RESULT" then
        if itemLoads[name] ~= nil then
            itemLoads[name] = success
            queueRefresh()
        end
    elseif name == addonName or name == "Blizzard_ProfessionsTemplates"
        or name == "Blizzard_Professions" or name == "Blizzard_Menu" then
        install()
    end
end)
