local _, addon = ...
local driver = CreateFrame("Frame")
local scan
local open = false
local requesting = false

local function announce(message)
    print("Auction Scanner: " .. message)
end

function addon.ScanSupported()
    local api = C_AuctionHouse
    return api and type(api.ReplicateItems) == "function"
        and type(api.GetNumReplicateItems) == "function"
        and type(api.GetReplicateItemInfo) == "function"
        and type(api.GetReplicateItemLink) == "function"
end

function addon.ScanState()
    return scan, open, math.max(0, math.ceil(addon.options.nextScanAt - addon.Now()))
end

local function stop(message)
    if scan then
        if scan.ticker then
            scan.ticker:Cancel()
        end
        if scan.timeout then
            scan.timeout:Cancel()
        end
    end
    scan = nil
    driver:UnregisterEvent("REPLICATE_ITEM_LIST_UPDATE")
    if message then
        announce(message)
    end
    addon.UpdateButton()
end

local function sameMarket()
    local market, guid = addon.DetectMarket()
    return open and addon.Context() == scan.context and market == scan.market and guid == scan.auctioneer
end

local function save()
    if not sameMarket() then
        stop("Auction house changed; previous prices kept.")
        return
    end
    local stores = addon.db.contexts[scan.context]
    if not stores then
        stores = {}
        addon.db.contexts[scan.context] = stores
    end
    stores[scan.market] = {
        prices = scan.prices, variants = scan.variants, scannedAt = addon.Now(),
        requestedAt = scan.requestedAt, auctions = scan.total, items = scan.items,
    }
    local message = string.format("%s scan saved: %d items from %d auctions.",
        addon.markets[scan.market], scan.items, scan.total)
    stop(message)
end

local function read(index)
    local _, _, count, _, _, _, _, _, _, buyout, _, _, _, _, _, status, id = C_AuctionHouse.GetReplicateItemInfo(index)
    if not addon.Readable(buyout, "number") or not addon.Readable(count, "number")
        or not addon.Readable(id, "number") then
        return false
    end
    if buyout <= 0 or status == 1 then
        return true
    end
    if count <= 0 or id <= 0 then
        return false
    end
    local key, linkedID = addon.ItemKey(C_AuctionHouse.GetReplicateItemLink(index))
    if not key or linkedID ~= id then
        if not scan.requested[id] then
            scan.requested[id] = true
            C_Item.RequestLoadItemDataByID(id)
        end
        return false
    end
    local price = math.ceil(buyout / count)
    if not scan.prices[id] then
        scan.items = scan.items + 1
    end
    scan.prices[id] = math.min(scan.prices[id] or price, price)
    scan.variants[key] = math.min(scan.variants[key] or price, price)
    return true
end

local function process()
    if not sameMarket() then
        stop("Auction house changed; previous prices kept.")
        return
    end
    if C_AuctionHouse.GetNumReplicateItems() ~= scan.total then
        stop("Auction results changed during the scan; previous prices kept.")
        return
    end
    local deadline = debugprofilestop() + 4
    local processed = 0
    while scan.index < scan.total and processed < 500 and debugprofilestop() < deadline do
        if not read(scan.index) then
            scan.pending[#scan.pending + 1] = scan.index
        end
        scan.index = scan.index + 1
        processed = processed + 1
    end
    if scan.index >= scan.total then
        local checked = 0
        while #scan.pending > 0 and checked < 100 and debugprofilestop() < deadline do
            scan.retry = scan.retry % #scan.pending + 1
            if read(scan.pending[scan.retry]) then
                scan.pending[scan.retry] = scan.pending[#scan.pending]
                scan.pending[#scan.pending] = nil
                scan.retry = scan.retry - 1
            end
            checked = checked + 1
        end
        if #scan.pending == 0 then
            save()
            return
        end
    end
    addon.UpdateButton()
end

function addon.StartScan()
    if scan or not open then
        return
    end
    if not addon.ScanSupported() then
        announce("Full auction scans are unavailable on this client.")
        return
    end
    local market, guid = addon.DetectMarket()
    if not market then
        announce("Unable to identify this auction house; no scan started.")
        return
    end
    local context = addon.Context()
    if not context then
        announce("Unable to identify the current region or ruleset; no scan started.")
        return
    end
    local _, _, cooldown = addon.ScanState()
    if cooldown > 0 then
        announce("The full-scan cooldown has not elapsed.")
        return
    end
    if C_AuctionHouse.IsThrottledMessageSystemReady and not C_AuctionHouse.IsThrottledMessageSystemReady() then
        announce("The auction house is busy. Try the scan button again when the current query finishes.")
        return
    end
    scan = {context = context, market = market, auctioneer = guid, state = "waiting"}
    driver:RegisterEvent("REPLICATE_ITEM_LIST_UPDATE")
    local current = scan
    scan.timeout = C_Timer.NewTimer(120, function()
        if scan == current then
            stop("Scan timed out; previous prices kept. Another addon may have used the shared full-scan cooldown.")
        end
    end)
    scan.requestedAt = addon.Now()
    requesting = true
    local ok = pcall(C_AuctionHouse.ReplicateItems)
    requesting = false
    if not ok then
        stop("The auction house rejected the scan; previous prices kept.")
        return
    end
    addon.options.nextScanAt = addon.Now() + 15 * 60
    announce("Scanning " .. addon.markets[market] .. ". Previous prices remain until the scan completes.")
    addon.UpdateButton()
end

function addon.SetAuctionHouseOpen(shown)
    if shown then
        open = true
        C_Timer.After(0, function()
            if open then
                addon.AttachButton()
            end
        end)
    else
        open = false
        stop(scan and "Scan cancelled; previous prices kept." or nil)
        addon.HideButton()
    end
end

driver:SetScript("OnEvent", function(_, event, interactionType)
    local auctioneer = interactionType == Enum.PlayerInteractionType.Auctioneer
    if event == "AUCTION_HOUSE_SHOW" or (event == "PLAYER_INTERACTION_MANAGER_FRAME_SHOW" and auctioneer) then
        addon.SetAuctionHouseOpen(true)
    elseif event == "AUCTION_HOUSE_CLOSED" or event == "PLAYER_LEAVING_WORLD"
        or (event == "PLAYER_INTERACTION_MANAGER_FRAME_HIDE" and auctioneer) then
        addon.SetAuctionHouseOpen(false)
    elseif event == "REPLICATE_ITEM_LIST_UPDATE" and scan and scan.state == "waiting" then
        local total = C_AuctionHouse.GetNumReplicateItems()
        if not addon.Readable(total, "number") or total < 0 then
            stop("Invalid auction results; previous prices kept.")
            return
        end
        scan.total, scan.index, scan.items, scan.retry = total, 0, 0, 0
        scan.prices, scan.variants, scan.pending, scan.requested = {}, {}, {}, {}
        scan.state = "processing"
        driver:UnregisterEvent("REPLICATE_ITEM_LIST_UPDATE")
        scan.ticker = C_Timer.NewTicker(0.05, process)
        addon.UpdateButton()
    end
end)

driver:RegisterEvent("AUCTION_HOUSE_SHOW")
driver:RegisterEvent("AUCTION_HOUSE_CLOSED")
driver:RegisterEvent("PLAYER_LEAVING_WORLD")
driver:RegisterEvent("PLAYER_INTERACTION_MANAGER_FRAME_SHOW")
driver:RegisterEvent("PLAYER_INTERACTION_MANAGER_FRAME_HIDE")

if addon.ScanSupported() then
    hooksecurefunc(C_AuctionHouse, "ReplicateItems", function()
        if scan and not requesting then
            stop("Another full scan started; previous prices kept.")
        end
    end)
end
