local addonName, addon = ...
local driver = CreateFrame("Frame")
local capitals = {
    [84] = true, [85] = true, [87] = true, [88] = true, [89] = true, [90] = true,
    [1453] = true, [1454] = true, [1455] = true, [1456] = true, [1457] = true, [1458] = true,
}

function addon.Readable(value, kind)
    return not (issecretvalue and issecretvalue(value)) and type(value) == kind
end

function addon.SetCraftReagents(value)
    addon.options.craftReagents = value == true
    addon.RefreshPricing()
end

local function offers()
    local context = GetCurrentRegion() .. ":" .. C_GameRules.GetCurrentGameModeRecordID()
    local contexts = addon.options.vendors
    contexts[context] = contexts[context] or {}
    return contexts[context]
end

function addon.GetVendorPrice(id)
    local base = addon.vendorPrices[id]
    local cheapest, capital
    local function consider(offer)
        if not cheapest or offer.price < cheapest.price then
            cheapest = offer
        end
        if offer.capital and (not capital or offer.price < capital.price) then
            capital = offer
        end
    end
    local faction = UnitFactionGroup("player")
    local observed = offers()[id] or {}
    local names = {}
    for _, offer in pairs(observed) do
        if offer.name then
            names[offer.name] = true
        end
    end
    for _, offer in ipairs(base and base.offers or {}) do
        if not names[offer.name] and (not offer.faction or offer.faction == faction) then
            consider(offer)
        end
    end
    for _, offer in pairs(observed) do
        consider(offer)
    end
    if base then
        cheapest = cheapest or base
        if base.capital then
            capital = capital or base
        end
    end
    local offer = addon.options.vendorPricing == "Capital City" and capital or cheapest
    if offer then
        return offer.price, offer
    end
end

local function inCapital()
    local id = C_Map.GetBestMapForUnit("player")
    local seen = {}
    while id and not seen[id] do
        if capitals[id] then
            return true
        end
        seen[id] = true
        local info = C_Map.GetMapInfo(id)
        id = info and info.parentMapID
    end
    return false
end

local function recordMerchant()
    if not addon.options or not MerchantFrame or not MerchantFrame:IsShown() then
        return
    end
    local guid = UnitGUID("npc")
    local npc = addon.Readable(guid, "string") and guid:match("^Creature%-%d+%-%d+%-%d+%-%d+%-(%d+)%-")
    if not npc then
        return
    end
    local records = offers()
    local capital = inCapital()
    local name = UnitName("npc")
    local now = GetServerTime()
    local prices = {}
    for index = 1, GetMerchantNumItems() do
        local id = GetMerchantItemID(index)
        local info = C_MerchantFrame.GetItemInfo(index)
        if addon.Readable(id, "number") and info and not info.hasExtendedCost
            and addon.Readable(info.price, "number") and info.price > 0
            and addon.Readable(info.stackCount, "number") and info.stackCount > 0 then
            local price = info.price / info.stackCount
            if not prices[id] or price < prices[id].price then
                prices[id] = {
                    price = price, capital = capital, name = name,
                    limited = info.numAvailable ~= -1, seenAt = now,
                }
            end
        end
    end
    for id, offer in pairs(prices) do
        records[id] = records[id] or {}
        records[id][npc] = offer
    end
    if addon.RefreshPricing then
        addon.RefreshPricing()
    end
end

local function initialize()
    if type(L7ProfessionHelperCharacterDB) ~= "table" then
        L7ProfessionHelperCharacterDB = {}
    end
    addon.options = L7ProfessionHelperCharacterDB
    if addon.options.vendorPricing ~= "Cheapest" and addon.options.vendorPricing ~= "Capital City" then
        addon.options.vendorPricing = "Capital City"
    end
    if type(addon.options.vendors) ~= "table" then
        addon.options.vendors = {}
    end
    if type(addon.options.craftReagents) ~= "boolean" then
        addon.options.craftReagents = false
    end
    local category = Settings.RegisterVerticalLayoutCategory("L7 Profession Helper")
    local setting = Settings.RegisterProxySetting(category, "L7ProfessionHelper_VendorPricing",
        Settings.VarType.String, "Vendor prices", "Capital City",
        function() return addon.options.vendorPricing end, function(value)
            if value == "Cheapest" or value == "Capital City" then
                addon.options.vendorPricing = value
                addon.RefreshPricing()
            end
        end)
    Settings.CreateDropdown(category, setting, function()
        local choices = Settings.CreateControlTextContainer()
        choices:Add("Cheapest", "Cheapest")
        choices:Add("Capital City", "Capital City")
        return choices:GetData()
    end, "Capital City prefers capital vendors, then the cheapest known vendor. Cheapest uses the lowest known vendor price. Crafting costs use AH prices when no vendor price is known. Prices use recorded Wowhead offers or base-price estimates; visiting merchants adds actual offers, including discounts.")
    local craftSetting = Settings.RegisterProxySetting(category, "L7ProfessionHelper_CraftReagents",
        Settings.VarType.Boolean, "Craft cheaper reagents", false,
        function() return addon.options.craftReagents end, addon.SetCraftReagents)
    Settings.CreateCheckbox(category, craftSetting,
        "Use learned recipes when their material cost is lower than buying reagents. Follows crafting chains and counts whole batches. You can also toggle this in the recipe pricing panel.")
    Settings.RegisterAddOnCategory(category)
end

driver:RegisterEvent("ADDON_LOADED")
driver:RegisterEvent("MERCHANT_SHOW")
driver:RegisterEvent("MERCHANT_UPDATE")
driver:SetScript("OnEvent", function(_, event, name)
    if event == "ADDON_LOADED" then
        if name == addonName then
            initialize()
            driver:UnregisterEvent("ADDON_LOADED")
        end
    else
        recordMerchant()
    end
end)
